package com.ashraf.employeeanalysis

import android.app.*
import android.content.*
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SQLiteOpenHelper
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.CancellationSignal
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.text.TextPaint
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.io.*
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.*
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import android.util.Base64

private object Palette {
    const val navy = 0xFF123B5D.toInt(); const val blue = 0xFF176B87.toInt()
    const val teal = 0xFF20A39E.toInt(); const val bg = 0xFFF3F7FA.toInt()
    const val ink = 0xFF183247.toInt(); const val muted = 0xFF63798A.toInt()
    const val white = Color.WHITE; const val line = 0xFFE1EAF0.toInt()
}

private class AppDb(ctx: Context, private val databaseKey: String) : SQLiteOpenHelper(ctx, "employee_analysis.db", null, 6) {
    val readableDatabase: SQLiteDatabase get() = super.getReadableDatabase(databaseKey)
    val writableDatabase: SQLiteDatabase get() = super.getWritableDatabase(databaseKey)
    override fun onConfigure(db: SQLiteDatabase) { db.setForeignKeyConstraintsEnabled(true) }
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE employees(id INTEGER PRIMARY KEY AUTOINCREMENT,file_no TEXT UNIQUE,name TEXT NOT NULL,job TEXT,department TEXT,workplace TEXT,phone TEXT,national_id TEXT,notes TEXT,source_serial TEXT,region TEXT,entity TEXT,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,updated_at TEXT)")
        db.execSQL("CREATE TABLE analyses(id INTEGER PRIMARY KEY AUTOINCREMENT,employee_id INTEGER NOT NULL,analysis_type TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'قيد الانتظار',sample_date TEXT,result_date TEXT,result TEXT,classification TEXT,notes TEXT,analyst TEXT,legal TEXT,clarification TEXT,case_details TEXT,source_serial TEXT,deleted INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL,updated_at TEXT,FOREIGN KEY(employee_id) REFERENCES employees(id))")
        db.execSQL("CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,salt TEXT NOT NULL,role TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL)")
        db.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT NOT NULL)")
        db.execSQL("CREATE TABLE user_permissions(username TEXT NOT NULL, permission TEXT NOT NULL, allowed INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(username,permission))")
        db.execSQL("CREATE TABLE audit(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT,action TEXT NOT NULL,entity TEXT,entity_id INTEGER,details TEXT,created_at TEXT NOT NULL)")
        db.execSQL("CREATE INDEX idx_emp_name ON employees(name)"); db.execSQL("CREATE INDEX idx_emp_file ON employees(file_no)"); db.execSQL("CREATE INDEX idx_analysis_emp ON analyses(employee_id)"); db.execSQL("CREATE INDEX idx_analysis_date ON analyses(sample_date)")
        db.execSQL("PRAGMA user_version=6")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Preserve any legacy data. Additive migrations only.
        addColumn(db,"employees","source_serial","TEXT"); addColumn(db,"employees","region","TEXT"); addColumn(db,"employees","entity","TEXT")
        addColumn(db,"analyses","analyst","TEXT"); addColumn(db,"analyses","legal","TEXT"); addColumn(db,"analyses","clarification","TEXT"); addColumn(db,"analyses","case_details","TEXT"); addColumn(db,"analyses","source_serial","TEXT")
        if (oldVersion < 3) {
            addColumn(db,"employees","national_id","TEXT"); addColumn(db,"employees","updated_at","TEXT")
            addColumn(db,"analyses","updated_at","TEXT")
        }
        if (oldVersion < 4) {
            addColumn(db,"audit","username","TEXT")
            db.execSQL("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,salt TEXT NOT NULL,role TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL)")
            db.execSQL("CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT NOT NULL)")
            db.execSQL("CREATE TABLE IF NOT EXISTS user_permissions(username TEXT NOT NULL, permission TEXT NOT NULL, allowed INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(username,permission))")
            db.execSQL("CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT,action TEXT NOT NULL,entity TEXT,entity_id INTEGER,details TEXT,created_at TEXT NOT NULL)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_emp_name ON employees(name)"); db.execSQL("CREATE INDEX IF NOT EXISTS idx_emp_file ON employees(file_no)"); db.execSQL("CREATE INDEX IF NOT EXISTS idx_analysis_emp ON analyses(employee_id)")
        }
        db.execSQL("CREATE TABLE IF NOT EXISTS user_permissions(username TEXT NOT NULL, permission TEXT NOT NULL, allowed INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(username,permission))")
        // Seed granular permissions for accounts created by earlier app versions.
        val keys=listOf("employees_view","employees_edit","employees_delete","analyses_view","analyses_edit","analyses_delete","import_export","reports","users_manage","settings_manage","audit_view","backup_restore")
        keys.forEach { key ->
            val defaultAllowed = if (key in listOf("employees_view","analyses_view","reports")) 1 else 0
            db.execSQL("INSERT OR IGNORE INTO user_permissions(username,permission,allowed) SELECT username,?,CASE WHEN role='مدير' THEN 1 ELSE ? END FROM users", arrayOf(key,defaultAllowed))
        }
        db.execSQL("PRAGMA user_version=6")
    }
    private fun addColumn(db:SQLiteDatabase,t:String,c:String,d:String){try{db.execSQL("ALTER TABLE $t ADD COLUMN $c $d")}catch(_:Exception){}}
    fun now()=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(Date())
    fun audit(user:String,action:String,entity:String,id:Long?=null,details:String=""){writableDatabase.insert("audit",null,ContentValues().apply{put("username",user);put("action",action);put("entity",entity);if(id!=null)put("entity_id",id);put("details",details);put("created_at",now())})}
    fun scalar(sql:String)=readableDatabase.rawQuery(sql,null).use{if(it.moveToFirst())it.getInt(0)else 0}
    fun employees(q:String="",inactive:Boolean=false):List<Array<String>> { val out=mutableListOf<Array<String>>();val c=readableDatabase.rawQuery("SELECT id,COALESCE(file_no,''),name,COALESCE(job,''),COALESCE(department,''),COALESCE(workplace,''),COALESCE(phone,''),COALESCE(national_id,''),COALESCE(notes,'') FROM employees WHERE active=? AND (name LIKE ? OR COALESCE(file_no,'') LIKE ? OR COALESCE(department,'') LIKE ? OR COALESCE(workplace,'') LIKE ?) ORDER BY name",arrayOf(if(inactive)"0" else "1","%$q%","%$q%","%$q%","%$q%"));c.use{while(it.moveToNext())out.add(Array(9){i->it.getString(i)?:""})};return out }
    fun saveEmployee(id:Long?,v:List<String>,user:String):Boolean=try{val cv=ContentValues().apply{put("file_no",v[0].ifBlank{null});put("name",v[1]);put("job",v[2]);put("department",v[3]);put("workplace",v[4]);put("phone",v[5]);put("national_id",v[6]);put("notes",v[7]);put("updated_at",now());if(id==null)put("created_at",now())};val n=if(id==null)writableDatabase.insertOrThrow("employees",null,cv).also{audit(user,"إضافة","موظف",it,v[1])}.toInt() else writableDatabase.update("employees",cv,"id=?",arrayOf(id.toString())).also{audit(user,"تعديل","موظف",id,v[1])};n>0}catch(_:Exception){false}
    fun setEmployeeActive(id:Long,active:Boolean,user:String){writableDatabase.execSQL("UPDATE employees SET active=? WHERE id=?",arrayOf(if(active)1 else 0,id));audit(user,if(active)"استعادة" else "حذف منطقي","موظف",id)}
    fun analyses(q:String="",employeeId:Long?=null,deleted:Boolean=false):List<Array<String>>{val out=mutableListOf<Array<String>>();val sql="SELECT a.id,a.employee_id,e.name,a.analysis_type,a.status,COALESCE(a.sample_date,''),COALESCE(a.result_date,''),COALESCE(a.result,''),COALESCE(a.classification,''),COALESCE(a.notes,'') FROM analyses a JOIN employees e ON e.id=a.employee_id WHERE a.deleted=? AND (? IS NULL OR a.employee_id=?) AND (e.name LIKE ? OR a.analysis_type LIKE ? OR COALESCE(a.result,'') LIKE ?) ORDER BY a.id DESC";readableDatabase.rawQuery(sql,arrayOf(if(deleted)"1" else "0",employeeId?.toString(),employeeId?.toString(),"%$q%","%$q%","%$q%")).use{c->while(c.moveToNext())out.add(Array(10){i->c.getString(i)?:""})};return out}
    fun saveAnalysis(id:Long?,emp:Long,v:List<String>,user:String):Boolean=try{val cv=ContentValues().apply{put("employee_id",emp);put("analysis_type",v[0]);put("status",v[1]);put("sample_date",v[2]);put("result_date",v[3]);put("result",v[4]);put("classification",v[5]);put("notes",v[6]);put("updated_at",now());if(id==null)put("created_at",now())};val n=if(id==null)writableDatabase.insertOrThrow("analyses",null,cv).also{audit(user,"إضافة","تحليل",it,v[0])}.toInt()else writableDatabase.update("analyses",cv,"id=? AND deleted=0",arrayOf(id.toString())).also{audit(user,"تعديل","تحليل",id,v[0])};n>0}catch(_:Exception){false}
    fun deleteAnalysis(id:Long,user:String,restore:Boolean=false){writableDatabase.execSQL("UPDATE analyses SET deleted=? WHERE id=?",arrayOf(if(restore)0 else 1,id));audit(user,if(restore)"استعادة" else "حذف منطقي","تحليل",id)}
    fun employeeIdByFileNo(fileNo:String):Long? { if(fileNo.isBlank())return null; readableDatabase.rawQuery("SELECT id FROM employees WHERE file_no=? AND active=1 LIMIT 1",arrayOf(fileNo)).use{if(it.moveToFirst())return it.getLong(0)};return null }
    fun saveLegacyEmployee(serial:String,fileNo:String,name:String,job:String,region:String,entity:String,phone:String,nationalId:String,user:String):Long? = try {
        val existing=employeeIdByFileNo(fileNo); if(existing!=null)return existing
        val cv=ContentValues().apply{put("file_no",fileNo.ifBlank{null});put("name",name);put("job",job);put("department",region);put("workplace",entity);put("phone",phone);put("national_id",nationalId);put("source_serial",serial);put("region",region);put("entity",entity);put("created_at",now())}
        writableDatabase.insertOrThrow("employees",null,cv).also{audit(user,"استيراد موظف من الملف التاريخي","موظف",it,name)}
    }catch(_:Exception){null}
    fun saveLegacyAnalysis(employeeId:Long,analysisType:String,sampleDate:String,notes:String,analyst:String,result:String,legal:String,clarification:String,caseDetails:String,serial:String,user:String):Boolean=try{
        val cv=ContentValues().apply{put("employee_id",employeeId);put("analysis_type",analysisType.ifBlank{"غير محدد"});put("status","تم الاستيراد");put("sample_date",sampleDate);put("notes",notes);put("analyst",analyst);put("result",result);put("legal",legal);put("classification",legal);put("clarification",clarification);put("case_details",caseDetails);put("source_serial",serial);put("created_at",now())}
        val id=writableDatabase.insertOrThrow("analyses",null,cv);audit(user,"استيراد تحليل تاريخي","تحليل",id,analysisType);true
    }catch(_:Exception){false}
    fun userRows():List<Array<String>>{val a=mutableListOf<Array<String>>();readableDatabase.rawQuery("SELECT id,username,role,active FROM users ORDER BY id",null).use{c->while(c.moveToNext())a.add(Array(4){i->c.getString(i)})};return a}
    private val permissionKeys=listOf("employees_view","employees_edit","employees_delete","analyses_view","analyses_edit","analyses_delete","import_export","reports","users_manage","settings_manage","audit_view","backup_restore")
    fun addUser(u:String,h:String,s:String,role:String):Boolean=try{writableDatabase.beginTransaction();writableDatabase.insertOrThrow("users",null,ContentValues().apply{put("username",u);put("password_hash",h);put("salt",s);put("role",role);put("created_at",now())});permissionKeys.forEach{key->writableDatabase.insertOrThrow("user_permissions",null,ContentValues().apply{put("username",u);put("permission",key);put("allowed",if(role=="مدير"||key in listOf("employees_view","analyses_view","reports"))1 else 0)})};writableDatabase.setTransactionSuccessful();true}catch(_:Exception){false}finally{try{writableDatabase.endTransaction()}catch(_:Exception){}}
    fun permissions(user:String):Map<String,Boolean>{val m=mutableMapOf<String,Boolean>();readableDatabase.rawQuery("SELECT permission,allowed FROM user_permissions WHERE username=?",arrayOf(user)).use{while(it.moveToNext())m[it.getString(0)]=it.getInt(1)==1};return m}
    fun setPermission(user:String,key:String,allowed:Boolean){writableDatabase.insertWithOnConflict("user_permissions",null,ContentValues().apply{put("username",user);put("permission",key);put("allowed",if(allowed)1 else 0)},SQLiteDatabase.CONFLICT_REPLACE)}
    fun permissionNames()=permissionKeys

    fun authenticate(u:String,p:String):String?{readableDatabase.rawQuery("SELECT password_hash,salt,role FROM users WHERE username=? AND active=1",arrayOf(u)).use{if(it.moveToFirst()){val h=hash(p,Base64.decode(it.getString(1),Base64.NO_WRAP));return if(MessageDigest.isEqual(h.toByteArray(),it.getString(0).toByteArray()))it.getString(2)else null}};return null}
    fun changePassword(u:String,p:String){val s=ByteArray(16).also{SecureRandom().nextBytes(it)};writableDatabase.update("users",ContentValues().apply{put("salt",Base64.encodeToString(s,Base64.NO_WRAP));put("password_hash",hash(p,s))},"username=?",arrayOf(u))}
    fun auditRows():List<String>{val a=mutableListOf<String>();readableDatabase.rawQuery("SELECT created_at,COALESCE(username,''),action,COALESCE(entity,''),COALESCE(details,'') FROM audit ORDER BY id DESC LIMIT 500",null).use{while(it.moveToNext())a.add((0..4).joinToString(" | "){i->it.getString(i)?:""})};return a}
    fun exportCsv(table:String):String { val (sql,header)=if(table=="employees") Pair("SELECT COALESCE(file_no,''),name,COALESCE(job,''),COALESCE(department,''),COALESCE(workplace,''),COALESCE(phone,''),COALESCE(national_id,''),COALESCE(notes,''),COALESCE(source_serial,''),COALESCE(region,''),COALESCE(entity,'') FROM employees ORDER BY id","رقم الملف,الاسم,الوظيفة,الإدارة,جهة العمل,الهاتف,الرقم القومي,ملاحظات,المسلسل الأصلي,المنطقة,الجهة") else Pair("SELECT e.file_no,e.name,a.analysis_type,a.status,a.sample_date,a.result_date,a.result,a.classification,a.notes,COALESCE(a.analyst,''),COALESCE(a.legal,''),COALESCE(a.clarification,''),COALESCE(a.case_details,''),COALESCE(a.source_serial,'') FROM analyses a JOIN employees e ON e.id=a.employee_id ORDER BY a.id","رقم الملف,اسم الموظف,نوع التحليل,الحالة,تاريخ العينة,تاريخ النتيجة,النتيجة,التصنيف,ملاحظات,القائم بالتحليل,قانونية,توضيح,تفاصيل الحالة,المسلسل الأصلي")
        val b=StringBuilder("\uFEFF$header\n");readableDatabase.rawQuery(sql,null).use{c->while(c.moveToNext())b.append((0 until c.columnCount).joinToString(","){i->"\""+(c.getString(i)?:"").replace("\"","\"\"")+"\""}).append('\n')};return b.toString() }
}
private fun hash(password:String,salt:ByteArray):String{val spec=PBEKeySpec(password.toCharArray(),salt,180000,256);val out=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded;spec.clearPassword();return Base64.encodeToString(out,Base64.NO_WRAP)}

class MainActivity:AppCompatActivity(){
    private lateinit var db:AppDb;private var username="";private var role="";private lateinit var root:LinearLayout;private lateinit var body:LinearLayout;private var accent:Int=Palette.blue
    private val createBackup=registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")){u->if(u!=null)writeBackup(u)}
    private val openBackup=registerForActivityResult(ActivityResultContracts.GetContent()){u->if(u!=null)readBackup(u)}
    private val createCsv=registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")){u->if(u!=null)writeUri(u,pendingCsv)}
    private val openCsv=registerForActivityResult(ActivityResultContracts.GetContent()){u->if(u!=null)importEmployees(u)}
    private val createPdf=registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")){u->if(u!=null)writePdf(u)}
    private val createXlsx=registerForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){u->if(u!=null)writeXlsx(u)}
    private val openXlsx=registerForActivityResult(ActivityResultContracts.GetContent()){u->if(u!=null)importXlsx(u)}
    private var pendingXlsxTable="employees"
    private var pendingCsv=""
    private var pendingPdf=""
    private var backupPassphrase=""
    private lateinit var databaseKey:String
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);accent=getAccent();window.statusBarColor=Palette.navy;window.navigationBarColor=Palette.navy;SQLiteDatabase.loadLibs(this);databaseKey=DatabaseSecurity.loadOrCreateKey(this);DatabaseSecurity.migratePlainDatabase(this,databaseKey);db=AppDb(this,databaseKey);if(db.userRows().isEmpty())firstAdmin()else login()}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun getAccent():Int=when(getSharedPreferences("ui",0).getString("accent","blue")){"teal"->0xFF087F8C.toInt();"green"->0xFF26734D.toInt();"indigo"->0xFF4656A5.toInt();else->Palette.blue}
    private fun saveAccent(value:String){getSharedPreferences("ui",0).edit().putString("accent",value).apply();accent=getAccent()}
    private fun text(s:String,size:Float=14f,color:Int=Palette.ink,bold:Boolean=false):TextView=TextView(this).apply{text=s;textSize=size*getSharedPreferences("ui",0).getFloat("font_scale",1f);setTextColor(color);if(bold)setTypeface(null,Typeface.BOLD);gravity=Gravity.RIGHT;setPadding(dp(4),dp(5),dp(4),dp(5))}
    private fun column():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
    private fun page(title:String,subtitle:String=""){root=column().apply{setBackgroundColor(Palette.bg)};val header=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(18));background=GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,intArrayOf(Palette.navy,accent)).apply{cornerRadii=floatArrayOf(0f,0f,dp(24).toFloat(),dp(24).toFloat(),dp(24).toFloat(),dp(24).toFloat(),0f,0f)}};header.addView(text(title,22f,Color.WHITE,true));if(subtitle.isNotBlank())header.addView(text(subtitle,12f,0xFFD9EAF4.toInt()));root.addView(header);val scroll=ScrollView(this);body=column().apply{setPadding(dp(16),dp(12),dp(16),dp(24))};scroll.addView(body);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)}
    private fun card(title:String,desc:String="",action:(()->Unit)?=null){val c=MaterialCardView(this).apply{radius=dp(16).toFloat();cardElevation=dp(2).toFloat();setCardBackgroundColor(Color.WHITE);strokeColor=Palette.line;strokeWidth=dp(1);setOnClickListener{action?.invoke()};isClickable=action!=null};val box=column().apply{setPadding(dp(16),dp(12),dp(16),dp(12));addView(text(title,16f,accent,true));if(desc.isNotBlank())addView(text(desc,12f,Palette.muted))};c.addView(box);val lp=LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(10);body.addView(c,lp)}
    private fun btn(label:String,action:()->Unit)=btn(label,action,false)
    private fun btn(label:String,action:()->Unit,secondary:Boolean){val b=MaterialButton(this).apply{text=label;textSize=14f;cornerRadius=dp(12);setOnClickListener{action()};if(secondary){setBackgroundColor(Color.WHITE);setTextColor(Palette.blue)}else{setBackgroundColor(accent);setTextColor(Color.WHITE)}};val lp=LinearLayout.LayoutParams(-1,dp(50));lp.bottomMargin=dp(8);body.addView(b,lp)}
    private fun input(hint:String,value:String="",multi:Boolean=false):EditText{val e=EditText(this).apply{this.hint=hint;setText(value);textSize=15f;setTextColor(Palette.ink);setHintTextColor(Palette.muted);setPadding(dp(14),dp(10),dp(14),dp(10));background=GradientDrawable().apply{setColor(Color.WHITE);cornerRadius=dp(12).toFloat();setStroke(dp(1),Palette.line)};if(multi){minLines=3;gravity=Gravity.TOP or Gravity.RIGHT}};val lp=LinearLayout.LayoutParams(-1,if(multi)dp(100) else dp(52));lp.bottomMargin=dp(9);body.addView(e,lp);return e}
    private fun firstAdmin(){page("مرحبًا بك في تحاليل العاملين","إنشاء حساب المدير لأول مرة");card("حساب المدير الرئيسي","سيُحفظ محليًا على هذا الهاتف. اختر كلمة مرور قوية.");val u=input("اسم المستخدم","admin");val p=input("كلمة المرور — 8 أحرف على الأقل");val p2=input("تأكيد كلمة المرور");btn("إنشاء حساب المدير"){if(u.text.isBlank()||p.text.length<8||p.text.toString()!=p2.text.toString()){toast("تحقق من اسم المستخدم وكلمة المرور والتأكيد");return@btn};val salt=ByteArray(16).also{SecureRandom().nextBytes(it)};if(db.addUser(u.text.toString().trim(),hash(p.text.toString(),salt),Base64.encodeToString(salt,Base64.NO_WRAP),"مدير")){username=u.text.toString().trim();role="مدير";db.audit(username,"إنشاء حساب","مستخدم");home()}else toast("تعذر إنشاء الحساب")}}
    private fun login(){page("تحاليل العاملين","تسجيل الدخول إلى قاعدة البيانات المحلية");card("مرحبًا بعودتك","أدخل بيانات حسابك للمتابعة");val u=input("اسم المستخدم");val p=input("كلمة المرور");btn("تسجيل الدخول"){val r=db.authenticate(u.text.toString().trim(),p.text.toString());if(r!=null){username=u.text.toString().trim();role=r;db.audit(username,"تسجيل دخول","النظام");home()}else toast("اسم المستخدم أو كلمة المرور غير صحيحة")}}
    private fun home(){page("تحاليل العاملين","نظام إدارة ملفات الموظفين والتحاليل");val ec=db.scalar("SELECT COUNT(*) FROM employees WHERE active=1");val ac=db.scalar("SELECT COUNT(*) FROM analyses WHERE deleted=0");card("لوحة المؤشرات","$ec موظف نشط  •  $ac تحليل مسجل");if(can("employees_view"))card("إدارة الموظفين","إضافة وتعديل وبحث واستعادة السجلات",::employees);if(can("analyses_view"))card("سجل التحاليل","إضافة وتعديل ومراجعة النتائج",::analyses);if(can("import_export")||can("reports"))card("التقارير والاستيراد والتصدير","Excel وCSV وتقارير PDF قابلة للطباعة",::exports);if(can("users_manage"))card("المستخدمون والصلاحيات","إضافة حسابات وتخصيص صلاحيات كل مستخدم",::users);if(can("settings_manage")||can("backup_restore"))card("الإعدادات والأمان","تغيير كلمة المرور والنسخ الاحتياطي",::settings);if(can("audit_view"))card("سجل العمليات","مراجعة العمليات المسجلة",::audit);btn("تسجيل الخروج",{db.audit(username,"تسجيل خروج","النظام");username="";login()},true)}
    private fun employees(){if(!requirePermission("employees_view"))return;page("إدارة الموظفين","قاعدة بيانات محلية قابلة للبحث والتحديث");val q=input("بحث بالاسم أو رقم الملف أو الإدارة");btn("بحث"){employeeResults(q.text.toString())};btn("إضافة موظف جديد",{employeeForm(null)});btn("الموظفون المحذوفون واستعادتهم",{inactiveEmployees()},true);employeeResults("")}
    private fun employeeResults(q:String){val rows=db.employees(q);card("نتائج البحث","${rows.size} سجل");rows.forEach{r->card(r[2],"ملف ${r[1]}  •  ${r[4]}  •  ${r[5]}"){employeeDetail(r)}};if(rows.isEmpty())card("لا توجد نتائج","جرّب تغيير عبارة البحث")}
    private fun employeeDetail(r:Array<String>){page(r[2],"ملف الموظف");card("بيانات الاتصال","الهاتف: ${r[6]}  •  الرقم القومي: ${r[7]}\nملاحظات: ${r[8]}");btn("تعديل البيانات"){employeeForm(r)};btn("عرض تحاليل الموظف"){analysisResults("",r[0].toLong())};btn("إضافة تحليل لهذا الموظف"){analysisForm(r[0].toLong(),null)};btn("حذف الموظف حذفًا منطقيًا",{if(!requirePermission("employees_delete"))return@btn;AlertDialog.Builder(this).setMessage("سيتم إخفاء الموظف مع الاحتفاظ بسجلاته وتحاليله. هل تريد المتابعة؟").setPositiveButton("حذف"){_,_->db.setEmployeeActive(r[0].toLong(),false,username);employees()}.setNegativeButton("إلغاء",null).show()},true)}
    private fun employeeForm(old:Array<String>?){if(!requirePermission("employees_edit"))return;page(if(old==null)"إضافة موظف" else "تعديل الموظف","الحقول ذات العلامة * مطلوبة");val f=input("رقم الملف",old?.get(1).orEmpty());val n=input("الاسم بالكامل *",old?.get(2).orEmpty());val j=input("الوظيفة",old?.get(3).orEmpty());val d=input("الإدارة",old?.get(4).orEmpty());val w=input("جهة العمل / المنطقة",old?.get(5).orEmpty());val ph=input("رقم الهاتف",old?.get(6).orEmpty());val nid=input("الرقم القومي",old?.get(7).orEmpty());val no=input("ملاحظات",old?.get(8).orEmpty(),true);btn("حفظ البيانات"){if(n.text.isBlank()){toast("اسم الموظف مطلوب");return@btn};val ok=db.saveEmployee(old?.get(0)?.toLong(),listOf(f,n,j,d,w,ph,nid,no).map{it.text.toString().trim()},username);if(ok){toast("تم حفظ بيانات الموظف");employees()}else toast("تعذر الحفظ؛ تحقق من عدم تكرار رقم الملف")};btn("إلغاء",::employees,true)}
    private fun inactiveEmployees(){if(!requirePermission("employees_delete"))return;page("الموظفون المحذوفون","يمكن استعادة السجل دون فقد التحاليل");db.employees("",true).forEach{r->card(r[2],"رقم الملف: ${r[1]}"){AlertDialog.Builder(this).setMessage("استعادة هذا الموظف؟").setPositiveButton("استعادة"){_,_->db.setEmployeeActive(r[0].toLong(),true,username);inactiveEmployees()}.setNegativeButton("إلغاء",null).show()}}}
    private fun analyses(){if(!requirePermission("analyses_view"))return;page("سجل التحاليل","بحث حسب الموظف أو نوع التحليل أو النتيجة");val q=input("عبارة البحث");btn("بحث"){analysisResults(q.text.toString())};btn("إضافة تحليل جديد"){chooseEmployee()};btn("التحاليل المحذوفة واستعادتها",{deletedAnalyses()},true);analysisResults("")}
    private fun analysisResults(q:String,emp:Long?=null){if(!requirePermission("analyses_view"))return;val rows=db.analyses(q,emp);card("السجلات","${rows.size} تحليل");rows.forEach{r->card("${r[2]} — ${r[3]}","${r[4]}  •  العينة: ${r[5]}  •  النتيجة: ${r[7]}"){analysisDetail(r)}};if(rows.isEmpty())card("لا توجد تحاليل","لا توجد سجلات مطابقة")}
    private fun chooseEmployee(){if(!requirePermission("analyses_edit"))return;page("اختيار الموظف","اختر الموظف لإضافة تحليل");db.employees().forEach{r->card(r[2],"رقم الملف: ${r[1]}"){analysisForm(r[0].toLong(),null)}}}
    private fun analysisDetail(r:Array<String>){page("تفاصيل التحليل",r[2]);card(r[3],"الحالة: ${r[4]}\nتاريخ العينة: ${r[5]}\nتاريخ النتيجة: ${r[6]}\nالنتيجة: ${r[7]}\nالتصنيف: ${r[8]}\nملاحظات: ${r[9]}");btn("تعديل التحليل"){analysisForm(r[1].toLong(),r)};btn("حذف التحليل حذفًا منطقيًا",{if(!requirePermission("analyses_delete"))return@btn;db.deleteAnalysis(r[0].toLong(),username);analyses()},true)}
    private fun analysisForm(emp:Long,old:Array<String>?){if(!requirePermission("analyses_edit"))return;val name=if(old!=null)old[2] else db.employees().firstOrNull{it[0]==emp.toString()}?.get(2).orEmpty();page(if(old==null)"إضافة تحليل" else "تعديل التحليل",name);val t=input("نوع التحليل *",old?.get(3).orEmpty());val s=input("الحالة (قيد الانتظار / تم الاستلام / تم التحليل / تمت المراجعة)",old?.get(4).orEmpty().ifBlank{"قيد الانتظار"});val sd=input("تاريخ العينة YYYY-MM-DD",old?.get(5).orEmpty());val rd=input("تاريخ النتيجة YYYY-MM-DD",old?.get(6).orEmpty());val res=input("النتيجة",old?.get(7).orEmpty(),true);val cl=input("التصنيف",old?.get(8).orEmpty().ifBlank{"تأكيدية"});val no=input("ملاحظات",old?.get(9).orEmpty(),true);btn("حفظ التحليل"){if(t.text.isBlank()){toast("نوع التحليل مطلوب");return@btn};if(db.saveAnalysis(old?.get(0)?.toLong(),emp,listOf(t,s,sd,rd,res,cl,no).map{it.text.toString().trim()},username)){toast("تم الحفظ");analysisResults("",emp)}else toast("تعذر حفظ التحليل")};btn("إلغاء",{analysisResults("",emp)},true)}
    private fun deletedAnalyses(){if(!requirePermission("analyses_delete"))return;page("التحاليل المحذوفة","استعادة السجلات عند الحاجة");db.analyses("",null,true).forEach{r->card("${r[2]} — ${r[3]}","${r[4]}"){AlertDialog.Builder(this).setMessage("استعادة التحليل؟").setPositiveButton("استعادة"){_,_->db.deleteAnalysis(r[0].toLong(),username,true);deletedAnalyses()}.setNegativeButton("إلغاء",null).show()}}}
    private fun exports(){if(!(can("import_export")||can("reports"))){toast("ليس لديك صلاحية");return};page("الاستيراد والتصدير والطباعة","تبادل بيانات الموظفين والتحاليل وإعداد تقارير قابلة للطباعة")
        if(can("import_export")) btn("استيراد الموظفين من CSV",{openCsv.launch("text/*")})
        if(can("import_export")) btn("استيراد التحاليل التاريخية من CSV",{openCsv.launch("text/*")})
        if(can("import_export")) btn("استيراد ملف Excel للموظفين أو التحاليل",{openXlsx.launch("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")})
        if(can("import_export")) btn("تصدير الموظفين CSV"){pendingCsv=db.exportCsv("employees");createCsv.launch("employees.csv")}
        if(can("import_export")) btn("تصدير التحاليل CSV"){pendingCsv=db.exportCsv("analyses");createCsv.launch("analyses.csv")}
        if(can("import_export")) btn("تصدير الموظفين Excel XLSX"){pendingXlsxTable="employees";createXlsx.launch("employees.xlsx")}
        if(can("import_export")) btn("تصدير التحاليل Excel XLSX"){pendingXlsxTable="analyses";createXlsx.launch("analyses.xlsx")}
        if(can("reports")) btn("طباعة / حفظ تقرير الموظفين PDF"){pendingPdf=buildPdfText("تقرير بيانات الموظفين",db.exportCsv("employees"));createPdf.launch("employees-report.pdf")}
        if(can("reports")) btn("طباعة / حفظ تقرير التحاليل PDF"){pendingPdf=buildPdfText("تقرير التحاليل",db.exportCsv("analyses"));createPdf.launch("analyses-report.pdf")}
        card("تنسيق ملفات الاستيراد","يجب أن يكون CSV بترميز UTF-8 وبنفس ترتيب عناوين الأعمدة التي ينتجها تصدير التطبيق. استيراد التحاليل يربط كل تحليل برقم ملف الموظف ولا يحذف السجلات السابقة.")
    }
    private fun writeUri(u:Uri,data:String){if(!requirePermission("import_export"))return;try{contentResolver.openOutputStream(u)?.bufferedWriter(Charsets.UTF_8)?.use{it.write(data)};toast("تم حفظ الملف بنجاح")}catch(e:Exception){toast("تعذر حفظ الملف: ${e.message}")}}
    private fun importEmployees(u:Uri){if(!requirePermission("import_export"))return;try{val rows=contentResolver.openInputStream(u)?.bufferedReader(Charsets.UTF_8)?.readLines().orEmpty();if(rows.isEmpty())throw IOException("الملف فارغ");val header=rows.first().removePrefix("\uFEFF");var added=0;var skipped=0;var isAnalysis=header.contains("نوع التحليل")||header.contains("اسم الموظف")
        if(isAnalysis){val employees=db.employees("",false).associateBy{it[1]};rows.drop(1).forEach{line->val a=parseCsv(line);val emp=employees[a.getOrElse(0){""}];if(emp!=null&&a.size>=9&&a[2].isNotBlank()){if(db.saveAnalysis(null,emp[0].toLong(),listOf(a[2],a[3],a[4],a[5],a[6],a[7],a[8]),username))added++ else skipped++}else skipped++}}
        else{rows.drop(1).forEach{line->val a=parseCsv(line);if(a.size>=2&&a[1].isNotBlank()&&db.saveEmployee(null,listOf(a.getOrElse(0){""},a[1],a.getOrElse(2){""},a.getOrElse(3){""},a.getOrElse(4){""},a.getOrElse(5){""},a.getOrElse(6){""},a.getOrElse(7){""}),username))added++ else skipped++}}
        toast("اكتمل الاستيراد: أضيف $added، وتجاوزنا $skipped. لم تُحذف السجلات السابقة.");home()}catch(e:Exception){toast("تعذر الاستيراد: ${e.message}")}}
    private fun writeXlsx(uri:Uri){if(!requirePermission("import_export"))return;try{val rows=mutableListOf<List<String>>();val csv=db.exportCsv(pendingXlsxTable).removePrefix("\uFEFF");csv.lineSequence().filter{it.isNotBlank()}.forEach{rows.add(parseCsv(it))};val out=contentResolver.openOutputStream(uri)?:throw IOException("تعذر فتح ملف Excel للحفظ");XlsxCodec.write(out,rows);toast("تم تصدير ملف Excel بنجاح")}catch(e:Exception){toast("تعذر تصدير Excel: ${e.message}")}}
    private fun importXlsx(uri:Uri){if(!requirePermission("import_export"))return;try{val input=contentResolver.openInputStream(uri)?:throw IOException("تعذر قراءة الملف");val rows=input.use{XlsxCodec.read(it).rows};if(rows.size<2)throw IOException("ملف Excel لا يحتوي بيانات");val headers=rows.first().map{it.trim().removePrefix("\uFEFF")};val header= headers.joinToString("|");var added=0;var skipped=0
        if(headers.contains("رقم الملف") && headers.contains("الاسم") && headers.contains("تاريخ التحليل") && headers.contains("النوع")) {
            fun col(name:String)=headers.indexOf(name)
            rows.drop(1).forEach { row ->
                fun v(name:String)=row.getOrElse(col(name)){""}.trim()
                val fileNo=v("رقم الملف");val name=v("الاسم")
                if(name.isBlank()){skipped++;return@forEach}
                val empId=db.saveLegacyEmployee(v("م"),fileNo,name,v("الوظيفة"),v("المنطقة"),v("الجهة"),v("رقم الهاتف"),v("رقم البطاقة"),username)
                if(empId==null){skipped++;return@forEach}
                val hasAnalysis=listOf("تاريخ التحليل","ملاحظات","النوع","القائم بالتحليل","النتيجة","قانونية","توضيح","تفاصيل الحالة").any{v(it).isNotBlank()}
                if(hasAnalysis){if(db.saveLegacyAnalysis(empId,v("النوع"),v("تاريخ التحليل"),v("ملاحظات"),v("القائم بالتحليل"),v("النتيجة"),v("قانونية"),v("توضيح"),v("تفاصيل الحالة"),v("م"),username))added++ else skipped++}
                else added++
            }
            db.audit(username,"استيراد ملف التحاليل التاريخي","Excel",null,"تمت معالجة ${rows.size-1} صفًا؛ تحاليل مستوردة $added ومتجاوزة $skipped")
            toast("اكتمل استيراد الملف التاريخي: تمت إضافة/معالجة $added صفًا، وتجاوزنا $skipped. تم الاحتفاظ بتكرار التحاليل وعدم حذف السجلات السابقة.");home();return
        }
        val isAnalysis=header.contains("نوع التحليل")||header.contains("اسم الموظف")
        if(isAnalysis){val employees=db.employees("",false).associateBy{it[1]};rows.drop(1).forEach{a->val emp=employees[a.getOrElse(0){""}];if(emp!=null&&a.size>=9&&a[2].isNotBlank()){if(db.saveAnalysis(null,emp[0].toLong(),listOf(a[2],a.getOrElse(3){""},a.getOrElse(4){""},a.getOrElse(5){""},a.getOrElse(6){""},a.getOrElse(7){""},a.getOrElse(8){""}),username))added++ else skipped++}else skipped++}}
        else{rows.drop(1).forEach{a->if(a.size>=2&&a[1].isNotBlank()&&db.saveEmployee(null,listOf(a.getOrElse(0){""},a[1],a.getOrElse(2){""},a.getOrElse(3){""},a.getOrElse(4){""},a.getOrElse(5){""},a.getOrElse(6){""},a.getOrElse(7){""}),username))added++ else skipped++}}
        db.audit(username,"استيراد Excel","بيانات",null,"أضيف $added وتجاوز $skipped");toast("اكتمل استيراد Excel: أضيف $added، وتجاوزنا $skipped. لم تُحذف السجلات السابقة.");home()
    }catch(e:Exception){toast("تعذر استيراد Excel: ${e.message}")}}
    private fun buildPdfText(title:String,csv:String):String=title+"\n"+csv.replace("\uFEFF","").replace(",","   |   ")
    private fun writePdf(uri:Uri){if(!requirePermission("reports"))return;val doc=PdfDocument();try{
        val paint=TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;textSize=10f}
        val layout=StaticLayout.Builder.obtain(pendingPdf,0,pendingPdf.length,paint,547).setAlignment(Layout.Alignment.ALIGN_OPPOSITE).setTextDirection(TextDirectionHeuristics.RTL).setLineSpacing(2f,1.05f).build()
        val pageHeight=770;val pages=maxOf(1,(layout.height+pageHeight-1)/pageHeight)
        for(i in 0 until pages){val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,i+1).create());page.canvas.save();page.canvas.translate(24f,32f-i*pageHeight);page.canvas.clipRect(0f,i*pageHeight.toFloat(),547f,(i+1)*pageHeight.toFloat());layout.draw(page.canvas);page.canvas.restore();doc.finishPage(page)}
        contentResolver.openOutputStream(uri)?.use{doc.writeTo(it)}?:throw IOException("تعذر فتح ملف PDF");toast("تم إنشاء تقرير PDF")
    }catch(e:Exception){toast("تعذر إنشاء PDF: ${e.message}")}finally{doc.close()}}
    private fun parseCsv(line:String):List<String>{val a=mutableListOf<String>();val b=StringBuilder();var q=false;var i=0;while(i<line.length){val c=line[i];if(c=='"'){if(q&&i+1<line.length&&line[i+1]=='"'){b.append('"');i++}else q=!q}else if(c==','&&!q){a.add(b.toString());b.setLength(0)}else b.append(c);i++};a.add(b.toString());return a}
    private fun users(){if(!requirePermission("users_manage"))return;page("المستخدمون والصلاحيات","إدارة حسابات الدخول");db.userRows().forEach{r->card(r[1],"الدور: ${r[2]}  •  ${if(r[3]=="1")"نشط" else "موقوف"}"){AlertDialog.Builder(this).setItems(arrayOf("تغيير كلمة المرور","تفعيل / إيقاف الحساب","تخصيص الصلاحيات")){_,which->if(which==0)passwordDialog(r[1])else if(which==2)permissionEditor(r[1])else{if(r[1]==username)toast("لا يمكن إيقاف الحساب المستخدم حاليًا")else{db.writableDatabase.execSQL("UPDATE users SET active=1-active WHERE id=?",arrayOf(r[0]));users()}}}.show()}};btn("إضافة مستخدم"){addUserDialog()};btn("عودة",::home,true)}
    private fun permissionEditor(target:String){if(!requirePermission("users_manage"))return;page("صلاحيات المستخدم","تحديد الوظائف المسموح بها للحساب: $target");val current=db.permissions(target);db.permissionNames().forEach{key->val cb=CheckBox(this).apply{text=permissionLabel(key);isChecked=current[key]?:false;setTextColor(Palette.ink);textSize=15f;buttonTintList=android.content.res.ColorStateList.valueOf(accent);setOnCheckedChangeListener{_,checked->db.setPermission(target,key,checked)}};body.addView(cb)};btn("حفظ الصلاحيات والعودة",::users)}
    private fun addUserDialog(){if(!requirePermission("users_manage"))return;val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),0,dp(20),0)};val u=EditText(this).apply{hint="اسم المستخدم"};val p=EditText(this).apply{hint="كلمة المرور (8 أحرف على الأقل)";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD};val roleSp=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("مستخدم","مدير"))};box.addView(u);box.addView(p);box.addView(roleSp);AlertDialog.Builder(this).setTitle("إضافة مستخدم").setView(box).setPositiveButton("حفظ"){_,_->if(u.text.isNotBlank()&&p.text.length>=8){val salt=ByteArray(16).also{SecureRandom().nextBytes(it)};if(db.addUser(u.text.toString().trim(),hash(p.text.toString(),salt),Base64.encodeToString(salt,Base64.NO_WRAP),roleSp.selectedItem.toString())){db.audit(username,"إضافة مستخدم","مستخدم",null,u.text.toString());users()}else toast("اسم المستخدم مستخدم بالفعل")}else toast("أدخل اسمًا وكلمة مرور من 8 أحرف على الأقل")}.setNegativeButton("إلغاء",null).show()}
    private fun passwordDialog(target:String){if(target!=username&&!requirePermission("users_manage"))return;val p=EditText(this).apply{hint="كلمة المرور الجديدة";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD};AlertDialog.Builder(this).setTitle("تغيير كلمة مرور $target").setView(p).setPositiveButton("تغيير"){_,_->if(p.text.length>=8){db.changePassword(target,p.text.toString());db.audit(username,"تغيير كلمة مرور","مستخدم",null,target);users()}else toast("كلمة المرور يجب ألا تقل عن 8 أحرف")}.setNegativeButton("إلغاء",null).show()}
    private fun settings(){if(!(can("settings_manage")||can("backup_restore"))){toast("ليس لديك صلاحية");return};page("الإعدادات والتخصيص","تخصيص المظهر وحماية بيانات العمل");card("الحساب الحالي","$username — $role");if(can("settings_manage")) btn("تغيير كلمة المرور"){passwordDialog(username)}
        if(can("settings_manage")) card("ألوان الواجهة","اختر اللون الرئيسي للتطبيق")
        if(can("settings_manage")){btn("أزرق طبي",{saveAccent("blue");settings()});btn("فيروزي",{saveAccent("teal");settings()});btn("أخضر هادئ",{saveAccent("green");settings()});btn("نيلي",{saveAccent("indigo");settings()})}
        if(can("settings_manage")) btn("تكبير الخط",{val p=getSharedPreferences("ui",0);p.edit().putFloat("font_scale",(p.getFloat("font_scale",1f)+0.1f).coerceAtMost(1.4f)).apply();settings()},true)
        if(can("settings_manage")) btn("تصغير الخط",{val p=getSharedPreferences("ui",0);p.edit().putFloat("font_scale",(p.getFloat("font_scale",1f)-0.1f).coerceAtLeast(0.9f)).apply();settings()},true)
        card("النسخ الاحتياطي المشفر","تشفير AES-256-GCM ومفتاح مشتق من كلمة مرور تختارها. يمكن استعادة الملف على جهاز آخر عند توفر كلمة المرور.")
        if(can("backup_restore")) btn("إنشاء نسخة احتياطية مشفرة",{backupPasswordDialog(false)})
        if(can("backup_restore")) btn("استعادة نسخة احتياطية مشفرة",{backupPasswordDialog(true)},true)
        card("حالة التشفير التشغيلي","قاعدة البيانات تعمل باستخدام SQLCipher، ويُحمى مفتاحها المحلي بواسطة Android Keystore.")
        card("معلومات الإصدار","الإصدار 2.1.1 — قاعدة بيانات SQLCipher");btn("عودة",::home,true)}
    private fun backupPasswordDialog(restore:Boolean){val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),0,dp(20),0)};val p=EditText(this).apply{hint="كلمة مرور النسخة (10 أحرف على الأقل)";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD};box.addView(p);AlertDialog.Builder(this).setTitle(if(restore)"استعادة النسخة المشفرة" else "إنشاء نسخة مشفرة").setView(box).setPositiveButton(if(restore)"اختيار الملف" else "حفظ النسخة"){_,_->val pass=p.text.toString();if(pass.length<10){toast("كلمة المرور يجب ألا تقل عن 10 أحرف");return@setPositiveButton};backupPassphrase=pass;if(restore)openBackup.launch("application/octet-stream")else createBackup.launch("employee-analysis-backup.eabk")}.setNegativeButton("إلغاء",null).show()}
    private fun writeBackup(uri:Uri){if(!requirePermission("backup_restore"))return;try{val out=contentResolver.openOutputStream(uri)?:throw IOException("تعذر فتح الملف للحفظ");SecureBackup.exportEncrypted(this,out,backupPassphrase.toCharArray(),databaseKey);db.audit(username,"إنشاء نسخة احتياطية مشفرة","قاعدة البيانات");backupPassphrase="";toast("تم إنشاء النسخة الاحتياطية المشفرة") }catch(e:Exception){backupPassphrase="";toast("فشل إنشاء النسخة الاحتياطية: ${e.message}")}}
    private fun readBackup(uri:Uri){if(!requirePermission("backup_restore"))return;try{db.close();val input=contentResolver.openInputStream(uri)?:throw IOException("تعذر قراءة الملف");SecureBackup.restoreEncrypted(this,input,backupPassphrase.toCharArray(),databaseKey);backupPassphrase="";db=AppDb(this,databaseKey);toast("تمت الاستعادة وفحص سلامة قاعدة البيانات؛ يرجى تسجيل الدخول بحساب موجود في النسخة");username="";role="";login()}catch(e:Exception){backupPassphrase="";db=AppDb(this,databaseKey);toast("فشلت الاستعادة ولم يتم اعتماد الملف: ${e.message}")}}
    private fun audit(){if(!requirePermission("audit_view"))return;page("سجل العمليات","آخر 500 عملية");db.auditRows().forEach{card(it)};btn("عودة",::home,true)}
    private fun can(key:String):Boolean = db.permissions(username)[key]==true
    private fun requirePermission(key:String):Boolean { if(can(key))return true;toast("ليس لديك صلاحية لتنفيذ هذه العملية");return false }
    private fun permissionLabel(key:String)=when(key){"employees_view"->"عرض الموظفين";"employees_edit"->"إضافة وتعديل الموظفين";"employees_delete"->"حذف واستعادة الموظفين";"analyses_view"->"عرض التحاليل";"analyses_edit"->"إضافة وتعديل التحاليل";"analyses_delete"->"حذف واستعادة التحاليل";"import_export"->"استيراد وتصدير البيانات";"reports"->"إعداد وطباعة التقارير";"users_manage"->"إدارة المستخدمين والصلاحيات";"settings_manage"->"إدارة الإعدادات";"audit_view"->"عرض سجل العمليات";else->"النسخ الاحتياطي والاستعادة"}
    private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_LONG).show()}
}
