package com.ashraf.employeeanalysis

import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Element

/** Minimal Office Open XML .xlsx codec: no external libraries or network required. */
object XlsxCodec {
    data class Sheet(val rows: List<List<String>>)

    fun write(output: OutputStream, rows: List<List<String>>) {
        ZipOutputStream(output).use { z ->
            fun entry(name: String, value: String) { z.putNextEntry(ZipEntry(name)); z.write(value.toByteArray(Charsets.UTF_8)); z.closeEntry() }
            entry("[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""")
            entry("_rels/.rels", """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
            entry("xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="البيانات" sheetId="1" r:id="rId1"/></sheets></workbook>""")
            entry("xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""")
            val xml = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
            rows.forEachIndexed { ri, row ->
                xml.append("<row r=\"").append(ri + 1).append("\">")
                row.forEachIndexed { ci, raw ->
                    val ref = col(ci) + (ri + 1)
                    xml.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">").append(esc(raw)).append("</t></is></c>")
                }
                xml.append("</row>")
            }
            xml.append("</sheetData></worksheet>")
            entry("xl/worksheets/sheet1.xml", xml.toString())
        }
    }

    fun read(input: InputStream): Sheet {
        val files = mutableMapOf<String, ByteArray>()
        var totalBytes = 0L
        ZipInputStream(input).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (!e.isDirectory) {
                    val bytes = z.readBytes(); totalBytes += bytes.size
                    require(totalBytes <= 64L * 1024 * 1024) { "ملف Excel أكبر من الحد المسموح للاستيراد" }
                    files[e.name] = bytes
                }
                e = z.nextEntry
            }
        }
        // Resolve the first worksheet through workbook relationships instead of assuming sheet1.xml.
        val workbook = files["xl/workbook.xml"] ?: throw IllegalArgumentException("ملف Excel لا يحتوي تعريف المصنف")
        val workbookDoc = parse(workbook)
        val sheetNodes = workbookDoc.getElementsByTagName("sheet")
        require(sheetNodes.length > 0) { "ملف Excel لا يحتوي أوراق عمل" }
        val relationshipId = (sheetNodes.item(0) as Element).getAttribute("r:id")
        val relBytes = files["xl/_rels/workbook.xml.rels"] ?: throw IllegalArgumentException("ملف Excel لا يحتوي روابط أوراق العمل")
        val relDoc = parse(relBytes); val relNodes = relDoc.getElementsByTagName("Relationship")
        var target: String? = null
        for (i in 0 until relNodes.length) { val rel = relNodes.item(i) as Element; if (rel.getAttribute("Id") == relationshipId) target = rel.getAttribute("Target") }
        val sheetPath = target?.let { if (it.startsWith("/")) it.removePrefix("/") else "xl/$it" } ?: throw IllegalArgumentException("تعذر تحديد ورقة البيانات الأولى")
        val sheetBytes = files[sheetPath] ?: throw IllegalArgumentException("ورقة البيانات الأولى غير موجودة")
        val shared = files["xl/sharedStrings.xml"]?.let { parse(it).getElementsByTagName("si").let { nodes -> (0 until nodes.length).map { i -> nodes.item(i).textContent } } } ?: emptyList()
        val doc = parse(sheetBytes); val rowNodes = doc.getElementsByTagName("row"); val rows = mutableListOf<List<String>>()
        require(rowNodes.length <= 200_000) { "عدد صفوف Excel يتجاوز الحد المسموح" }
        for (ri in 0 until rowNodes.length) {
            val row = rowNodes.item(ri) as Element; val cells = row.getElementsByTagName("c"); val values = mutableMapOf<Int, String>(); var max = -1
            for (ci in 0 until cells.length) {
                val cell = cells.item(ci) as Element; val index = colIndex(cell.getAttribute("r")); max = maxOf(max, index)
                val type = cell.getAttribute("t"); val value = when (type) {
                    "inlineStr" -> cell.getElementsByTagName("t").let { if (it.length > 0) it.item(0).textContent else "" }
                    "s" -> cell.getElementsByTagName("v").let { if (it.length > 0) shared.getOrElse(it.item(0).textContent.toInt()) { "" } else "" }
                    else -> cell.getElementsByTagName("v").let { if (it.length > 0) it.item(0).textContent else "" }
                }
                values[index] = value
            }
            rows.add((0..max).map { values[it] ?: "" })
        }
        return Sheet(rows)
    }

    private fun parse(bytes: ByteArray) = DocumentBuilderFactory.newInstance().apply { isNamespaceAware = false; setFeature("http://apache.org/xml/features/disallow-doctype-decl", true); setFeature("http://xml.org/sax/features/external-general-entities", false); setFeature("http://xml.org/sax/features/external-parameter-entities", false) }.newDocumentBuilder().parse(bytes.inputStream())
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")
    private fun col(n: Int): String { var x=n+1; val b=StringBuilder(); while(x>0){val r=(x-1)%26;b.insert(0,('A'.code+r).toChar());x=(x-1)/26};return b.toString() }
    private fun colIndex(ref: String): Int { val letters=ref.takeWhile{it.isLetter()};var n=0;letters.forEach{n=n*26+(it.uppercaseChar().code-'A'.code+1)};return n-1 }
}
