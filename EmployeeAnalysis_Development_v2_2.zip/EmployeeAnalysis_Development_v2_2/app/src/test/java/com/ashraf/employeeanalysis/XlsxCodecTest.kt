package com.ashraf.employeeanalysis

import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class XlsxCodecTest {
    @Test fun roundTripArabicAndQuotedCells() {
        val rows = listOf(
            listOf("رقم الملف", "الاسم", "ملاحظات"),
            listOf("00125", "أحمد نصر", "نتيجة <طبيعية> & متابعة"),
            listOf("00126", "مريم", "قال: \"مراجعة\"")
        )
        val bytes = ByteArrayOutputStream().also { XlsxCodec.write(it, rows) }.toByteArray()
        assertEquals(rows, XlsxCodec.read(ByteArrayInputStream(bytes)).rows)
    }
}
