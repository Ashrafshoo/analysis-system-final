package com.ashraf.employeeanalysis

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import net.sqlcipher.database.SQLiteDatabase
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Local SQLCipher key protected by Android Keystore; never stored as plaintext in preferences. */
object DatabaseSecurity {
    private const val PREFS = "database_security"
    private const val CIPHER_KEY = "wrapped_db_key"
    private const val IV_KEY = "wrapped_db_iv"
    private const val ALIAS = "employee_analysis_keystore_v1"

    fun loadOrCreateKey(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val stored = prefs.getString(CIPHER_KEY, null)
        if (stored != null) {
            val encodedIv = prefs.getString(IV_KEY, null)
                ?: throw IllegalStateException("بيانات مفتاح قاعدة البيانات غير مكتملة. لا تحذف بيانات التطبيق أو تعِد تثبيته؛ يلزم فحص النسخة الاحتياطية.")
            val iv = try { Base64.decode(encodedIv, Base64.NO_WRAP) }
                catch (e: Exception) { throw IllegalStateException("بيانات مفتاح قاعدة البيانات تالفة. لا تحذف بيانات التطبيق.", e) }
            require(iv.size == 12) { "بيانات مفتاح قاعدة البيانات تالفة. لا تحذف بيانات التطبيق." }
            // If a wrapped key already exists, NEVER generate a replacement Keystore key:
            // doing so would make the existing database key unrecoverable.
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getExistingKeystoreKey(), GCMParameterSpec(128, iv))
            val raw = try { cipher.doFinal(Base64.decode(stored, Base64.NO_WRAP)) }
                catch (e: Exception) { throw IllegalStateException("تعذر فك مفتاح قاعدة البيانات المحفوظ. قد يكون مفتاح Android Keystore الأصلي غير متاح. لم يتم إنشاء مفتاح بديل ولم يتم تعديل قاعدة البيانات؛ لا تحذف بيانات التطبيق.", e) }
            require(raw.size == 32) { "مفتاح قاعدة البيانات المحفوظ غير صالح. لا تحذف بيانات التطبيق." }
            return Base64.encodeToString(raw, Base64.NO_WRAP)
        }
        val raw = ByteArray(32).also { java.security.SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKeystoreKey())
        val ok = prefs.edit().putString(CIPHER_KEY, Base64.encodeToString(cipher.doFinal(raw), Base64.NO_WRAP))
            .putString(IV_KEY, Base64.encodeToString(cipher.iv, Base64.NO_WRAP)).commit()
        check(ok) { "تعذر حفظ مفتاح تشفير قاعدة البيانات" }
        return Base64.encodeToString(raw, Base64.NO_WRAP)
    }

    private fun getExistingKeystoreKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        return (ks.getKey(ALIAS, null) as? SecretKey)
            ?: throw IllegalStateException("مفتاح حماية قاعدة البيانات الأصلي غير موجود في Android Keystore. لم يتم إنشاء مفتاح بديل حفاظًا على البيانات.")
    }

    private fun getOrCreateKeystoreKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }

    /** One-time atomic migration of an existing plaintext SQLite file to SQLCipher.
     * A prior plaintext backup is retained until the encrypted database has been opened by AppDb.
     */
    fun migratePlainDatabase(context: Context, passphrase: String) {
        val file = context.getDatabasePath("employee_analysis.db")
        val parent = file.parentFile ?: throw IllegalStateException("تعذر تحديد مجلد قاعدة البيانات")
        val temp = File(parent, "employee_analysis.encrypted.tmp")
        val old = File(parent, "employee_analysis.plain.migration-backup")

        // Recover an interrupted first rename before attempting another migration.
        if (!file.exists() && old.exists()) {
            if (!old.renameTo(file)) throw IllegalStateException("عُثر على نسخة قاعدة البيانات الأصلية من محاولة ترحيل سابقة، لكن تعذر إعادتها. لا تحذف ملفات التطبيق.")
        }
        if (!file.exists() || isSqlCipher(file, passphrase)) return

        // Never overwrite a prior recovery copy. It may be the only surviving original.
        if (old.exists()) throw IllegalStateException("توجد نسخة رجوع من محاولة ترحيل سابقة. أوقفنا الترحيل حفاظًا عليها؛ لا تحذفها ولا تحذف بيانات التطبيق.")
        if (temp.exists() && !temp.delete()) throw IllegalStateException("تعذر تنظيف ملف ترحيل مؤقت قديم؛ لم يتم تغيير قاعدة البيانات الأصلية")

        val source = SQLiteDatabase.openDatabase(file.absolutePath, "", null, SQLiteDatabase.OPEN_READWRITE)
        try {
            val escapedPath = temp.absolutePath.replace("'", "''")
            val escapedKey = passphrase.replace("'", "''")
            source.rawExecSQL("ATTACH DATABASE '$escapedPath' AS encrypted KEY '$escapedKey'")
            try { source.rawQuery("SELECT sqlcipher_export('encrypted')", null).use { it.moveToFirst() } }
            finally { source.rawExecSQL("DETACH DATABASE encrypted") }
        } finally { source.close() }
        // The old plaintext database may have WAL/SHM sidecars. Never let them be
        // associated with the new SQLCipher file after the atomic rename.
        deleteSidecars(file)

        require(isSqlCipher(temp, passphrase)) {
            temp.delete()
            "تعذر التحقق من تشفير قاعدة البيانات بعد الترحيل؛ بقيت القاعدة الأصلية دون تغيير"
        }
        if (!file.renameTo(old)) {
            temp.delete()
            throw IllegalStateException("تعذر حفظ قاعدة البيانات الأصلية قبل التشفير؛ لم يتم استبدالها")
        }
        if (!temp.renameTo(file)) {
            val restored = old.renameTo(file)
            temp.delete()
            throw IllegalStateException(if (restored) "تعذر اعتماد قاعدة البيانات المشفرة؛ تمت إعادة الملف الأصلي" else "تعذر اعتماد قاعدة البيانات وتعذرت إعادة الملف الأصلي تلقائيًا. النسخة الأصلية محفوظة باسم employee_analysis.plain.migration-backup؛ لا تحذف بيانات التطبيق.")
        }
        if (!isSqlCipher(file, passphrase)) {
            file.delete()
            val restored = old.renameTo(file)
            throw IllegalStateException(if (restored) "فشل التحقق النهائي؛ تمت إعادة قاعدة البيانات الأصلية" else "فشل التحقق النهائي. النسخة الأصلية محفوظة باسم employee_analysis.plain.migration-backup؛ لا تحذف بيانات التطبيق.")
        }
        // Keep the plaintext recovery copy until the app successfully opens and validates AppDb.
    }

    /** Call only after AppDb has opened and passed its initial read checks. */
    fun cleanupValidatedRecoveryCopies(context: Context) {
        val parent = context.getDatabasePath("employee_analysis.db").parentFile ?: return
        listOf("employee_analysis.plain.migration-backup", "employee_analysis.rollback", "employee_analysis.pre-import")
            .forEach { name ->
                val recovery = File(parent, name)
                if (recovery.exists() && !recovery.delete()) {
                    // Keep any recovery copy that cannot be removed; never risk data loss.
                }
            }
    }

    private fun deleteSidecars(base: File) {
        listOf("-wal", "-shm", "-journal").forEach { suffix ->
            val sidecar = File(base.path + suffix)
            if (sidecar.exists() && !sidecar.delete()) {
                throw IllegalStateException("تعذر تنظيف ملف قاعدة بيانات جانبي قبل الترحيل: ${sidecar.name}")
            }
        }
    }

    fun isSqlCipher(file: File, passphrase: String): Boolean = try {
        val db = SQLiteDatabase.openDatabase(file.absolutePath, passphrase, null, SQLiteDatabase.OPEN_READONLY)
        try {
            db.rawQuery("SELECT count(*) FROM sqlite_master", null).use { it.moveToFirst() }
            db.rawQuery("PRAGMA cipher_version", null).use { it.moveToFirst() && it.getString(0).isNotBlank() }
        } finally { db.close() }
    } catch (_: Exception) { false }
}
