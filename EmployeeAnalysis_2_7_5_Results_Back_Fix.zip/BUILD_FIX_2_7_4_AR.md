# إصلاح خطأ القوس الزائد — الإصدار 2.7.4

## الخطأ

ظهرت أخطاء GitHub Actions في الأسطر 863 وما بعدها، مثل:

- `Unresolved reference db`
- `Unresolved reference username`
- `Unresolved reference login`
- `this is not defined in this context`

## السبب

كان مستمع اختيار الخط في شاشة الإعدادات يحتوي على قوس إغلاق زائد بعد `Typeface.create(...)`. أدى ذلك إلى إغلاق كتلة `settings()` قبل أوانها، فظهرت الدوال التالية وكأنها خارج `MainActivity`.

## الإصلاح

تم حذف القوس الزائد والإبقاء على إغلاقين فقط: إغلاق دالة `onItemSelected` وإغلاق كائن `OnItemSelectedListener`. كما تمت مراجعة عمق الأقواس حول `settings()` ودوال النسخ والاستعادة وسجل العمليات.

الإصدار المصحح: **2.7.4 / Build 40**.
