# إصلاح خطأ بناء النسخة السابقة — 2.7.2

## سبب الخطأ

النسخة 2.7.0 كانت تحتوي على تسلسل `\n` حرفي بعد دالة `parseCsvRecords` بدلاً من فاصل سطر Kotlin فعلي. نتيجة ذلك التصق تعريف `users` وما بعده بنهاية الدالة، ولم يتعرف المترجم على نطاق الدوال اللاحقة بالشكل الصحيح.

لذلك ظهرت رسائل كثيرة مثل:

- `Unresolved reference: toast`
- `Unresolved reference: can`
- `Unresolved reference: audit`
- `Unresolved reference: requirePermission`

هذه الرسائل ليست أخطاء مستقلة في كل وظيفة؛ هي أخطاء متسلسلة ناتجة عن خلل الفاصل البرمجي.

## الإصلاح

تم وضع فاصل سطر فعلي بعد إغلاق `parseCsvRecords`، ثم التحقق من وجود تعريفات مستقلة للدوال `users` و`permissionEditor` و`settings` و`audit` و`can` و`requirePermission` و`toast` داخل `MainActivity`.

تم رفع الإصدار إلى **2.7.2 / Build 38** حتى لا تختلط النسخة المصححة بالأرشيف السابق.

## ملاحظة البناء

ملف الخطأ المرفق يثبت أن Gradle وصل إلى مهمة `compileDebugKotlin` وأن المشكلة في المصدر، وليست مشكلة اتصال RMI أو إضافة Kotlin Scripting؛ رسائل RMI وScripting الظاهرة في بداية الملف رسائل debug وليست سبب الفشل.
