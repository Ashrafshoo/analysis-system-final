package com.ashraf.employeeanalysis

import android.content.Context
import android.database.sqlite.SQLiteDatabase as PlainSQLiteDatabase
import net.sqlcipher.database.SQLiteDatabase
import java.io.*
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Portable authenticated backup: plaintext is only temporary and immediately encrypted. */
object SecureBackup {
    private val magic = "EABK3".toByteArray(Charsets.US_ASCII)
    private const val ITERATIONS = 310_000
    private const val SALT_SIZE = 16
    private const val IV_SIZE = 12
    private const val MAX_BACKUP_BYTES = 512L * 1024 * 1024

    private fun key(passphrase: CharArray, salt: ByteArray, iterations: Int = ITERATIONS): SecretKeySpec {
        require(passphrase.size >= 10) { "كلمة مرور النسخة الاحتياطية يجب ألا تقل عن 10 أحرف" }
        val spec = PBEKeySpec(passphrase, salt, iterations, 256)
        return try { SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded, "AES") }
        finally { spec.clearPassword() }
    }

    fun exportEncrypted(context: Context, output: OutputStream, passphrase: CharArray, databasePassword: String) {
        val dbFile = context.getDatabasePath("employee_analysis.db")
        require(dbFile.exists()) { "ملف قاعدة البيانات غير موجود" }
        val plain = File(context.cacheDir, "backup-export-plain.tmp")
        try {
            val live = SQLiteDatabase.openDatabase(dbFile.absolutePath, databasePassword, null, SQLiteDatabase.OPEN_READWRITE)
            try {
                live.rawQuery("PRAGMA wal_checkpoint(FULL)", null).use { c -> if (c.moveToFirst() && c.getInt(0) != 0) throw IOException("تعذر إتمام حفظ معاملات قاعدة البيانات") }
                val escaped = plain.absolutePath.replace("'", "''")
                live.rawExecSQL("ATTACH DATABASE '$escaped' AS backup_plain KEY ''")
                try { live.rawQuery("SELECT sqlcipher_export('backup_plain')", null).use { it.moveToFirst() } }
                finally { live.rawExecSQL("DETACH DATABASE backup_plain") }
            } finally { live.close() }
            require(plain.exists() && plain.length() > 0) { "تعذر تجهيز قاعدة البيانات للنسخ الاحتياطي" }
            val salt = ByteArray(SALT_SIZE).also { SecureRandom().nextBytes(it) }
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key(passphrase, salt))
            DataOutputStream(BufferedOutputStream(output)).use { out ->
                out.write(magic); out.writeInt(ITERATIONS); out.writeInt(SALT_SIZE); out.write(salt)
                out.writeInt(cipher.iv.size); out.write(cipher.iv)
                CipherOutputStream(out, cipher).use { encrypted -> FileInputStream(plain).use { it.copyTo(encrypted) } }
            }
        } finally { plain.delete(); passphrase.fill('\u0000') }
    }


    /** Import a trusted plaintext SQLite database, validate it, encrypt it with this device key, then atomically replace the live DB. */
    fun importPlainDatabase(context: Context, input: InputStream, databasePassword: String) {
        val plain = File(context.cacheDir, "database-import-plain.tmp")
        val encrypted = File(context.cacheDir, "database-import-encrypted.tmp")
        val live = context.getDatabasePath("employee_analysis.db")
        val staged = File(live.parentFile, "employee_analysis.import")
        val rollback = File(live.parentFile, "employee_analysis.pre-import")
        try {
            FileOutputStream(plain).use { out ->
                val buffer = ByteArray(64 * 1024); var total = 0L
                while (true) { val n = input.read(buffer); if (n < 0) break; total += n
                    require(total in 1..MAX_BACKUP_BYTES) { "حجم ملف قاعدة البيانات غير صالح أو يتجاوز الحد المسموح" }
                    out.write(buffer, 0, n)
                }
            }
            val check = PlainSQLiteDatabase.openDatabase(plain.absolutePath, null, PlainSQLiteDatabase.OPEN_READONLY)
            try {
                check.rawQuery("PRAGMA quick_check", null).use { c -> require(c.moveToFirst() && c.getString(0) == "ok") { "قاعدة البيانات المستوردة تالفة" } }
                listOf("employees", "analyses", "users", "settings", "user_permissions", "audit", "activation_codes").forEach { table ->
                    check.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name=?", arrayOf(table)).use { c -> require(c.moveToFirst()) { "الملف ليس قاعدة بيانات البرنامج: الجدول $table غير موجود" } }
                }
                check.rawQuery("PRAGMA foreign_key_check", null).use { c -> require(!c.moveToFirst()) { "توجد علاقات غير سليمة في قاعدة البيانات المستوردة" } }
                check.rawQuery("SELECT id,name,file_no FROM employees LIMIT 1", null).use { }
                check.rawQuery("SELECT id,employee_id,sample_date FROM analyses LIMIT 1", null).use { }
            } finally { check.close() }

            val source = SQLiteDatabase.openDatabase(plain.absolutePath, "", null, SQLiteDatabase.OPEN_READWRITE)
            try {
                val path = encrypted.absolutePath.replace("'", "''")
                val pass = databasePassword.replace("'", "''")
                source.rawExecSQL("ATTACH DATABASE '$path' AS imported_encrypted KEY '$pass'")
                try { source.rawQuery("SELECT sqlcipher_export('imported_encrypted')", null).use { it.moveToFirst() } }
                finally { source.rawExecSQL("DETACH DATABASE imported_encrypted") }
            } finally { source.close() }
            val verify = SQLiteDatabase.openDatabase(encrypted.absolutePath, databasePassword, null, SQLiteDatabase.OPEN_READONLY)
            try {
                verify.rawQuery("PRAGMA quick_check", null).use { c -> require(c.moveToFirst() && c.getString(0) == "ok") { "فشل التحقق من تشفير قاعدة البيانات المستوردة" } }
                verify.rawQuery("SELECT COUNT(*) FROM employees", null).use { c -> require(c.moveToFirst()) }
                verify.rawQuery("SELECT COUNT(*) FROM analyses", null).use { c -> require(c.moveToFirst()) }
                verify.rawQuery("PRAGMA foreign_key_check", null).use { c -> require(!c.moveToFirst()) { "فشل فحص العلاقات بعد التشفير" } }
            } finally { verify.close() }

            live.parentFile?.let { if (!it.exists()) it.mkdirs() }
            staged.delete()
            if (!encrypted.renameTo(staged)) throw IOException("تعذر تجهيز قاعدة البيانات المشفرة للاستيراد")
            File(live.path + "-wal").delete(); File(live.path + "-shm").delete()
            rollback.delete()
            if (live.exists() && !live.renameTo(rollback)) throw IOException("تعذر حفظ قاعدة البيانات الحالية كنسخة رجوع")
            if (!staged.renameTo(live)) {
                val restored = !rollback.exists() || rollback.renameTo(live)
                if (!restored) throw IOException("تعذر اعتماد قاعدة البيانات الجديدة؛ احتفظ ببيانات التطبيق ولا تحذفها")
                throw IOException("تعذر اعتماد قاعدة البيانات الجديدة؛ تمت إعادة القاعدة السابقة")
            }
            // Keep the encrypted previous database as a recovery point until a later successful operation.
        } finally {
            plain.delete(); encrypted.delete(); staged.delete()
            // Keep rollback: it is an encrypted recovery copy, not plaintext.
        }
    }

    fun restoreEncrypted(context: Context, input: InputStream, passphrase: CharArray, databasePassword: String) {
        val plain = File(context.cacheDir, "restore-plain.tmp")
        val encryptedDb = File(context.cacheDir, "restore-encrypted.tmp")
        val live = context.getDatabasePath("employee_analysis.db")
        val staged = File(live.parentFile, "employee_analysis.restore")
        val rollback = File(live.parentFile, "employee_analysis.rollback")
        try {
            DataInputStream(BufferedInputStream(input)).use { data ->
                val header = ByteArray(magic.size); data.readFully(header)
                require(header.contentEquals(magic)) { "صيغة النسخة غير مدعومة؛ يلزم ملف EABK3" }
                val iterations = data.readInt(); require(iterations in 200_000..1_000_000) { "إعدادات التشفير غير سليمة" }
                val saltSize = data.readInt(); require(saltSize == SALT_SIZE) { "ملح التشفير غير سليم" }
                val salt = ByteArray(saltSize); data.readFully(salt)
                val ivSize = data.readInt(); require(ivSize == IV_SIZE) { "بيانات التشفير غير سليمة" }
                val iv = ByteArray(ivSize); data.readFully(iv)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, key(passphrase, salt, iterations), GCMParameterSpec(128, iv))
                CipherInputStream(data, cipher).use { decrypted -> FileOutputStream(plain).use { out ->
                    val buffer = ByteArray(64 * 1024); var total = 0L
                    while (true) { val n = decrypted.read(buffer); if (n < 0) break; total += n; require(total <= MAX_BACKUP_BYTES) { "حجم النسخة يتجاوز الحد المسموح" }; out.write(buffer, 0, n) }
                } }
            }
            val check = PlainSQLiteDatabase.openDatabase(plain.absolutePath, null, PlainSQLiteDatabase.OPEN_READONLY)
            try {
                check.rawQuery("PRAGMA quick_check", null).use { c -> require(c.moveToFirst() && c.getString(0) == "ok") { "فشل فحص سلامة قاعدة البيانات" } }
                listOf("employees", "analyses", "users", "settings", "user_permissions", "audit", "activation_codes").forEach { table -> check.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name=?", arrayOf(table)).use { c -> require(c.moveToFirst()) { "النسخة لا تحتوي جدول $table" } } }
            check.rawQuery("PRAGMA foreign_key_check", null).use { c -> require(!c.moveToFirst()) { "توجد علاقات غير سليمة داخل النسخة الاحتياطية" } }
            val employeeCount = check.rawQuery("SELECT COUNT(*) FROM employees", null).use { c -> require(c.moveToFirst()); c.getLong(0) }
            val analysisCount = check.rawQuery("SELECT COUNT(*) FROM analyses", null).use { c -> require(c.moveToFirst()); c.getLong(0) }
            require(employeeCount >= 0 && analysisCount >= 0) { "تعذر قراءة أعداد السجلات" }
            } finally { check.close() }
            val source = SQLiteDatabase.openDatabase(plain.absolutePath, "", null, SQLiteDatabase.OPEN_READWRITE)
            try {
                val path = encryptedDb.absolutePath.replace("'", "''"); val pass = databasePassword.replace("'", "''")
                source.rawExecSQL("ATTACH DATABASE '$path' AS encrypted_restore KEY '$pass'")
                try { source.rawQuery("SELECT sqlcipher_export('encrypted_restore')", null).use { it.moveToFirst() } }
                finally { source.rawExecSQL("DETACH DATABASE encrypted_restore") }
            } finally { source.close() }
            val verify = SQLiteDatabase.openDatabase(encryptedDb.absolutePath, databasePassword, null, SQLiteDatabase.OPEN_READONLY)
            try {
                verify.rawQuery("PRAGMA quick_check", null).use { c -> require(c.moveToFirst() && c.getString(0) == "ok") { "فشل التحقق بعد إعادة التشفير" } }
                listOf("employees", "analyses", "users", "settings", "user_permissions", "audit", "activation_codes").forEach { table -> verify.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name=?", arrayOf(table)).use { c -> require(c.moveToFirst()) { "فقد جدول $table أثناء إعادة التشفير" } } }
                verify.rawQuery("PRAGMA foreign_key_check", null).use { c -> require(!c.moveToFirst()) { "فشل فحص العلاقات بعد إعادة التشفير" } }
            } finally { verify.close() }
            live.parentFile?.let { if (!it.exists()) it.mkdirs() }
            staged.delete(); rollback.delete()
            if (!encryptedDb.renameTo(staged)) throw IOException("تعذر تجهيز قاعدة البيانات المستعادة")
            File(live.path + "-wal").delete(); File(live.path + "-shm").delete()
            if (live.exists() && !live.renameTo(rollback)) throw IOException("تعذر حفظ قاعدة البيانات الحالية")
            if (!staged.renameTo(live)) {
                val rolledBack = !rollback.exists() || rollback.renameTo(live)
                if (!rolledBack) throw IOException("تعذر اعتماد النسخة وتعذر إعادة قاعدة البيانات السابقة؛ احتفظ بملف الاستعادة ولا تحذف بيانات التطبيق")
                throw IOException("تعذر اعتماد قاعدة البيانات المستعادة؛ تمت إعادة القاعدة السابقة")
            }
            // Keep the previous encrypted database as an internal recovery point after a successful restore.
            // It is replaced only by the next restore attempt, never exposed as plaintext.
        } finally {
            plain.delete(); encryptedDb.delete(); staged.delete()
            // Never delete the rollback file if it is the only surviving copy after a failed swap.
            // Do not remove rollback here: it is the encrypted pre-restore recovery copy.
            passphrase.fill('\u0000')
        }
    }
}
