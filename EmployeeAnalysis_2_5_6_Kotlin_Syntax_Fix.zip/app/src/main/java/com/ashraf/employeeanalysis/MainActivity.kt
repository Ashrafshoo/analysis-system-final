package com.ashraf.employeeanalysis

import android.app.*
import android.content.*
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SQLiteOpenHelper
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.text.TextPaint
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.OnBackPressedCallback
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.io.*
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.*
import kotlin.concurrent.thread
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import android.util.Base64

private object Palette {
    const val navy = 0xFF09263D.toInt(); const val blue = 0xFF105A78.toInt()
    const val teal = 0xFF118F91.toInt(); const val bg = 0xFFF1F5F8.toInt()
    const val ink = 0xFF132F43.toInt(); const val muted = 0xFF5D7282.toInt()
    const val white = Color.WHITE; const val line = 0xFFE1EAF0.toInt()
}

private data class UiTheme(val name:String,val accent:Int,val bg:Int,val ink:Int,val muted:Int,val card:Int,val shadow:Int)
private val UI_THEMES=listOf(
 UiTheme("أخضر طبي فاخر",0xFF176B52.toInt(),0xFFF3F8F5.toInt(),0xFF18372D.toInt(),0xFF667D73.toInt(),Color.WHITE,0xFFDCE9E1.toInt()),
 UiTheme("أزرق طبي هادئ",0xFF176B87.toInt(),0xFFF2F7FA.toInt(),0xFF183447.toInt(),0xFF637987.toInt(),Color.WHITE,0xFFDCE8EE.toInt()),
 UiTheme("فيروزي عصري",0xFF087F83.toInt(),0xFFF0F8F7.toInt(),0xFF173B3D.toInt(),0xFF607D7D.toInt(),Color.WHITE,0xFFD8EAE7.toInt()),
 UiTheme("كحلي مؤسسي",0xFF294B68.toInt(),0xFFF1F5F8.toInt(),0xFF172B3C.toInt(),0xFF647789.toInt(),Color.WHITE,0xFFDCE4EA.toInt()),
 UiTheme("نيلي أنيق",0xFF4656A5.toInt(),0xFFF3F4FA.toInt(),0xFF252F55.toInt(),0xFF68708D.toInt(),Color.WHITE,0xFFE1E4F1.toInt()),
 UiTheme("بنفسجي هادئ",0xFF7651A8.toInt(),0xFFF7F3FA.toInt(),0xFF382A4A.toInt(),0xFF7B6D89.toInt(),Color.WHITE,0xFFEAE2F1.toInt()),
 UiTheme("رمادي احترافي",0xFF596579.toInt(),0xFFF3F5F7.toInt(),0xFF303944.toInt(),0xFF737D88.toInt(),Color.WHITE,0xFFE1E5E9.toInt()),
 UiTheme("عنابي راقٍ",0xFF8A3D55.toInt(),0xFFFAF3F5.toInt(),0xFF472630.toInt(),0xFF856A73.toInt(),Color.WHITE,0xFFEEDFE4.toInt()),
 UiTheme("رملي دافئ",0xFF866343.toInt(),0xFFFAF7F1.toInt(),0xFF49382A.toInt(),0xFF847464.toInt(),Color.WHITE,0xFFECE5D9.toInt()),
 UiTheme("داكن ليلي",0xFF55B7AD.toInt(),0xFF14252B.toInt(),0xFFE7F1F2.toInt(),0xFFACBEC1.toInt(),0xFF20363D.toInt(),0xFF304B51.toInt())
)

private class AppDb(ctx: Context, private val databaseKey: String) : SQLiteOpenHelper(ctx, "employee_analysis.db", null, 11) {
    val readableDatabase: SQLiteDatabase get() = super.getReadableDatabase(databaseKey)
    val writableDatabase: SQLiteDatabase get() = super.getWritableDatabase(databaseKey)
    override fun onConfigure(db: SQLiteDatabase) { db.setForeignKeyConstraintsEnabled(true) }
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE employees(id INTEGER PRIMARY KEY AUTOINCREMENT,file_no TEXT UNIQUE,name TEXT NOT NULL,job TEXT,department TEXT,workplace TEXT,phone TEXT,national_id TEXT,gender TEXT,notes TEXT,source_serial TEXT,region TEXT,entity TEXT,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,updated_at TEXT)")
        db.execSQL("CREATE TABLE analyses(id INTEGER PRIMARY KEY AUTOINCREMENT,employee_id INTEGER NOT NULL,analysis_type TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'قيد الانتظار',sample_date TEXT,result_date TEXT,result TEXT,classification TEXT,notes TEXT,analyst TEXT,legal TEXT,clarification TEXT,case_details TEXT,source_serial TEXT,deleted INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL,updated_at TEXT,FOREIGN KEY(employee_id) REFERENCES employees(id))")
        db.execSQL("CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,salt TEXT NOT NULL,role TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL)")
        db.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT NOT NULL)")
        db.execSQL("CREATE TABLE user_permissions(username TEXT NOT NULL, permission TEXT NOT NULL, allowed INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(username,permission))")
        db.execSQL("CREATE TABLE audit(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT,action TEXT NOT NULL,entity TEXT,entity_id INTEGER,details TEXT,created_at TEXT NOT NULL)")
        db.execSQL("CREATE TABLE activation_codes(code_hash TEXT PRIMARY KEY,role TEXT NOT NULL,created_by TEXT NOT NULL,created_at TEXT NOT NULL,used INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE INDEX idx_emp_name ON employees(name)"); db.execSQL("CREATE INDEX idx_emp_file ON employees(file_no)"); db.execSQL("CREATE INDEX idx_analysis_emp ON analyses(employee_id)"); db.execSQL("CREATE INDEX idx_analysis_date ON analyses(sample_date)")
        db.execSQL("CREATE INDEX idx_emp_national ON employees(national_id)"); db.execSQL("CREATE INDEX idx_emp_phone ON employees(phone)"); db.execSQL("CREATE INDEX idx_analysis_type ON analyses(analysis_type)"); db.execSQL("CREATE INDEX idx_analysis_status ON analyses(status)"); db.execSQL("CREATE INDEX idx_analysis_source_employee ON analyses(employee_id,source_serial)")
        installAuditGuards(db)
        db.execSQL("PRAGMA user_version=11")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Preserve any legacy data. Additive migrations only.
        addColumn(db,"employees","source_serial","TEXT"); addColumn(db,"employees","region","TEXT"); addColumn(db,"employees","entity","TEXT"); addColumn(db,"employees","gender","TEXT")
        addColumn(db,"analyses","analyst","TEXT"); addColumn(db,"analyses","legal","TEXT"); addColumn(db,"analyses","clarification","TEXT"); addColumn(db,"analyses","case_details","TEXT"); addColumn(db,"analyses","source_serial","TEXT")
        if (oldVersion < 3) {
            addColumn(db,"employees","national_id","TEXT"); addColumn(db,"employees","updated_at","TEXT")
            addColumn(db,"analyses","updated_at","TEXT")
        }
        if (oldVersion < 4) {
            addColumn(db,"audit","username","TEXT")
            db.execSQL("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,salt TEXT NOT NULL,role TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL)")
            db.execSQL("CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT NOT NULL)")
            db.execSQL("CREATE TABLE IF NOT EXISTS user_permissions(username TEXT NOT NULL, permission TEXT NOT NULL, allowed INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(username,permission))")
            db.execSQL("CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT,action TEXT NOT NULL,entity TEXT,entity_id INTEGER,details TEXT,created_at TEXT NOT NULL)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_emp_name ON employees(name)"); db.execSQL("CREATE INDEX IF NOT EXISTS idx_emp_file ON employees(file_no)"); db.execSQL("CREATE INDEX IF NOT EXISTS idx_analysis_emp ON analyses(employee_id)")
        }
        db.execSQL("CREATE TABLE IF NOT EXISTS user_permissions(username TEXT NOT NULL, permission TEXT NOT NULL, allowed INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(username,permission))")
        db.execSQL("CREATE TABLE IF NOT EXISTS activation_codes(code_hash TEXT PRIMARY KEY,role TEXT NOT NULL,created_by TEXT NOT NULL,created_at TEXT NOT NULL,used INTEGER NOT NULL DEFAULT 0)")
        // Seed granular permissions for accounts created by earlier app versions.
        val keys=listOf("employees_view","employees_edit","employees_delete","analyses_view","analyses_edit","analyses_delete","import_export","reports","users_manage","settings_manage","audit_view","backup_restore")
        keys.forEach { key ->
            val defaultAllowed = if (key in listOf("employees_view","analyses_view","reports")) 1 else 0
            db.execSQL("INSERT OR IGNORE INTO user_permissions(username,permission,allowed) SELECT username,?,CASE WHEN role='مدير' THEN 1 ELSE ? END FROM users", arrayOf(key,defaultAllowed))
        }
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_emp_national ON employees(national_id)"); db.execSQL("CREATE INDEX IF NOT EXISTS idx_emp_phone ON employees(phone)"); db.execSQL("CREATE INDEX IF NOT EXISTS idx_analysis_type ON analyses(analysis_type)"); db.execSQL("CREATE INDEX IF NOT EXISTS idx_analysis_status ON analyses(status)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_analysis_source_employee ON analyses(employee_id,source_serial)")
        // Remove the old date-only uniqueness rule; distinct source rows can share a date.
        db.execSQL("DROP TRIGGER IF EXISTS analyses_unique_employee_date_insert")
        db.execSQL("DROP TRIGGER IF EXISTS analyses_unique_employee_date_update")
        installAuditGuards(db)
        db.execSQL("PRAGMA user_version=11")
    }
    private fun installAuditGuards(db:SQLiteDatabase){
        db.execSQL("CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit BEGIN SELECT RAISE(ABORT, 'سجل العمليات للإضافة فقط'); END")
        db.execSQL("CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit BEGIN SELECT RAISE(ABORT, 'سجل العمليات للإضافة فقط'); END")
    }
    private fun addColumn(db:SQLiteDatabase,t:String,c:String,d:String){try{db.execSQL("ALTER TABLE $t ADD COLUMN $c $d")}catch(_:Exception){}}
    fun now()=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(Date())
    fun audit(user:String,action:String,entity:String,id:Long?=null,details:String=""){writableDatabase.insert("audit",null,ContentValues().apply{put("username",user);put("action",action);put("entity",entity);if(id!=null)put("entity_id",id);put("details",details);put("created_at",now())})}
    fun scalar(sql:String)=readableDatabase.rawQuery(sql,null).use{if(it.moveToFirst())it.getInt(0)else 0}
    fun topGroups(sql:String):String=readableDatabase.rawQuery(sql,null).use{c->val lines=mutableListOf<String>();while(c.moveToNext())lines.add("${c.getString(0)}: ${c.getInt(1)}");lines.joinToString("\n")}
    fun employeeAnalysisSummary(employeeId:Long):String=readableDatabase.rawQuery("SELECT COUNT(*),COALESCE(MAX(sample_date),'') FROM analyses WHERE employee_id=? AND deleted=0",arrayOf(employeeId.toString())).use{c->if(c.moveToFirst())"عدد التحاليل المسجلة: ${c.getInt(0)}\nأحدث تاريخ تحليل: ${c.getString(1).ifBlank{"غير محدد"}}" else "لا توجد تحاليل مسجلة"}
    fun integritySummary():String {
        val db=readableDatabase
        val check=db.rawQuery("PRAGMA quick_check",null).use{c->if(c.moveToFirst())c.getString(0) else "لم تُرجع قاعدة البيانات نتيجة"}
        val fkErrors=db.rawQuery("PRAGMA foreign_key_check",null).use{c->var n=0;while(c.moveToNext())n++;n}
        val employees=db.rawQuery("SELECT COUNT(*) FROM employees",null).use{c->if(c.moveToFirst())c.getLong(0) else 0L}
        val analyses=db.rawQuery("SELECT COUNT(*) FROM analyses",null).use{c->if(c.moveToFirst())c.getLong(0) else 0L}
        val active=db.rawQuery("SELECT COUNT(*) FROM analyses WHERE deleted=0",null).use{c->if(c.moveToFirst())c.getLong(0) else 0L}
        val duplicates=db.rawQuery("SELECT COUNT(*) FROM (SELECT employee_id,TRIM(COALESCE(sample_date,'')),COUNT(*) n FROM analyses WHERE deleted=0 AND TRIM(COALESCE(sample_date,''))<>'' GROUP BY employee_id,TRIM(COALESCE(sample_date,'')) HAVING n>1)",null).use{c->if(c.moveToFirst())c.getLong(0) else 0L}
        return "فحص SQLite: $check\nأخطاء العلاقات: $fkErrors\nعدد الموظفين: $employees\nإجمالي سجلات التحاليل: $analyses\nالتحاليل النشطة: $active\nمجموعات التحاليل المتكررة (للمراجعة فقط ولا تُحذف): $duplicates"
    }
    fun employees(q:String="",inactive:Boolean=false):List<Array<String>> {
        val out=mutableListOf<Array<String>>()
        val normalized=q.trim().map { when(it) { '٠'->'0';'١'->'1';'٢'->'2';'٣'->'3';'٤'->'4';'٥'->'5';'٦'->'6';'٧'->'7';'٨'->'8';'٩'->'9'; else->it } }
        val like="%$normalized%"
        val sql="SELECT id,COALESCE(file_no,''),name,COALESCE(job,''),COALESCE(department,''),COALESCE(workplace,''),COALESCE(phone,''),COALESCE(national_id,''),COALESCE(notes,''),COALESCE(gender,'') FROM employees WHERE active=? AND (name LIKE ? OR COALESCE(file_no,'') LIKE ? OR COALESCE(job,'') LIKE ? OR COALESCE(department,'') LIKE ? OR COALESCE(workplace,'') LIKE ? OR COALESCE(phone,'') LIKE ? OR COALESCE(national_id,'') LIKE ? OR COALESCE(region,'') LIKE ? OR COALESCE(entity,'') LIKE ?) ORDER BY CASE WHEN COALESCE(file_no,'')=? AND ?<>'' THEN 0 WHEN COALESCE(file_no,'') LIKE ? AND ?<>'' THEN 1 WHEN name LIKE ? THEN 2 ELSE 3 END, name LIMIT 100"
        readableDatabase.rawQuery(sql,arrayOf(if(inactive)"0" else "1",like,like,like,like,like,like,like,like,like,normalized,normalized+"%",normalized,normalized,like)).use{c->while(c.moveToNext())out.add(Array(10){i->c.getString(i)?:""})}
        return out
    }
    fun saveEmployee(id:Long?,v:List<String>,user:String):Boolean=try{val cv=ContentValues().apply{put("file_no",v[0].ifBlank{null});put("name",v[1]);put("job",v[2]);put("department",v[3]);put("workplace",v[4]);put("phone",v[5]);put("national_id",v[6]);put("notes",v[7]);put("updated_at",now());if(id==null)put("created_at",now())};val n=if(id==null)writableDatabase.insertOrThrow("employees",null,cv).also{audit(user,"إضافة","موظف",it,"تم إنشاء سجل موظف") }.toInt() else writableDatabase.update("employees",cv,"id=?",arrayOf(id.toString())).also{audit(user,"تعديل","موظف",id,"تم تحديث سجل موظف") };n>0}catch(_:Exception){false}
    fun setEmployeeActive(id:Long,active:Boolean,user:String){writableDatabase.execSQL("UPDATE employees SET active=? WHERE id=?",arrayOf(if(active)1 else 0,id));audit(user,if(active)"استعادة" else "حذف منطقي","موظف",id)}
    fun addDemoData(user:String):Int {
        val db=writableDatabase
        val demoTag="DEMO:2.4.9"
        val already=db.rawQuery("SELECT COUNT(*) FROM employees WHERE source_serial=?",arrayOf(demoTag)).use{it.moveToFirst() && it.getInt(0)>0}
        if(already) return 0
        val people=listOf(
            arrayOf("DEMO-001","أحمد محمد علي","إداري","الشؤون الإدارية","القاهرة","01000000001","29001011234567","ذكر"),
            arrayOf("DEMO-002","منى السيد حسن","أخصائي","الإدارة الطبية","الجيزة","01000000002","29505221234567","أنثى"),
            arrayOf("DEMO-003","محمود إبراهيم","فني","المعامل","القليوبية","01000000003","28807151234567","ذكر"),
            arrayOf("DEMO-004","سارة مصطفى","موظف","الموارد البشرية","القاهرة","01000000004","29903151234567","أنثى"),
            arrayOf("DEMO-005","خالد عبد الرحمن","مشرف","الخدمات","الجيزة","01000000005","28511121234567","ذكر")
        )
        var count=0
        db.beginTransaction()
        try {
            people.forEachIndexed { i,p ->
                val cv=ContentValues().apply{put("file_no",p[0]);put("name",p[1]);put("job",p[2]);put("department",p[3]);put("workplace",p[4]);put("phone",p[5]);put("national_id",p[6]);put("gender",p[7]);put("source_serial",demoTag);put("region",p[4]);put("entity",p[3]);put("created_at",now())}
                val id=db.insertOrThrow("employees",null,cv)
                val samples=listOf(
                    arrayOf("صورة دم كاملة","تمت المراجعة","2026-10-01","إيجابي","إيجابي"),
                    arrayOf("فيروسات","تم التحليل","2026-10-08","سلبي","سلبي"),
                    arrayOf("وظائف كبد","قيد الانتظار","2026-10-15","","" )
                )
                samples.forEachIndexed { j,a -> val ac=ContentValues().apply{put("employee_id",id);put("analysis_type",a[0]);put("status",a[1]);put("sample_date",a[2]);put("result",a[3]);put("classification",a[4]);put("notes","بيانات تجريبية غير حقيقية");put("source_serial",demoTag);put("created_at",now())};db.insertOrThrow("analyses",null,ac);count++ }
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        audit(user,"إضافة بيانات تجريبية","بيانات",null,"5 موظفين و15 تحليلًا تجريبيًا")
        return count
    }
    fun removeDemoData(user:String):Int {
        val db=writableDatabase
        val ids=mutableListOf<String>()
        db.rawQuery("SELECT id FROM employees WHERE source_serial='DEMO:2.4.9'",null).use{while(it.moveToNext())ids.add(it.getString(0))}
        if(ids.isEmpty()) return 0
        db.beginTransaction();try{ids.forEach{id->db.delete("analyses","employee_id=? AND source_serial='DEMO:2.4.9'",arrayOf(id));db.delete("employees","id=? AND source_serial='DEMO:2.4.9'",arrayOf(id))};db.setTransactionSuccessful()}finally{db.endTransaction()}
        audit(user,"حذف البيانات التجريبية","بيانات",null,"تم حذف ${ids.size} موظفين تجريبيين فقط")
        return ids.size
    }
    private fun analysisCategoryClause(category:String):String = when(category) {
        "positive" -> "(LOWER(TRIM(COALESCE(a.result,''))) LIKE '%إيجابي%' OR LOWER(TRIM(COALESCE(a.result,''))) LIKE '%موجب%' OR LOWER(TRIM(COALESCE(a.classification,''))) LIKE '%إيجابي%' OR LOWER(TRIM(COALESCE(a.classification,''))) LIKE '%موجب%')"
        "negative" -> "(LOWER(TRIM(COALESCE(a.result,''))) LIKE '%سلبي%' OR LOWER(TRIM(COALESCE(a.result,''))) LIKE '%سالب%' OR LOWER(TRIM(COALESCE(a.classification,''))) LIKE '%سلبي%' OR LOWER(TRIM(COALESCE(a.classification,''))) LIKE '%سالب%')"
        "unspecified" -> "(TRIM(COALESCE(a.result,''))='' AND TRIM(COALESCE(a.classification,''))='')"
        "other" -> "(TRIM(COALESCE(a.result,''))<>'' OR TRIM(COALESCE(a.classification,''))<>'') AND NOT (LOWER(TRIM(COALESCE(a.result,''))) LIKE '%إيجابي%' OR LOWER(TRIM(COALESCE(a.result,''))) LIKE '%موجب%' OR LOWER(TRIM(COALESCE(a.classification,''))) LIKE '%إيجابي%' OR LOWER(TRIM(COALESCE(a.classification,''))) LIKE '%موجب%' OR LOWER(TRIM(COALESCE(a.result,''))) LIKE '%سلبي%' OR LOWER(TRIM(COALESCE(a.result,''))) LIKE '%سالب%' OR LOWER(TRIM(COALESCE(a.classification,''))) LIKE '%سلبي%' OR LOWER(TRIM(COALESCE(a.classification,''))) LIKE '%سالب%')"
        else -> "1=1"
    }
    fun analysesCount(q:String="",employeeId:Long?=null,deleted:Boolean=false,category:String="all"):Long {
        val normalized=q.trim().map { when(it) { '٠'->'0';'١'->'1';'٢'->'2';'٣'->'3';'٤'->'4';'٥'->'5';'٦'->'6';'٧'->'7';'٨'->'8';'٩'->'9'; else->it } }; val like="%$normalized%"
        val sql="SELECT COUNT(*) FROM analyses a JOIN employees e ON e.id=a.employee_id WHERE a.deleted=? AND (? IS NULL OR a.employee_id=?) AND (e.name LIKE ? OR COALESCE(e.file_no,'') LIKE ? OR COALESCE(e.national_id,'') LIKE ? OR COALESCE(e.phone,'') LIKE ? OR COALESCE(e.job,'') LIKE ? OR COALESCE(e.department,'') LIKE ? OR COALESCE(e.workplace,'') LIKE ? OR a.analysis_type LIKE ? OR a.status LIKE ? OR COALESCE(a.sample_date,'') LIKE ? OR COALESCE(a.result_date,'') LIKE ? OR COALESCE(a.result,'') LIKE ? OR COALESCE(a.analyst,'') LIKE ? OR COALESCE(a.legal,'') LIKE ? OR COALESCE(a.clarification,'') LIKE ? OR COALESCE(a.case_details,'') LIKE ?) AND ${analysisCategoryClause(category)}"
        val args=arrayOf(if(deleted)"1" else "0",employeeId?.toString(),employeeId?.toString(),like,like,like,like,like,like,like,like,like,like,like,like,like,like,like)
        return readableDatabase.rawQuery(sql,args).use{if(it.moveToFirst())it.getLong(0) else 0L}
    }
    fun analyses(q:String="",employeeId:Long?=null,deleted:Boolean=false,offset:Int=0,category:String="all",limit:Int=100):List<Array<String>>{
        val out=mutableListOf<Array<String>>();val normalized=q.trim().map { when(it) { '٠'->'0';'١'->'1';'٢'->'2';'٣'->'3';'٤'->'4';'٥'->'5';'٦'->'6';'٧'->'7';'٨'->'8';'٩'->'9'; else->it } }; val like="%$normalized%"
        val sql="SELECT a.id,a.employee_id,e.name,a.analysis_type,a.status,COALESCE(a.sample_date,''),COALESCE(a.result_date,''),COALESCE(a.result,''),COALESCE(a.classification,''),COALESCE(a.notes,'') FROM analyses a JOIN employees e ON e.id=a.employee_id WHERE a.deleted=? AND (? IS NULL OR a.employee_id=?) AND (e.name LIKE ? OR COALESCE(e.file_no,'') LIKE ? OR COALESCE(e.national_id,'') LIKE ? OR COALESCE(e.phone,'') LIKE ? OR COALESCE(e.job,'') LIKE ? OR COALESCE(e.department,'') LIKE ? OR COALESCE(e.workplace,'') LIKE ? OR a.analysis_type LIKE ? OR a.status LIKE ? OR COALESCE(a.sample_date,'') LIKE ? OR COALESCE(a.result_date,'') LIKE ? OR COALESCE(a.result,'') LIKE ? OR COALESCE(a.analyst,'') LIKE ? OR COALESCE(a.legal,'') LIKE ? OR COALESCE(a.clarification,'') LIKE ? OR COALESCE(a.case_details,'') LIKE ?) AND ${analysisCategoryClause(category)} ORDER BY COALESCE(a.sample_date,'') DESC,a.id DESC LIMIT ? OFFSET ?"
        val args=arrayOf(if(deleted)"1" else "0",employeeId?.toString(),employeeId?.toString(),like,like,like,like,like,like,like,like,like,like,like,like,like,like,like,limit.toString(),offset.coerceAtLeast(0).toString())
        readableDatabase.rawQuery(sql,args).use{c->while(c.moveToNext())out.add(Array(10){i->c.getString(i)?:""})};return out
    }
    fun saveAnalysis(id:Long?,emp:Long,v:List<String>,user:String):Boolean=try{val cv=ContentValues().apply{put("employee_id",emp);put("analysis_type",v[0]);put("status",v[1]);put("sample_date",v[2]);put("result_date",v[3]);put("result",v[4]);put("classification",v[5]);put("notes",v[6]);put("updated_at",now());if(id==null)put("created_at",now())};val n=if(id==null)writableDatabase.insertOrThrow("analyses",null,cv).also{audit(user,"إضافة","تحليل",it,"تم إنشاء سجل تحليل") }.toInt()else writableDatabase.update("analyses",cv,"id=? AND deleted=0",arrayOf(id.toString())).also{audit(user,"تعديل","تحليل",id,"تم تحديث سجل تحليل") };n>0}catch(_:Exception){false}
    fun deleteAnalysis(id:Long,user:String,restore:Boolean=false){writableDatabase.execSQL("UPDATE analyses SET deleted=? WHERE id=?",arrayOf(if(restore)0 else 1,id));audit(user,if(restore)"استعادة" else "حذف منطقي","تحليل",id)}
    fun employeeIdByFileNo(fileNo:String):Long? { if(fileNo.isBlank())return null; readableDatabase.rawQuery("SELECT id FROM employees WHERE file_no=? LIMIT 1",arrayOf(fileNo)).use{if(it.moveToFirst())return it.getLong(0)};return null }
    fun saveLegacyEmployee(serial:String,fileNo:String,name:String,job:String,region:String,entity:String,phone:String,nationalId:String,gender:String,user:String,auditEach:Boolean=true):Long? {
        return try {
            var existing=employeeIdByFileNo(fileNo)
            // Recover employees partially imported by older CSV logic: national ID may have been stored in notes.
            if(existing==null && nationalId.isNotBlank()) readableDatabase.rawQuery("SELECT id FROM employees WHERE national_id=? OR notes=? LIMIT 1",arrayOf(nationalId,nationalId)).use{if(it.moveToFirst())existing=it.getLong(0)}
            if(existing!=null){
                writableDatabase.execSQL("UPDATE employees SET file_no=CASE WHEN ?='' THEN file_no ELSE ? END, job=CASE WHEN ?='' THEN job ELSE ? END, department=CASE WHEN ?='' THEN department ELSE ? END, workplace=CASE WHEN ?='' THEN workplace ELSE ? END, phone=CASE WHEN ?='' THEN phone ELSE ? END, national_id=CASE WHEN ?='' THEN national_id ELSE ? END, gender=CASE WHEN ?='' THEN gender ELSE ? END, region=CASE WHEN ?='' THEN region ELSE ? END, entity=CASE WHEN ?='' THEN entity ELSE ? END WHERE id=?",arrayOf(fileNo,fileNo,job,job,region,region,entity,entity,phone,phone,nationalId,nationalId,gender,gender,region,region,entity,entity,existing))
                return existing
            }
            val cv=ContentValues().apply{put("file_no",fileNo.ifBlank{null});put("name",name);put("job",job);put("department",region);put("workplace",entity);put("phone",phone);put("national_id",nationalId);put("gender",gender);put("source_serial",serial);put("created_at",now());put("region",region);put("entity",entity)}
            writableDatabase.insertOrThrow("employees",null,cv).also{if(auditEach)audit(user,"استيراد موظف من الملف التاريخي","موظف",it,"تم استيراد سجل موظف") }
        }catch(_:Exception){null}
    }
    fun saveLegacyAnalysis(employeeId:Long,analysisType:String,sampleDate:String,notes:String,analyst:String,result:String,legal:String,clarification:String,caseDetails:String,serial:String,user:String,auditEach:Boolean=true):Boolean=try{
        // Idempotency is based on the stable source-row serial, never on date alone:
        // one employee may have multiple different analyses on the same day.
        if(serial.isNotBlank()) readableDatabase.rawQuery("SELECT 1 FROM analyses WHERE employee_id=? AND source_serial=? LIMIT 1",arrayOf(employeeId.toString(),serial)).use{if(it.moveToFirst())return false}
        val cv=ContentValues().apply{put("employee_id",employeeId);put("analysis_type",analysisType.ifBlank{"غير محدد"});put("status","تم الاستيراد");put("sample_date",sampleDate);put("notes",notes);put("analyst",analyst);put("result",result);put("legal",legal);put("classification",legal);put("clarification",clarification);put("case_details",caseDetails);put("source_serial",serial);put("created_at",now())}
        val id=writableDatabase.insertOrThrow("analyses",null,cv);if(auditEach)audit(user,"استيراد تحليل تاريخي","تحليل",id,"تم استيراد سجل تاريخي");true
    }catch(_:Exception){false}
    fun userRows():List<Array<String>>{val a=mutableListOf<Array<String>>();readableDatabase.rawQuery("SELECT id,username,role,active FROM users ORDER BY id",null).use{c->while(c.moveToNext())a.add(Array(4){i->c.getString(i)})};return a}
    private val permissionKeys=listOf("employees_view","employees_edit","employees_delete","analyses_view","analyses_edit","analyses_delete","import_export","reports","users_manage","settings_manage","audit_view","backup_restore")
    fun addUser(u:String,h:String,s:String,role:String):Boolean=try{writableDatabase.beginTransaction();writableDatabase.insertOrThrow("users",null,ContentValues().apply{put("username",u);put("password_hash",h);put("salt",s);put("role",role);put("created_at",now())});permissionKeys.forEach{key->writableDatabase.insertOrThrow("user_permissions",null,ContentValues().apply{put("username",u);put("permission",key);put("allowed",if(role=="مدير"||key in listOf("employees_view","analyses_view","reports"))1 else 0)})};writableDatabase.setTransactionSuccessful();true}catch(_:Exception){false}finally{try{writableDatabase.endTransaction()}catch(_:Exception){}}
    fun permissions(user:String):Map<String,Boolean>{val m=mutableMapOf<String,Boolean>();readableDatabase.rawQuery("SELECT permission,allowed FROM user_permissions WHERE username=?",arrayOf(user)).use{while(it.moveToNext())m[it.getString(0)]=it.getInt(1)==1};return m}
    fun setPermission(user:String,key:String,allowed:Boolean){writableDatabase.insertWithOnConflict("user_permissions",null,ContentValues().apply{put("username",user);put("permission",key);put("allowed",if(allowed)1 else 0)},SQLiteDatabase.CONFLICT_REPLACE)}
    fun permissionNames()=permissionKeys
    fun issueActivationCode(role:String,creator:String):String{
        val alphabet="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";val random=SecureRandom();val code=(1..12).map{alphabet[random.nextInt(alphabet.length)]}.joinToString("");val digest=MessageDigest.getInstance("SHA-256").digest(code.toByteArray(Charsets.UTF_8));val key=Base64.encodeToString(digest,Base64.NO_WRAP);writableDatabase.insertOrThrow("activation_codes",null,ContentValues().apply{put("code_hash",key);put("role",role);put("created_by",creator);put("created_at",now());put("used",0)});audit(creator,"إنشاء كود تفعيل","مستخدم",null,"الدور: $role");return code
    }
    fun activationCodeRole(code:String):String? {
        val digest=MessageDigest.getInstance("SHA-256").digest(code.trim().uppercase(Locale.ROOT).toByteArray(Charsets.UTF_8))
        val key=Base64.encodeToString(digest,Base64.NO_WRAP)
        return readableDatabase.rawQuery("SELECT role FROM activation_codes WHERE code_hash=? AND used=0",arrayOf(key)).use{if(it.moveToFirst())it.getString(0) else null}
    }
    fun redeemActivationCode(code:String,u:String,p:String):Boolean{
        val digest=MessageDigest.getInstance("SHA-256").digest(code.trim().uppercase(Locale.ROOT).toByteArray(Charsets.UTF_8));val key=Base64.encodeToString(digest,Base64.NO_WRAP);val dbx=writableDatabase;return try{dbx.beginTransaction();var assignedRole:String?=null;dbx.rawQuery("SELECT role FROM activation_codes WHERE code_hash=? AND used=0",arrayOf(key)).use{if(it.moveToFirst())assignedRole=it.getString(0)};if(assignedRole==null)throw IllegalArgumentException("كود التفعيل غير صحيح أو سبق استخدامه");val salt=ByteArray(16).also{SecureRandom().nextBytes(it)};dbx.insertOrThrow("users",null,ContentValues().apply{put("username",u);put("password_hash",hash(p,salt));put("salt",Base64.encodeToString(salt,Base64.NO_WRAP));put("role",assignedRole);put("created_at",now())});permissionKeys.forEach{keyName->dbx.insertOrThrow("user_permissions",null,ContentValues().apply{put("username",u);put("permission",keyName);put("allowed",if(assignedRole=="مدير"||keyName in listOf("employees_view","analyses_view","reports"))1 else 0)})};val changed=dbx.update("activation_codes",ContentValues().apply{put("used",1)},"code_hash=? AND used=0",arrayOf(key));if(changed!=1)throw IllegalStateException("تم استخدام الكود بالفعل");dbx.setTransactionSuccessful();true}catch(_:Exception){false}finally{dbx.endTransaction()}
    }

    fun activeRole(u:String):String?{readableDatabase.rawQuery("SELECT role FROM users WHERE username=? AND active=1",arrayOf(u)).use{if(it.moveToFirst())return it.getString(0)};return null}
    fun authenticate(u:String,p:String):String?{readableDatabase.rawQuery("SELECT password_hash,salt,role FROM users WHERE username=? AND active=1",arrayOf(u)).use{if(it.moveToFirst()){val h=hash(p,Base64.decode(it.getString(1),Base64.NO_WRAP));return if(MessageDigest.isEqual(h.toByteArray(),it.getString(0).toByteArray()))it.getString(2)else null}};return null}
    fun changePassword(u:String,p:String){val s=ByteArray(16).also{SecureRandom().nextBytes(it)};writableDatabase.update("users",ContentValues().apply{put("salt",Base64.encodeToString(s,Base64.NO_WRAP));put("password_hash",hash(p,s))},"username=?",arrayOf(u))}
    fun auditRows():List<String>{val a=mutableListOf<String>();readableDatabase.rawQuery("SELECT created_at,COALESCE(username,''),action,COALESCE(entity,''),COALESCE(details,'') FROM audit ORDER BY id DESC LIMIT 500",null).use{while(it.moveToNext())a.add((0..4).joinToString(" | "){i->it.getString(i)?:""})};return a}
    fun exportFilteredAnalyses(query:String="",fromDate:String="",toDate:String="",region:String="",entity:String="",analysisType:String="",status:String="",category:String="all"):String {
        val sql="SELECT COALESCE(e.file_no,''),e.name,COALESCE(e.region,''),COALESCE(e.entity,''),a.analysis_type,a.status,COALESCE(a.sample_date,''),COALESCE(a.result_date,''),COALESCE(a.result,''),COALESCE(a.classification,''),COALESCE(a.analyst,''),COALESCE(a.legal,''),COALESCE(a.clarification,''),COALESCE(a.case_details,''),COALESCE(a.notes,'') FROM analyses a JOIN employees e ON e.id=a.employee_id WHERE a.deleted=0 AND (?='' OR a.sample_date>=?) AND (?='' OR a.sample_date<=?) AND (?='' OR e.region LIKE ?) AND (?='' OR e.entity LIKE ?) AND (?='' OR a.analysis_type LIKE ?) AND (?='' OR a.status=?) AND (?='' OR e.name LIKE ? OR COALESCE(e.file_no,'') LIKE ? OR COALESCE(e.national_id,'') LIKE ? OR COALESCE(e.phone,'') LIKE ? OR COALESCE(a.result,'') LIKE ? OR COALESCE(a.analyst,'') LIKE ?) AND ${analysisCategoryClause(category)} ORDER BY a.sample_date DESC,a.id DESC"
        val q="%$query%";val args=arrayOf(fromDate,fromDate,toDate,toDate,region,"%$region%",entity,"%$entity%",analysisType,"%$analysisType%",status,status,query,q,q,q,q,q,q)
        val header="رقم الملف,اسم الموظف,المنطقة,الجهة,نوع التحليل,الحالة,تاريخ العينة,تاريخ النتيجة,النتيجة,التصنيف,جهة إجراء التحليل,قانونية,توضيح,تفاصيل الحالة,ملاحظات"
        val out=StringBuilder("\uFEFF$header\n")
        readableDatabase.rawQuery(sql,args).use { c -> while(c.moveToNext()) out.append((0 until c.columnCount).joinToString(","){i->"\""+(c.getString(i)?:"").replace("\"","\"\"")+"\""}).append('\n') }
        return out.toString()
    }
    fun exportCsv(table:String):String { val (sql,header)=if(table=="employees") Pair("SELECT COALESCE(file_no,''),name,COALESCE(job,''),COALESCE(department,''),COALESCE(workplace,''),COALESCE(phone,''),COALESCE(national_id,''),COALESCE(gender,''),COALESCE(notes,''),COALESCE(source_serial,''),COALESCE(region,''),COALESCE(entity,'') FROM employees ORDER BY id","رقم الملف,الاسم,الوظيفة,الإدارة,جهة العمل,الهاتف,الرقم القومي,النوع,ملاحظات,المسلسل الأصلي,المنطقة,الجهة") else Pair("SELECT e.file_no,e.name,a.analysis_type,a.status,a.sample_date,a.result_date,a.result,a.classification,a.notes,COALESCE(a.analyst,''),COALESCE(a.legal,''),COALESCE(a.clarification,''),COALESCE(a.case_details,''),COALESCE(a.source_serial,'') FROM analyses a JOIN employees e ON e.id=a.employee_id ORDER BY a.id","رقم الملف,اسم الموظف,نوع التحليل,الحالة,تاريخ العينة,تاريخ النتيجة,النتيجة,التصنيف,ملاحظات,جهة إجراء التحليل,قانونية,توضيح,تفاصيل الحالة,المسلسل الأصلي")
        val b=StringBuilder("\uFEFF$header\n");readableDatabase.rawQuery(sql,null).use{c->while(c.moveToNext())b.append((0 until c.columnCount).joinToString(","){i->"\""+(c.getString(i)?:"").replace("\"","\"\"")+"\""}).append('\n')};return b.toString() }
}
private fun hash(password:String,salt:ByteArray):String{val spec=PBEKeySpec(password.toCharArray(),salt,180000,256);val out=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded;spec.clearPassword();return Base64.encodeToString(out,Base64.NO_WRAP)}

class MainActivity:AppCompatActivity(){
    private lateinit var db:AppDb;private var username="";private var role="";private lateinit var root:LinearLayout;private lateinit var body:LinearLayout;private var accent:Int=Palette.blue; private lateinit var theme:UiTheme; private var activeNavIndex=0
    private val screenHistory = java.util.ArrayDeque<Pair<LinearLayout,LinearLayout>>()
    private var suppressNextHistory=false
    private val createBackup=registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")){u->if(u!=null)writeBackup(u)}
    private val openBackup=registerForActivityResult(ActivityResultContracts.GetContent()){u->if(u!=null)readBackup(u)}
    private val openPlainDatabase=registerForActivityResult(ActivityResultContracts.GetContent()){u->if(u!=null)importPlainDatabase(u)}
    private val createCsv=registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")){u->if(u!=null)writeUri(u,pendingCsv)}
    private val openCsv=registerForActivityResult(ActivityResultContracts.GetContent()){u->if(u!=null)importEmployees(u)}
    private val createPdf=registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")){u->if(u!=null)writePdf(u)}
    private val createXlsx=registerForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){u->if(u!=null)writeXlsx(u)}
    private val openXlsx=registerForActivityResult(ActivityResultContracts.GetContent()){u->if(u!=null)importXlsx(u)}
    private var pendingXlsxTable="employees"
    private var pendingCsv=""
    private var pendingPdf=""
    private var backupPassphrase=""
    private val idleHandler=Handler(Looper.getMainLooper())
    private val idleLock=Runnable{if(username.isNotBlank()){db.audit(username,"قفل تلقائي بسبب الخمول","الأمان");username="";role="";screenHistory.clear();login();toast("تم قفل التطبيق تلقائيًا بسبب عدم النشاط")}}
    private lateinit var databaseKey:String
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        val uiPrefs=getSharedPreferences("ui",0)
        if(!uiPrefs.contains("theme_index")) uiPrefs.edit().putInt("theme_index",1).apply()
        theme=loadUiTheme();accent=theme.accent;window.statusBarColor=theme.bg;window.navigationBarColor=theme.bg
        onBackPressedDispatcher.addCallback(this, object:OnBackPressedCallback(true){
            override fun handleOnBackPressed(){
                if(restorePreviousScreen()) return
                else if(username.isNotBlank()){
                    AlertDialog.Builder(this@MainActivity).setTitle("الخروج من التطبيق")
                        .setMessage("هل تريد إغلاق برنامج تحاليل العاملين؟")
                        .setPositiveButton("خروج"){_,_->finish()}.setNegativeButton("إلغاء",null).show()
                }else finish()
            }
        })
        SQLiteDatabase.loadLibs(this);databaseKey=DatabaseSecurity.loadOrCreateKey(this);DatabaseSecurity.migratePlainDatabase(this,databaseKey);db=AppDb(this,databaseKey);if(db.userRows().isEmpty())firstAdmin()else login()
    }
    override fun onUserInteraction(){super.onUserInteraction();if(::db.isInitialized && username.isNotBlank()){idleHandler.removeCallbacks(idleLock);val minutes=getSharedPreferences("security",0).getInt("auto_lock_minutes",5);if(minutes>0)idleHandler.postDelayed(idleLock,minutes*60_000L)}}
    private fun restorePreviousScreen():Boolean {
        if(screenHistory.isEmpty()) return false
        val previous=screenHistory.removeLast()
        root=previous.first
        body=previous.second
        setContentView(root)
        return true
    }
    private fun cancelCurrentScreen(){
        if(!restorePreviousScreen()) {
            if(username.isNotBlank()) home() else login()
        }
    }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun loadUiTheme():UiTheme {
        val prefs=getSharedPreferences("ui",0); val base=UI_THEMES[prefs.getInt("theme_index",0).coerceIn(0,UI_THEMES.lastIndex)]
        fun color(key:String,default:Int):Int { val raw=prefs.getString(key,null) ?: return default; return try { Color.parseColor(raw) } catch(_:Exception) { default } }
        return base.copy(accent=color("custom_accent",base.accent),bg=color("custom_bg",base.bg),ink=color("custom_ink",base.ink))
    }
    private fun saveTheme(index:Int){getSharedPreferences("ui",0).edit().putInt("theme_index",index.coerceIn(0,UI_THEMES.lastIndex)).apply();theme=loadUiTheme();accent=theme.accent;window.statusBarColor=theme.bg;window.navigationBarColor=theme.bg}
    private fun text(s:String,size:Float=14f,color:Int=theme.ink,bold:Boolean=false):TextView=TextView(this).apply{text=s;textSize=size*getSharedPreferences("ui",0).getFloat("font_scale",1f);setTextColor(color);typeface=Typeface.create(if(bold)"sans-serif-medium" else "sans-serif",if(bold)Typeface.BOLD else Typeface.NORMAL);gravity=Gravity.RIGHT;textDirection=View.TEXT_DIRECTION_RTL;textAlignment=View.TEXT_ALIGNMENT_VIEW_START;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(dp(4),dp(5),dp(4),dp(5))}
    private fun column():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
    private fun page(title:String,subtitle:String=""){
        activeNavIndex=when { title.contains("موظف")||title.contains("الموظفون") -> 1; title.contains("تحليل")||title.contains("التحاليل") -> 2; title.contains("تقرير")||title.contains("مركز البيانات")||title.contains("استيراد")||title.contains("تصدير") -> 3; title.contains("إعدادات") -> 4; else -> 0 }
        if(::root.isInitialized && !suppressNextHistory) screenHistory.addLast(root to body)
        suppressNextHistory=false
        root=column().apply{setBackgroundColor(theme.bg)}
        val header=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL; gravity=Gravity.RIGHT
            setPadding(dp(22),dp(22),dp(22),dp(25))
            background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(0xFF102B4A.toInt(),0xFF126B83.toInt(),theme.accent)).apply{
                cornerRadii=floatArrayOf(0f,0f,dp(30).toFloat(),dp(30).toFloat(),dp(30).toFloat(),dp(30).toFloat(),0f,0f)
            }
        }
        val brand=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
        val mark=TextView(this).apply{text="✚";textSize=22f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(0x33FFFFFF)};layoutParams=LinearLayout.LayoutParams(dp(46),dp(46))}
        val brandText=column().apply{addView(text("منظومة تحاليل العاملين",13f,0xFFE7F4FA.toInt(),true));addView(text("إدارة ذكية • بيانات محمية • تشغيل محلي",10.5f,0xFFC5DCE8.toInt()))}
        brand.addView(mark);val gap=View(this);brand.addView(gap,LinearLayout.LayoutParams(dp(10),1));brand.addView(brandText);header.addView(brand)
        val titleView=text(title,25f,Color.WHITE,true).apply{setPadding(0,dp(17),0,dp(2))};header.addView(titleView)
        if(subtitle.isNotBlank())header.addView(text(subtitle,13f,0xFFE1EFEB.toInt()))
        root.addView(header)
        val scroll=ScrollView(this).apply{clipToPadding=false;isFillViewport=true}
        body=column().apply{setPadding(dp(16),dp(16),dp(16),dp(28))}
        scroll.addView(body);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        if(username.isNotBlank()) {
            val nav=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(dp(7),dp(7),dp(7),dp(7));setBackgroundColor(theme.card);elevation=dp(10).toFloat() }
            val items=listOf("الرئيسية" to "⌂","الموظفون" to "♙","التحاليل" to "✚","Excel" to "⇄","الإعدادات" to "⚙")
            items.forEachIndexed { index,item ->
                val selected=index==activeNavIndex
                val b=TextView(this).apply { text="${item.second}\n${item.first}";gravity=Gravity.CENTER;textSize=10.5f;typeface=Typeface.create("sans-serif-medium",Typeface.BOLD);setTextColor(if(selected)theme.accent else theme.muted);textDirection=View.TEXT_DIRECTION_RTL;textAlignment=View.TEXT_ALIGNMENT_CENTER;contentDescription=item.first;setPadding(dp(2),dp(5),dp(2),dp(5));if(selected)background=GradientDrawable().apply{cornerRadius=dp(12).toFloat();setColor(theme.accent and 0x18FFFFFF)};isClickable=true;isFocusable=true;minimumHeight=dp(48);setOnClickListener { when(index){0->home();1->employees();2->analyses();3->exports();4->settings()} } }
                nav.addView(b,LinearLayout.LayoutParams(0,dp(55),1f))
            }
            root.addView(nav,LinearLayout.LayoutParams(-1,-2))
        }
        // Android 15 enforces edge-to-edge for targetSdk 35. Apply system-bar insets
        // to every newly-created screen root so headers and bottom navigation remain tappable.
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        val lightSystemBars = Color.luminance(theme.bg) > 0.5f
        WindowInsetsControllerCompat(window, root).isAppearanceLightStatusBars = lightSystemBars
        WindowInsetsControllerCompat(window, root).isAppearanceLightNavigationBars = lightSystemBars
        setContentView(root)
    }
    private fun card(title:String,desc:String="",action:(()->Unit)?=null){
        val icon=when{title.contains("موظف")||title.contains("الموظفين")||title.contains("إجمالي الموظفين")->"👥";title.contains("تحليل")||title.contains("التحاليل")||title.contains("إيجابي")||title.contains("سلبي")->"🧪";title.contains("تقارير")||title.contains("تصدير")||title.contains("استيراد")->"📊";title.contains("مستخدم")||title.contains("صلاحيات")->"🛡️";title.contains("إعدادات")||title.contains("أمان")||title.contains("نسخ")->"⚙️";title.contains("عمليات")->"📋";title.contains("مرحبًا")||title.contains("حساب المدير")->"🔬";else->"✦"}
        val c=MaterialCardView(this).apply{
            radius=dp(24).toFloat();cardElevation=dp(if(action!=null)4 else 2).toFloat()
            setCardBackgroundColor(theme.card);strokeColor=theme.shadow;strokeWidth=dp(1)
            if(action!=null){setOnClickListener{action()};isClickable=true;isFocusable=true}
        }
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(dp(16),dp(15),dp(16),dp(15))}
        val iconBox=TextView(this).apply{text=icon;textSize=21f;gravity=Gravity.CENTER;setTextColor(theme.accent);background=GradientDrawable().apply{shape=GradientDrawable.RECTANGLE;cornerRadius=dp(15).toFloat();setColor(theme.accent and 0x22FFFFFF)};layoutParams=LinearLayout.LayoutParams(dp(50),dp(50))}
        row.addView(iconBox)
        val content=column().apply{setPadding(dp(12),0,dp(8),0);addView(text(title,16f,theme.ink,true));if(desc.isNotBlank())addView(text(desc,12.5f,theme.muted))}
        row.addView(content,LinearLayout.LayoutParams(0,-2,1f))
        if(action!=null)row.addView(text("‹",27f,theme.accent,true))
        c.addView(row);val lp=LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(12);body.addView(c,lp)
    }
    private fun btn(label:String,action:()->Unit)=btn(label,action,false)
    private fun btn(label:String,action:()->Unit,secondary:Boolean){val symbol=when{label.contains("بحث")||label.contains("استعلام")->"⌕  ";label.contains("إضافة")||label.contains("إنشاء")->"＋  ";label.contains("حفظ")||label.contains("تأكيد")->"✓  ";label.contains("حذف")||label.contains("إلغاء")->"✕  ";label.contains("استيراد")||label.contains("تصدير")->"⇄  ";label.contains("نسخة")||label.contains("استعادة")->"▣  ";label.contains("بصمة")->"◉  ";label.contains("عودة")||label.contains("رجوع")->"‹  ";else->"◆  "};val b=MaterialButton(this).apply{text=symbol+label;textSize=14.5f;typeface=Typeface.create("sans-serif-medium",Typeface.BOLD);cornerRadius=dp(17);insetTop=dp(2);insetBottom=dp(2);setOnClickListener{action()};if(secondary){setBackgroundColor(theme.card);setTextColor(theme.accent)}else{setBackgroundColor(accent);setTextColor(Color.WHITE)}};val lp=LinearLayout.LayoutParams(-1,dp(52));lp.bottomMargin=dp(9);body.addView(b,lp)}
    private fun input(hint:String,value:String="",multi:Boolean=false):EditText{val e=EditText(this).apply{this.hint=hint;setText(value);textSize=15f;setTextColor(theme.ink);setHintTextColor(theme.muted);layoutDirection=View.LAYOUT_DIRECTION_RTL;textDirection=View.TEXT_DIRECTION_FIRST_STRONG;textAlignment=View.TEXT_ALIGNMENT_VIEW_START;gravity=if(multi)Gravity.TOP or Gravity.RIGHT else Gravity.CENTER_VERTICAL or Gravity.RIGHT;maxLines=if(multi)5 else 1;isSingleLine=!multi;setPadding(dp(14),dp(10),dp(14),dp(10));background=GradientDrawable().apply{setColor(theme.card);cornerRadius=dp(12).toFloat();setStroke(dp(1),theme.shadow)};if(multi)minLines=3};val lp=LinearLayout.LayoutParams(-1,if(multi)dp(100) else dp(52));lp.bottomMargin=dp(9);body.addView(e,lp);return e}
    private fun firstAdmin(){page("مرحبًا بك في تحاليل العاملين","إنشاء حساب المدير لأول مرة");card("حساب المدير الرئيسي","سيُحفظ محليًا على هذا الهاتف. اختر كلمة مرور قوية.");val u=input("اسم المستخدم","admin");val p=input("كلمة المرور — 8 أحرف على الأقل");val p2=input("تأكيد كلمة المرور");btn("إنشاء حساب المدير"){if(u.text.isBlank()||p.text.length<8||p.text.toString()!=p2.text.toString()){toast("تحقق من اسم المستخدم وكلمة المرور والتأكيد");return@btn};val salt=ByteArray(16).also{SecureRandom().nextBytes(it)};if(db.addUser(u.text.toString().trim(),hash(p.text.toString(),salt),Base64.encodeToString(salt,Base64.NO_WRAP),"مدير")){username=u.text.toString().trim();role="مدير";db.audit(username,"إنشاء حساب","مستخدم");home()}else toast("تعذر إنشاء الحساب")}}
    private fun login(){
        screenHistory.clear();suppressNextHistory=true;page("تحاليل العاملين","نظام إدارة ملفات الموظفين والتحاليل الطبية")
        val logo=TextView(this).apply{text="⚕  🧪";textSize=42f;gravity=Gravity.CENTER;setTextColor(theme.accent);setPadding(0,dp(18),0,dp(8))};body.addView(logo,LinearLayout.LayoutParams(-1,-2))
        card("مرحبًا بعودتك","منصة آمنة لإدارة الموظفين وسجلات التحاليل — تعمل محليًا دون إنترنت")
        val savedBioUser=getSharedPreferences("security",0).getString("biometric_user","").orEmpty()
        if(savedBioUser.isNotBlank()) btn("الدخول بالبصمة / القياسات الحيوية"){biometricLogin(savedBioUser)}
        val u=input("اسم المستخدم");val p=input("كلمة المرور");p.inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        btn("تفعيل حساب جديد بكود المدير"){activationDialog()}
        btn("دخول آمن إلى النظام"){val r=db.authenticate(u.text.toString().trim(),p.text.toString());if(r!=null){username=u.text.toString().trim();role=r;db.audit(username,"تسجيل دخول","النظام");home();onUserInteraction()}else toast("اسم المستخدم أو كلمة المرور غير صحيحة")}
        card("حماية وخصوصية","قاعدة البيانات مشفرة ومحفوظة على هذا الجهاز")
    }
    private fun home(){
        screenHistory.clear();suppressNextHistory=true
        page("تحاليل العاملين","نظام إدارة ملفات الموظفين والتحاليل")
        val ec=db.scalar("SELECT COUNT(*) FROM employees WHERE active=1")
        val ac=db.scalar("SELECT COUNT(*) FROM analyses WHERE deleted=0")
        val month=db.scalar("SELECT COUNT(*) FROM analyses WHERE deleted=0 AND substr(COALESCE(sample_date,''),1,7)=strftime('%Y-%m','now','localtime')")
        val year=db.scalar("SELECT COUNT(*) FROM analyses WHERE deleted=0 AND substr(COALESCE(sample_date,''),1,4)=strftime('%Y','now','localtime')")
        val waiting=db.scalar("SELECT COUNT(*) FROM analyses WHERE deleted=0 AND status='قيد الانتظار'")
        card("لوحة المؤشرات","$ec موظف نشط  •  $ac تحليل مسجل  •  $month تحليل هذا الشهر  •  $year تحليل هذا العام  •  $waiting قيد الانتظار",::dashboard)
        if(can("employees_view"))card("إدارة الموظفين","إضافة وتعديل وبحث واستعادة السجلات",::employees)
        if(can("analyses_view"))card("سجل التحاليل","إضافة وتعديل ومراجعة النتائج",::analyses)
        if(can("import_export")||can("reports"))card("التقارير والاستيراد والتصدير","Excel وCSV وتقارير PDF قابلة للطباعة",::exports)
        if(can("users_manage"))card("المستخدمون والصلاحيات","إضافة حسابات وتخصيص صلاحيات كل مستخدم",::users)
        if(can("settings_manage")||can("backup_restore"))card("الإعدادات والأمان","تغيير كلمة المرور والنسخ الاحتياطي",::settings)
        if(can("audit_view"))card("سجل العمليات","مراجعة العمليات المسجلة",::audit)
        btn("تسجيل الخروج",{idleHandler.removeCallbacks(idleLock);db.audit(username,"تسجيل خروج","النظام");username="";role="";screenHistory.clear();login()},true)
    }
    private fun dashboard(){
        if(!requirePermission("analyses_view") && !requirePermission("employees_view"))return
        page("لوحة المؤشرات والإحصائيات","تحليل تفاعلي لبيانات الموظفين والتحاليل المسجلة محليًا")
        val activeEmployees=db.scalar("SELECT COUNT(*) FROM employees WHERE active=1")
        val inactiveEmployees=db.scalar("SELECT COUNT(*) FROM employees WHERE active=0")
        val totalAnalyses=db.scalar("SELECT COUNT(*) FROM analyses WHERE deleted=0")
        val thisMonth=db.scalar("SELECT COUNT(*) FROM analyses WHERE deleted=0 AND substr(COALESCE(sample_date,''),1,7)=strftime('%Y-%m','now','localtime')")
        val thisYear=db.scalar("SELECT COUNT(*) FROM analyses WHERE deleted=0 AND substr(COALESCE(sample_date,''),1,4)=strftime('%Y','now','localtime')")
        if(can("employees_view"))card("إجمالي الموظفين","نشط: $activeEmployees  •  غير نشط: $inactiveEmployees",::employees)
        if(can("analyses_view")){
            card("إجمالي التحاليل","$totalAnalyses سجل تحليل — اضغط لعرض السجل",::analyses)
            card("النشاط الزمني","هذا الشهر: $thisMonth  •  هذا العام: $thisYear",::analyses)
            val positive=db.scalar("SELECT COUNT(*) FROM analyses a WHERE a.deleted=0 AND ${analysisCategoryClauseForDashboard("positive")}")
            val negative=db.scalar("SELECT COUNT(*) FROM analyses a WHERE a.deleted=0 AND ${analysisCategoryClauseForDashboard("negative")}")
            val other=db.scalar("SELECT COUNT(*) FROM analyses a WHERE a.deleted=0 AND ${analysisCategoryClauseForDashboard("other")}")
            val unspecified=db.scalar("SELECT COUNT(*) FROM analyses a WHERE a.deleted=0 AND ${analysisCategoryClauseForDashboard("unspecified")}")
            card("توزيع نتائج التحاليل","إيجابي: $positive  •  سلبي: $negative  •  أخرى: $other  •  غير محدد: $unspecified")
            card("عرض التحاليل الإيجابية","عدد السجلات: $positive",{analysisResults("",null,"positive",0)})
            card("عرض التحاليل السلبية","عدد السجلات: $negative",{analysisResults("",null,"negative",0)})
            card("عرض النتائج الأخرى","عدد السجلات: $other",{analysisResults("",null,"other",0)})
            card("عرض النتائج غير المحددة","عدد السجلات: $unspecified",{analysisResults("",null,"unspecified",0)})
            val waiting=db.scalar("SELECT COUNT(*) FROM analyses WHERE deleted=0 AND status='قيد الانتظار'")
            val received=db.scalar("SELECT COUNT(*) FROM analyses WHERE deleted=0 AND status='تم الاستلام'")
            val completed=db.scalar("SELECT COUNT(*) FROM analyses WHERE deleted=0 AND status='تم التحليل'")
            val reviewed=db.scalar("SELECT COUNT(*) FROM analyses WHERE deleted=0 AND status='تمت المراجعة'")
            card("موقف تنفيذ التحاليل","قيد الانتظار: $waiting  •  تم الاستلام: $received  •  تم التحليل: $completed  •  تمت المراجعة: $reviewed",::analyses)
            val topTypes=db.topGroups("SELECT COALESCE(NULLIF(analysis_type,''),'غير محدد'),COUNT(*) n FROM analyses WHERE deleted=0 GROUP BY 1 ORDER BY n DESC LIMIT 7")
            if(topTypes.isNotBlank())card("أكثر أنواع التحاليل تداولًا","$topTypes\n\nيمكن استخدام سجل التحاليل للبحث عن نوع محدد")
        }
        if(can("employees_view")){
            val topRegions=db.topGroups("SELECT COALESCE(NULLIF(region,''),NULLIF(department,''),'غير محدد'),COUNT(*) n FROM employees WHERE active=1 GROUP BY 1 ORDER BY n DESC LIMIT 7")
            if(topRegions.isNotBlank())card("توزيع الموظفين حسب المنطقة / الإدارة",topRegions,::employees)
        }
        if(can("analyses_view") && can("reports"))btn("الانتقال إلى التقارير والتصدير",::exports)
        btn("العودة للرئيسية",::home,true)
    }
    private fun analysisCategoryClauseForDashboard(category:String):String = when(category){
        "positive" -> "(LOWER(TRIM(COALESCE(a.result,''))) LIKE '%إيجابي%' OR LOWER(TRIM(COALESCE(a.result,''))) LIKE '%موجب%' OR LOWER(TRIM(COALESCE(a.classification,''))) LIKE '%إيجابي%' OR LOWER(TRIM(COALESCE(a.classification,''))) LIKE '%موجب%')"
        "negative" -> "(LOWER(TRIM(COALESCE(a.result,''))) LIKE '%سلبي%' OR LOWER(TRIM(COALESCE(a.result,''))) LIKE '%سالب%' OR LOWER(TRIM(COALESCE(a.classification,''))) LIKE '%سلبي%' OR LOWER(TRIM(COALESCE(a.classification,''))) LIKE '%سالب%')"
        "unspecified" -> "(TRIM(COALESCE(a.result,''))='' AND TRIM(COALESCE(a.classification,''))='')"
        else -> "(TRIM(COALESCE(a.result,''))<>'' OR TRIM(COALESCE(a.classification,''))<>'') AND NOT (LOWER(TRIM(COALESCE(a.result,''))) LIKE '%إيجابي%' OR LOWER(TRIM(COALESCE(a.result,''))) LIKE '%موجب%' OR LOWER(TRIM(COALESCE(a.classification,''))) LIKE '%إيجابي%' OR LOWER(TRIM(COALESCE(a.classification,''))) LIKE '%موجب%' OR LOWER(TRIM(COALESCE(a.result,''))) LIKE '%سلبي%' OR LOWER(TRIM(COALESCE(a.result,''))) LIKE '%سالب%' OR LOWER(TRIM(COALESCE(a.classification,''))) LIKE '%سلبي%' OR LOWER(TRIM(COALESCE(a.classification,''))) LIKE '%سالب%')"
    }
    private fun employees(query:String=""){
        if(!requirePermission("employees_view"))return
        suppressNextHistory=true
        page("إدارة الموظفين","ابحث بالاسم أو برقم الملف للوصول إلى سجل الموظف وتحاليله")
        val q=input("ابحث بالاسم أو اكتب رقم الملف مباشرة",query)
        btn("بحث") { employees(q.text.toString()) }
        btn("مسح البحث",{employees("")},true)
        btn("إضافة موظف جديد",{employeeForm(null)})
        btn("الموظفون المحذوفون واستعادتهم",{inactiveEmployees()},true)
        employeeResults(query)
    }
    private fun employeeResults(q:String){
        if(!requirePermission("employees_view"))return
        try {
            val rows=db.employees(q.trim())
            card("نتائج البحث","${rows.size} سجل${if(rows.size>=100)" — تم عرض أول 100 نتيجة؛ أضف جزءًا من الاسم أو رقم الملف" else ""}")
            rows.forEach{r->card(r[2],"ملف ${r[1]}  •  ${r[4]}  •  ${r[5]}"){employeeDetail(r)}}
            if(rows.isEmpty())card("لا توجد نتائج مطابقة","تحقق من رقم الملف أو جرّب جزءًا من الاسم")
        } catch(e:Exception) { card("تعذر تنفيذ البحث",e.localizedMessage?:"حدث خطأ أثناء قراءة قاعدة البيانات") }
    }
    private fun ageFromEgyptianNationalId(nid:String):Pair<Int?,Boolean?> {
        val id=nid.trim(); if(id.length!=14 || !id.all{it.isDigit()}) return Pair(null,null)
        val century=when(id[0]){'2'->1900;'3'->2000;'4'->2100;else->return Pair(null,null)}
        return try {
            val year=century+id.substring(1,3).toInt(); val month=id.substring(3,5).toInt(); val day=id.substring(5,7).toInt()
            val birth=GregorianCalendar(year,month-1,day).apply{isLenient=false}; birth.time
            val today=GregorianCalendar(); var age=today.get(Calendar.YEAR)-year
            if(today.get(Calendar.MONTH)<month-1 || (today.get(Calendar.MONTH)==month-1 && today.get(Calendar.DAY_OF_MONTH)<day)) age--
            Pair(age.takeIf{it in 0..125}, id[12].digitToInt()%2==1)
        } catch(_:Exception){Pair(null,null)}
    }
    private fun employeeDetail(r:Array<String>){
        if(!requirePermission("employees_view"))return
        page(r[2],"ملف الموظف")
        val (age,isMale)=ageFromEgyptianNationalId(r[7])
        card("بيانات الموظف","الهاتف: ${r[6]}  •  الرقم القومي: ${r[7]}\nالنوع: ${r.getOrElse(9){""}}\nالعمر اليوم: ${age?.let{"$it سنة"}?:"تعذر استخراجه — راجع الرقم القومي"}\nملاحظات: ${r[8]}")
        if(age!=null && isMale==true && age>=60) body.addView(text("⚠ بلغ سن المعاش – مراجعة موقف نهاية الخدمة",16f,0xFFD00000.toInt(),true))
        if(can("analyses_view"))card("ملخص السجل الطبي الإداري",db.employeeAnalysisSummary(r[0].toLong()))
        if(can("employees_edit"))btn("تعديل البيانات"){employeeForm(r)}
        if(can("analyses_view"))btn("عرض تحاليل الموظف"){analysisResults("",r[0].toLong())}
        if(can("analyses_edit"))btn("إضافة تحليل لهذا الموظف"){analysisForm(r[0].toLong(),null)}
        if(can("employees_delete"))btn("حذف الموظف حذفًا منطقيًا",{if(!requirePermission("employees_delete"))return@btn;AlertDialog.Builder(this).setMessage("سيتم إخفاء الموظف مع الاحتفاظ بسجلاته وتحاليله. هل تريد المتابعة؟").setPositiveButton("حذف"){_,_->db.setEmployeeActive(r[0].toLong(),false,username);employees()}.setNegativeButton("إلغاء",null).show()},true)
    }
    private fun employeeForm(old:Array<String>?){if(!requirePermission("employees_edit"))return;page(if(old==null)"إضافة موظف" else "تعديل الموظف","الحقول ذات العلامة * مطلوبة");val f=input("رقم الملف",old?.get(1).orEmpty());val n=input("الاسم بالكامل *",old?.get(2).orEmpty());val j=input("الوظيفة",old?.get(3).orEmpty());val d=input("الإدارة",old?.get(4).orEmpty());val w=input("جهة العمل / المنطقة",old?.get(5).orEmpty());val ph=input("رقم الهاتف",old?.get(6).orEmpty());val nid=input("الرقم القومي",old?.get(7).orEmpty());val no=input("ملاحظات",old?.get(8).orEmpty(),true);btn("حفظ البيانات"){if(!requirePermission("employees_edit"))return@btn;if(n.text.isBlank()){toast("اسم الموظف مطلوب");return@btn};val ok=db.saveEmployee(old?.get(0)?.toLong(),listOf(f,n,j,d,w,ph,nid,no).map{it.text.toString().trim()},username);if(ok){toast("تم حفظ بيانات الموظف");employees()}else toast("تعذر الحفظ؛ تحقق من عدم تكرار رقم الملف")};btn("إلغاء",::cancelCurrentScreen,true)}
    private fun inactiveEmployees(){if(!requirePermission("employees_delete"))return;page("الموظفون المحذوفون","يمكن استعادة السجل دون فقد التحاليل");db.employees("",true).forEach{r->card(r[2],"رقم الملف: ${r[1]}"){AlertDialog.Builder(this).setMessage("استعادة هذا الموظف؟").setPositiveButton("استعادة"){_,_->db.setEmployeeActive(r[0].toLong(),true,username);inactiveEmployees()}.setNegativeButton("إلغاء",null).show()}}}
    private fun analyses(query:String=""){
        if(!requirePermission("analyses_view"))return
        try {
            suppressNextHistory=true
            page("سجل التحاليل","بحث وفلاتر ونتائج مقسمة إلى صفحات")
            val q=input("اكتب الاسم أو رقم الملف للبحث",query)
            btn("بحث برقم الملف أو الاسم"){analyses(q.text.toString())}
            btn("مسح البحث",{analyses("")},true)
            btn("إضافة تحليل جديد"){chooseEmployee()}
            btn("التحاليل المحذوفة واستعادتها",{deletedAnalyses()},true)
            analysisResults(query)
        } catch(e:Exception){toast("تعذر فتح سجل التحاليل: ${e.localizedMessage?:"خطأ غير معروف"}")}
    }
    private fun analysisResults(q:String,emp:Long?=null,category:String="all",offset:Int=0){
        if(!requirePermission("analyses_view"))return
        try{val pageSize=100;val total=db.analysesCount(q.trim(),emp,false,category);val rows=db.analyses(q.trim(),emp,false,offset,category,pageSize)
            val labels=mapOf("all" to "كل النتائج","positive" to "إيجابي","negative" to "سلبي","other" to "نتائج أخرى","unspecified" to "غير محدد")
            card("إجمالي السجلات","$total تحليل — ${labels[category]?:"كل النتائج"}")
            btn("الكل"){analysisResults(q,emp,"all",0)};btn("إيجابي"){analysisResults(q,emp,"positive",0)};btn("سلبي"){analysisResults(q,emp,"negative",0)};btn("أخرى"){analysisResults(q,emp,"other",0)};btn("غير محدد"){analysisResults(q,emp,"unspecified",0)}
            rows.forEach{r->if(r.size>=8)card("${r[2]} — ${r[3]}","${r[4]}  •  العينة: ${r[5]}  •  النتيجة: ${r[7]}"){analysisDetail(r)}}
            val shown=(offset+rows.size).coerceAtMost(total.toInt());card("عرض السجلات","تم عرض $shown من $total")
            if(offset>0)btn("الصفحة السابقة"){analysisResults(q,emp,category,(offset-pageSize).coerceAtLeast(0))}
            if(offset+rows.size<total)btn("تحميل 100 تحليل إضافي"){analysisResults(q,emp,category,offset+pageSize)}
            if(rows.isEmpty())card("لا توجد تحاليل","لا توجد سجلات مطابقة")
        }catch(e:Exception){card("تعذر عرض النتائج",e.localizedMessage?:"حدث خطأ أثناء قراءة سجل التحاليل")}
    }
    private fun chooseEmployee(){if(!requirePermission("analyses_edit"))return;page("اختيار الموظف","ابحث بالاسم أو رقم الملف لتحديد الموظف");val q=input("اسم الموظف أو رقم الملف");btn("بحث عن الموظف"){chooseEmployeeResults(q.text.toString())};chooseEmployeeResults("")}
    private fun chooseEmployeeResults(q:String){if(!requirePermission("analyses_edit"))return;val rows=db.employees(q);card("نتائج اختيار الموظف","${rows.size} موظف${if(rows.size>=100)" — اكتب جزءًا من الاسم أو رقم الملف لتضييق النتائج" else ""}");rows.forEach{r->card(r[2],"رقم الملف: ${r[1]}"){analysisForm(r[0].toLong(),null)}}}
    private fun analysisDetail(r:Array<String>){if(!requirePermission("analyses_view"))return;page("تفاصيل التحليل",r[2]);card(r[3],"الحالة: ${r[4]}\nتاريخ العينة: ${r[5]}\nتاريخ النتيجة: ${r[6]}\nالنتيجة: ${r[7]}\nالتصنيف: ${r[8]}\nملاحظات: ${r[9]}");if(can("analyses_edit"))btn("تعديل التحليل"){analysisForm(r[1].toLong(),r)};if(can("analyses_delete"))btn("حذف التحليل حذفًا منطقيًا",{if(!requirePermission("analyses_delete"))return@btn;db.deleteAnalysis(r[0].toLong(),username);analyses()},true)}
    private fun analysisForm(emp:Long,old:Array<String>?){if(!requirePermission("analyses_edit"))return;val name=if(old!=null)old[2] else db.employees().firstOrNull{it[0]==emp.toString()}?.get(2).orEmpty();page(if(old==null)"إضافة تحليل" else "تعديل التحليل",name);val t=input("نوع التحليل *",old?.get(3).orEmpty());val s=input("الحالة (قيد الانتظار / تم الاستلام / تم التحليل / تمت المراجعة)",old?.get(4).orEmpty().ifBlank{"قيد الانتظار"});val sd=input("تاريخ العينة YYYY-MM-DD",old?.get(5).orEmpty());val rd=input("تاريخ النتيجة YYYY-MM-DD",old?.get(6).orEmpty());val res=input("النتيجة",old?.get(7).orEmpty(),true);val cl=input("التصنيف",old?.get(8).orEmpty().ifBlank{"تأكيدية"});val no=input("ملاحظات",old?.get(9).orEmpty(),true);btn("حفظ التحليل"){if(!requirePermission("analyses_edit"))return@btn;if(t.text.isBlank()){toast("نوع التحليل مطلوب");return@btn};if(db.saveAnalysis(old?.get(0)?.toLong(),emp,listOf(t,s,sd,rd,res,cl,no).map{it.text.toString().trim()},username)){toast("تم الحفظ");analysisResults("",emp)}else toast("تعذر حفظ التحليل")};btn("إلغاء",::cancelCurrentScreen,true)}
    private fun deletedAnalyses(){if(!requirePermission("analyses_delete"))return;page("التحاليل المحذوفة","استعادة السجلات عند الحاجة");db.analyses("",null,true).forEach{r->card("${r[2]} — ${r[3]}","${r[4]}"){AlertDialog.Builder(this).setMessage("استعادة التحليل؟").setPositiveButton("استعادة"){_,_->db.deleteAnalysis(r[0].toLong(),username,true);deletedAnalyses()}.setNegativeButton("إلغاء",null).show()}}}
    private fun exports(){if(!(can("import_export")||can("reports"))){toast("ليس لديك صلاحية");return};page("مركز البيانات والتقارير","استيراد منظم • مراجعة السجلات • تصدير وطباعة")
        card("استيراد واسترداد بيانات Excel","اختر ملف Excel الذي يحتوي بيانات الموظفين أو سجل التحاليل التاريخي. سيُفحص الملف قبل إدخال البيانات، وتبقى السجلات السابقة محفوظة.")
        if(can("import_export")) btn("اختيار ملف Excel للاستيراد",{openXlsx.launch("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")})
        if(can("import_export")) btn("استيراد الموظفين من CSV",{openCsv.launch("text/*")},true)
        if(can("import_export")) btn("استيراد التحاليل التاريخية من CSV",{openCsv.launch("text/*")},true)
        card("تصدير البيانات","أنشئ نسخة Excel أو CSV من بيانات الموظفين أو جميع التحاليل للاحتفاظ بها أو مراجعتها.")
        if(can("import_export")) btn("تصدير الموظفين CSV"){pendingCsv=db.exportCsv("employees");createCsv.launch("employees.csv")}
        if(can("import_export")) btn("تصدير التحاليل CSV"){pendingCsv=db.exportCsv("analyses");createCsv.launch("analyses.csv")}
        if(can("import_export")) btn("تصدير الموظفين Excel XLSX"){pendingXlsxTable="employees";createXlsx.launch("employees.xlsx")}
        if(can("import_export")) btn("تصدير التحاليل Excel XLSX"){pendingXlsxTable="analyses";createXlsx.launch("analyses.xlsx")}
        if(can("reports")) btn("تقارير منفصلة حسب نتيجة التحليل",::categoryReports)
        if(can("reports")) btn("إعداد تقرير تحاليل متقدم بالفلاتر",::advancedReport)
        if(can("reports")) btn("طباعة / حفظ تقرير الموظفين PDF"){pendingPdf=buildPdfText("تقرير بيانات الموظفين",db.exportCsv("employees"));createPdf.launch("employees-report.pdf")}
        if(can("reports")) btn("طباعة / حفظ تقرير التحاليل PDF"){pendingPdf=buildPdfText("تقرير التحاليل",db.exportCsv("analyses"));createPdf.launch("analyses-report.pdf")}
        card("قواعد سلامة الاستيراد","يتعرف النظام على صف العناوين حتى لو لم يكن في أول صف، ويربط التحاليل برقم ملف الموظف. لا تُحذف التحاليل التاريخية بسبب تكرار رقم الملف؛ فلكل موظف عدة تحاليل عبر تواريخ مختلفة. استعادة النسخة الاحتياطية المشفرة عملية مستقلة من الإعدادات.")
    }
    private fun categoryReports(){
        if(!requirePermission("reports"))return
        page("تقارير التحاليل حسب النتيجة","اختر الفئة لمعاينة عدد السجلات ثم تصديرها")
        val cats=listOf("all" to "كل التحاليل","positive" to "الإيجابي","negative" to "السلبي","other" to "النتائج الأخرى","unspecified" to "غير المحدد")
        cats.forEach{(key,label)->
            val count=db.analysesCount(category=key)
            card(label,"عدد السجلات: $count")
            if(can("import_export"))btn("تصدير $label CSV/Excel"){pendingCsv=db.exportFilteredAnalyses(category=key);createCsv.launch("analyses-$key.csv")}
            btn("إنشاء تقرير PDF — $label"){
                val csv=db.exportFilteredAnalyses(category=key)
                pendingPdf=buildPdfText("تقرير $label — عدد السجلات: $count",csv)
                db.audit(username,"إعداد تقرير حسب النتيجة","تقارير",null,"$label: $count")
                createPdf.launch("analyses-$key-report.pdf")
            }
        }
        btn("عودة",::exports,true)
    }
    private fun advancedReport(){
        if(!requirePermission("reports"))return
        page("تقرير التحاليل المتقدم","حدد معايير التقرير؛ اترك أي حقل فارغًا لتجاهله")
        val q=input("بحث: الاسم أو رقم الملف أو البطاقة أو الهاتف أو النتيجة أو جهة إجراء التحليل")
        val from=input("من تاريخ العينة YYYY-MM-DD")
        val to=input("إلى تاريخ العينة YYYY-MM-DD")
        val region=input("المنطقة")
        val entity=input("الجهة")
        val type=input("نوع التحليل")
        val status=input("الحالة (اتركه فارغًا للكل)")
        btn("معاينة عدد السجلات المطابقة"){
            if((from.text.isNotBlank()&&!from.text.matches(Regex("\\d{4}-\\d{2}-\\d{2}")))||(to.text.isNotBlank()&&!to.text.matches(Regex("\\d{4}-\\d{2}-\\d{2}")))){toast("صيغة التاريخ يجب أن تكون YYYY-MM-DD");return@btn}
            val csv=db.exportFilteredAnalyses(q.text.toString().trim(),from.text.toString().trim(),to.text.toString().trim(),region.text.toString().trim(),entity.text.toString().trim(),type.text.toString().trim(),status.text.toString().trim())
            val count=csv.lineSequence().drop(1).count{it.isNotBlank()}
            card("نتيجة المعاينة","عدد التحاليل المطابقة: $count")
        }
        if(can("import_export")) btn("تصدير النتائج المطابقة CSV"){if(from.text.isNotBlank()&&!from.text.toString().matches(Regex("\\d{4}-\\d{2}-\\d{2}"))||to.text.isNotBlank()&&!to.text.toString().matches(Regex("\\d{4}-\\d{2}-\\d{2}"))){toast("اكتب التاريخ بصيغة YYYY-MM-DD");return@btn};if(from.text.isNotBlank()&&to.text.isNotBlank()&&from.text.toString()>to.text.toString()){toast("تاريخ البداية يجب ألا يتجاوز تاريخ النهاية");return@btn};pendingCsv=db.exportFilteredAnalyses(q.text.toString().trim(),from.text.toString().trim(),to.text.toString().trim(),region.text.toString().trim(),entity.text.toString().trim(),type.text.toString().trim(),status.text.toString().trim());createCsv.launch("filtered-analyses.csv")}
        btn("إنشاء تقرير PDF بالفلاتر المحددة"){
            if((from.text.isNotBlank()&&!from.text.matches(Regex("\\d{4}-\\d{2}-\\d{2}")))||(to.text.isNotBlank()&&!to.text.matches(Regex("\\d{4}-\\d{2}-\\d{2}")))){toast("صيغة التاريخ يجب أن تكون YYYY-MM-DD");return@btn}
            if(from.text.isNotBlank()&&to.text.isNotBlank()&&from.text.toString()>to.text.toString()){toast("تاريخ البداية يجب ألا يتجاوز تاريخ النهاية");return@btn}
            val csv=db.exportFilteredAnalyses(q.text.toString().trim(),from.text.toString().trim(),to.text.toString().trim(),region.text.toString().trim(),entity.text.toString().trim(),type.text.toString().trim(),status.text.toString().trim())
            val count=csv.lineSequence().drop(1).count{it.isNotBlank()}
            pendingPdf=buildPdfText("تقرير التحاليل المتقدم — عدد السجلات: $count",csv)
            db.audit(username,"إعداد تقرير تحاليل مفلتر","تقارير",null,"عدد السجلات: $count")
            createPdf.launch("filtered-analyses-report.pdf")
        }
        btn("عودة",::exports,true)
    }
    private fun writeUri(u:Uri,data:String){if(!requirePermission("import_export"))return;try{val out=contentResolver.openOutputStream(u)?:throw IOException("تعذر فتح الملف");out.bufferedWriter(Charsets.UTF_8).use{it.write(data)};db.audit(username,"تصدير ملف CSV","بيانات");toast("تم حفظ الملف بنجاح") }catch(e:Exception){toast("تعذر حفظ الملف: ${e.message}")}}
    private fun importEmployees(u:Uri){
        if(!requirePermission("import_export"))return
        val progress=ProgressDialog.show(this,"جارٍ الاستيراد","يرجى الانتظار؛ لا تغلق التطبيق أثناء معالجة الملف",true,false)
        thread(name="csv-import") {
            var added=0;var skipped=0;var error:String?=null
            try {
                val content=contentResolver.openInputStream(u)?.bufferedReader(Charsets.UTF_8)?.use{it.readText()} ?: throw IOException("تعذر قراءة الملف")
                val records=parseCsvRecords(content).filter{it.any{v->v.isNotBlank()}}
                if(records.isEmpty())throw IOException("الملف فارغ")
                val headerIndex=records.indexOfFirst{r->r.any{it.trim().removePrefix("\uFEFF") in listOf("الاسم","اسم الموظف")} && r.any{it.trim() in listOf("رقم الملف","رقم ملف")}}
                if(headerIndex<0)throw IOException("لم يتم العثور على صف العناوين: الاسم ورقم الملف")
                val headers=records[headerIndex].map{it.trim().removePrefix("\uFEFF")};fun idx(vararg names:String)=headers.indexOfFirst{h->names.any{it==h}}
                val legacy=idx("تاريخ التحليل")>=0 && idx("رقم الملف","رقم ملف")>=0
                if(!legacy && idx("الرقم القومي","رقم البطاقة")<0 && idx("رقم الهاتف")<0 && idx("الوظيفة")<0) {
                    throw IOException("عناوين الأعمدة لا تطابق نموذج الموظفين أو التحاليل التاريخية؛ لم يتم تعديل قاعدة البيانات")
                }
                db.writableDatabase.beginTransaction()
                try {
                    records.drop(headerIndex+1).forEach { row ->
                        fun v(vararg names:String)=idx(*names).let{if(it>=0)row.getOrElse(it){""}.trim() else ""}
                        val name=v("الاسم","اسم الموظف");if(name.isBlank()){skipped++;return@forEach}
                        if(legacy){
                            val emp=db.saveLegacyEmployee(v("م"),v("رقم الملف","رقم ملف"),name,v("الوظيفة"),v("المنطقة"),v("الجهة"),v("رقم الهاتف"),v("رقم البطاقة"),v("النوع"),username,false)
                            if(emp==null){skipped++;return@forEach}
                            val hasAnalysis=listOf("تاريخ التحليل","ملاحظات","القائم بالتحليل","النتيجة","قانونية","توضيح","تفاصيل الحالة").any{v(it).isNotBlank()}
                            if(hasAnalysis){if(db.saveLegacyAnalysis(emp,"غير محدد",v("تاريخ التحليل"),v("ملاحظات"),v("القائم بالتحليل"),v("النتيجة"),v("قانونية"),v("توضيح"),v("تفاصيل الحالة"),v("م"),username,false))added++ else skipped++}else added++
                        } else {
                            val ok=db.saveEmployee(null,listOf(v("رقم الملف","رقم ملف"),name,v("الوظيفة"),v("الإدارة"),v("جهة العمل","المنطقة"),v("رقم الهاتف"),v("رقم البطاقة","الرقم القومي"),v("ملاحظات")),username)
                            if(ok)added++ else skipped++
                        }
                    }
                    db.audit(username,"استيراد بيانات CSV","قاعدة البيانات",null,"المضاف/المعالج: $added؛ المتجاوز: $skipped")
                    db.writableDatabase.setTransactionSuccessful()
                } finally { db.writableDatabase.endTransaction() }
            } catch(e:Exception){error=e.message?:"خطأ غير معروف"}
            runOnUiThread { progress.dismiss(); if(error==null){toast("اكتمل الاستيراد: تمت معالجة $added سجلًا، وتجاوزنا $skipped. لم تُحذف السجلات السابقة.");home()}else toast("تعذر الاستيراد: $error") }
        }
    }
    private fun writeXlsx(uri:Uri){if(!requirePermission("import_export"))return;try{val rows=mutableListOf<List<String>>();val csv=db.exportCsv(pendingXlsxTable).removePrefix("\uFEFF");csv.lineSequence().filter{it.isNotBlank()}.forEach{rows.add(parseCsv(it))};val out=contentResolver.openOutputStream(uri)?:throw IOException("تعذر فتح ملف Excel للحفظ");out.use{XlsxCodec.write(it,rows)};db.audit(username,"تصدير ملف Excel","بيانات",null,pendingXlsxTable);toast("تم تصدير ملف Excel بنجاح")}catch(e:Exception){toast("تعذر تصدير Excel: ${e.message}")}}
    private fun importXlsx(uri:Uri){
        if(!requirePermission("import_export"))return
        val progress=ProgressDialog.show(this,"جارٍ استيراد Excel","يتم فحص ورقة العمل والتحقق من الأعمدة ثم معالجة السجلات في الخلفية",true,false)
        thread(name="xlsx-import") {
            var added=0;var skipped=0;var error:String?=null
            try {
                val input=contentResolver.openInputStream(uri)?:throw IOException("تعذر قراءة الملف")
                val rows=input.use{XlsxCodec.read(it,"قاعدة البيانات").rows}
                if(rows.size<2)throw IOException("ورقة البيانات لا تحتوي سجلات")
                if(rows.size>200_000)throw IOException("عدد الصفوف أكبر من الحد الآمن للاستيراد")
                val headerIndex=rows.indexOfFirst{r->r.any{it.trim().removePrefix("\uFEFF") in listOf("الاسم","اسم الموظف")} && r.any{it.trim() in listOf("رقم الملف","رقم ملف")}}
                if(headerIndex<0)throw IOException("لم يتم العثور على عناوين الاسم ورقم الملف في ورقة قاعدة البيانات")
                val headers=rows[headerIndex].map{it.trim().removePrefix("\uFEFF")};fun idx(vararg names:String)=headers.indexOfFirst{h->names.any{it==h}}
                val legacy=idx("تاريخ التحليل")>=0 && idx("رقم الملف","رقم ملف")>=0
                if(!legacy && idx("الرقم القومي","رقم البطاقة")<0 && idx("رقم الهاتف")<0 && idx("الوظيفة")<0) {
                    throw IOException("عناوين الأعمدة لا تطابق نموذج الموظفين أو التحاليل التاريخية؛ لم يتم تعديل قاعدة البيانات")
                }
                db.writableDatabase.beginTransaction()
                try {
                    rows.drop(headerIndex+1).forEachIndexed { rowOffset, row ->
                        fun v(vararg names:String)=idx(*names).let{if(it>=0)row.getOrElse(it){""}.trim() else ""}
                        val name=v("الاسم","اسم الموظف");if(name.isBlank()){skipped++;return@forEachIndexed}
                        if(legacy){
                            val emp=db.saveLegacyEmployee(v("م"),v("رقم الملف","رقم ملف"),name,v("الوظيفة"),v("المنطقة"),v("الجهة"),v("رقم الهاتف"),v("رقم البطاقة"),v("النوع"),username,false)
                            if(emp==null){skipped++;return@forEachIndexed}
                            val hasAnalysis=listOf("تاريخ التحليل","ملاحظات","القائم بالتحليل","النتيجة","قانونية","توضيح","تفاصيل الحالة").any{v(it).isNotBlank()}
                            if(hasAnalysis){if(db.saveLegacyAnalysis(emp,"غير محدد",v("تاريخ التحليل"),v("ملاحظات"),v("القائم بالتحليل"),v("النتيجة"),v("قانونية"),v("توضيح"),v("تفاصيل الحالة"),v("م"),username,false))added++ else skipped++}else added++
                        }else{
                            val ok=db.saveEmployee(null,listOf(v("رقم الملف","رقم ملف"),name,v("الوظيفة"),v("الإدارة"),v("جهة العمل","المنطقة"),v("رقم الهاتف"),v("رقم البطاقة","الرقم القومي"),v("ملاحظات")),username)
                            if(ok)added++ else skipped++
                        }
                    }
                    db.audit(username,"استيراد ملف Excel","قاعدة البيانات",null,"المضاف/المعالج: $added؛ المتجاوز: $skipped")
                    db.writableDatabase.setTransactionSuccessful()
                } finally { db.writableDatabase.endTransaction() }
            }catch(e:Exception){error=e.message?:"خطأ غير معروف"}
            runOnUiThread {progress.dismiss();if(error==null){toast("اكتمل الاستيراد: تمت معالجة $added سجلًا، وتجاوزنا $skipped. تم الاحتفاظ بتكرار التحاليل.");home()}else toast("تعذر استيراد Excel: $error")}
        }
    }
    private fun buildPdfText(title:String,csv:String):String=title+"\n"+csv.replace("\uFEFF","").replace(",","   |   ")
    private fun writePdf(uri:Uri){if(!requirePermission("reports"))return;val doc=PdfDocument();try{
        val paint=TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;textSize=10f}
        val layout=StaticLayout.Builder.obtain(pendingPdf,0,pendingPdf.length,paint,547).setAlignment(Layout.Alignment.ALIGN_OPPOSITE).setTextDirection(TextDirectionHeuristics.RTL).setLineSpacing(2f,1.05f).build()
        val pageHeight=770;val pages=maxOf(1,(layout.height+pageHeight-1)/pageHeight)
        for(i in 0 until pages){val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,i+1).create());page.canvas.save();page.canvas.translate(24f,32f-i*pageHeight);page.canvas.clipRect(0f,i*pageHeight.toFloat(),547f,(i+1)*pageHeight.toFloat());layout.draw(page.canvas);page.canvas.restore();doc.finishPage(page)}
        contentResolver.openOutputStream(uri)?.use{doc.writeTo(it)}?:throw IOException("تعذر فتح ملف PDF");toast("تم إنشاء تقرير PDF")
    }catch(e:Exception){toast("تعذر إنشاء PDF: ${e.message}")}finally{doc.close()}}
    private fun parseCsv(line:String):List<String>{return parseCsvRecords(line).firstOrNull().orEmpty()}
    private fun parseCsvRecords(content:String):List<List<String>>{val rows=mutableListOf<List<String>>();val row=mutableListOf<String>();val cell=StringBuilder();var quoted=false;var i=0;while(i<content.length){val c=content[i];when{c=='"'->{if(quoted&&i+1<content.length&&content[i+1]=='"'){cell.append('"');i++}else quoted=!quoted};c==','&&!quoted->{row.add(cell.toString());cell.setLength(0)};(c=='\n'||c=='\r')&&!quoted->{if(c=='\r'&&i+1<content.length&&content[i+1]=='\n')i++;row.add(cell.toString());cell.setLength(0);if(row.any{it.isNotBlank()})rows.add(row.toList());row.clear()};else->cell.append(c)};i++};if(cell.isNotEmpty()||row.isNotEmpty()){row.add(cell.toString());if(row.any{it.isNotBlank()})rows.add(row.toList())};return rows}
    private fun users(){if(!requirePermission("users_manage"))return;page("المستخدمون والصلاحيات","إدارة حسابات الدخول");db.userRows().forEach{r->card(r[1],"الدور: ${r[2]}  •  ${if(r[3]=="1")"نشط" else "موقوف"}"){AlertDialog.Builder(this).setItems(arrayOf("تغيير كلمة المرور","تفعيل / إيقاف الحساب","تخصيص الصلاحيات")){_,which->if(which==0)passwordDialog(r[1])else if(which==2)permissionEditor(r[1])else{if(r[1]==username)toast("لا يمكن إيقاف الحساب المستخدم حاليًا")else{db.writableDatabase.execSQL("UPDATE users SET active=1-active WHERE id=?",arrayOf(r[0]));db.audit(username,if(r[3]=="1")"إيقاف حساب مستخدم" else "إعادة تفعيل حساب مستخدم","مستخدم",r[0].toLong(),r[1]);users()}}}.show()}};btn("إضافة مستخدم مباشرة"){addUserDialog()};btn("إنشاء كود تفعيل ومشاركته عبر واتساب أو أي تطبيق"){issueActivationDialog()};btn("عودة",::home,true)}
    private fun permissionEditor(target:String){if(!requirePermission("users_manage"))return;if(target==username){toast("لا يمكن تعديل صلاحيات الحساب المستخدم حاليًا من هذه الشاشة");return};page("صلاحيات المستخدم","حدد الصلاحيات ثم اضغط حفظ لتطبيقها دفعة واحدة: $target");val current=db.permissions(target);val selected=linkedMapOf<String,Boolean>();db.permissionNames().forEach{key->val cb=CheckBox(this).apply{text=permissionLabel(key);isChecked=current[key]?:false;setTextColor(theme.ink);textSize=15f;buttonTintList=android.content.res.ColorStateList.valueOf(accent);selected[key]=isChecked;setOnCheckedChangeListener{_,checked->selected[key]=checked}};body.addView(cb)};btn("حفظ الصلاحيات",{if(!requirePermission("users_manage"))return@btn;try{db.writableDatabase.beginTransaction();selected.forEach{(key,value)->db.setPermission(target,key,value)};db.writableDatabase.setTransactionSuccessful();db.writableDatabase.endTransaction();db.audit(username,"تعديل صلاحيات مستخدم","مستخدم",null,target);toast("تم حفظ الصلاحيات بنجاح");users()}catch(e:Exception){try{db.writableDatabase.endTransaction()}catch(_:Exception){};toast("تعذر حفظ الصلاحيات: ${e.message}")}});btn("إلغاء",::users,true)}
    private fun issueActivationDialog(){if(!requirePermission("users_manage"))return;val roles=listOf("مستخدم","مدير");val spinner=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,roles)};val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),0,dp(20),0);addView(text("حدد نوع الحساب ثم اضغط تأكيد وإنشاء الكود"));addView(spinner);addView(text("المستخدم العادي يبدأ بصلاحيات العرض، ويمكن للمدير تخصيص صلاحياته بعد التفعيل."))};AlertDialog.Builder(this).setTitle("إنشاء كود تفعيل لمرة واحدة").setView(box).setPositiveButton("تأكيد وإنشاء الكود"){_,_->try{val selectedRole=spinner.selectedItem?.toString()?:"مستخدم";val code=db.issueActivationCode(selectedRole,username);AlertDialog.Builder(this).setTitle("تم إنشاء كود التفعيل").setMessage("الدور المحدد: $selectedRole\n\nالكود: $code\n\nاحفظ الكود وشاركه مع المستخدم المقصود فقط.").setPositiveButton("مشاركة"){_,_->val send=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,"كود تفعيل تطبيق تحاليل العاملين: $code\nالدور: $selectedRole\nيستخدم مرة واحدة.")};startActivity(Intent.createChooser(send,"مشاركة كود التفعيل"))}.setNeutralButton("نسخ الكود"){_,_->val cm=getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager;cm.setPrimaryClip(android.content.ClipData.newPlainText("كود التفعيل",code));toast("تم نسخ كود التفعيل")}.setNegativeButton("إغلاق",null).show()}catch(e:Exception){toast("تعذر إنشاء الكود: ${e.message}")}}.setNegativeButton("إلغاء",null).show()}
    private fun activationDialog(){
        val codeBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),0,dp(20),0)}
        val code=EditText(this).apply{hint="أدخل كود التفعيل المرسل من المدير";setSingleLine(true);inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS}
        codeBox.addView(code)
        val dialog=AlertDialog.Builder(this).setTitle("الخطوة الأولى — التحقق من كود التفعيل").setView(codeBox).setPositiveButton("متابعة",null).setNegativeButton("إلغاء",null).create()
        dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val entered=code.text.toString().trim(); val assignedRole=if(entered.isBlank()) null else db.activationCodeRole(entered)
            if(assignedRole==null){toast("كود التفعيل غير صحيح أو سبق استخدامه");return@setOnClickListener}
            dialog.dismiss()
            val accountBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),0,dp(20),0)}
            val user=EditText(this).apply{hint="اختر اسم المستخدم";setSingleLine(true)}
            val pass=EditText(this).apply{hint="أنشئ كلمة مرور (8 أحرف على الأقل)";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
            val confirm=EditText(this).apply{hint="أعد كتابة كلمة المرور";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
            accountBox.addView(text("نوع الحساب المحدد من المدير: $assignedRole",14f,theme.accent,true));accountBox.addView(user);accountBox.addView(pass);accountBox.addView(confirm)
            AlertDialog.Builder(this).setTitle("الخطوة الثانية — إنشاء حسابك").setView(accountBox).setPositiveButton("إنشاء الحساب") { _, _ ->
                val name=user.text.toString().trim(); val pw=pass.text.toString()
                if(name.isBlank()||pw.length<8||pw!=confirm.text.toString()){toast("تحقق من اسم المستخدم وكلمة المرور وتأكيدها");return@setPositiveButton}
                if(db.redeemActivationCode(entered,name,pw)){db.audit(name,"تفعيل حساب بكود","مستخدم",null,"الدور: $assignedRole");toast("تم إنشاء الحساب. يمكنك تسجيل الدخول الآن.")}
                else toast("تعذر إنشاء الحساب؛ قد يكون الكود استُخدم أو اسم المستخدم موجودًا")
            }.setNegativeButton("إلغاء",null).show()
        } }
        dialog.show()
    }
    private fun addUserDialog(){if(!requirePermission("users_manage"))return;val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),0,dp(20),0)};val u=EditText(this).apply{hint="اسم المستخدم"};val p=EditText(this).apply{hint="كلمة المرور (8 أحرف على الأقل)";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD};val roleSp=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("مستخدم","مدير"))};box.addView(u);box.addView(p);box.addView(roleSp);AlertDialog.Builder(this).setTitle("إضافة مستخدم").setView(box).setPositiveButton("حفظ"){_,_->if(u.text.isNotBlank()&&p.text.length>=8){val salt=ByteArray(16).also{SecureRandom().nextBytes(it)};if(db.addUser(u.text.toString().trim(),hash(p.text.toString(),salt),Base64.encodeToString(salt,Base64.NO_WRAP),roleSp.selectedItem.toString())){db.audit(username,"إضافة مستخدم","مستخدم",null,u.text.toString());users()}else toast("اسم المستخدم مستخدم بالفعل")}else toast("أدخل اسمًا وكلمة مرور من 8 أحرف على الأقل")}.setNegativeButton("إلغاء",null).show()}
    private fun passwordDialog(target:String){if(target!=username&&!requirePermission("users_manage"))return;val p=EditText(this).apply{hint="كلمة المرور الجديدة";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD};AlertDialog.Builder(this).setTitle("تغيير كلمة مرور $target").setView(p).setPositiveButton("تغيير"){_,_->if(p.text.length>=8){db.changePassword(target,p.text.toString());db.audit(username,if(target==username)"تغيير كلمة المرور" else "إعادة تعيين كلمة مرور مستخدم","مستخدم",null,target);if(target==username)getSharedPreferences("security",0).edit().remove("biometric_user").apply();users()}else toast("كلمة المرور يجب ألا تقل عن 8 أحرف")}.setNegativeButton("إلغاء",null).show()}
    private fun settings(){if(!(can("settings_manage")||can("backup_restore"))){toast("ليس لديك صلاحية");return};page("الإعدادات والتخصيص","تخصيص المظهر وحماية بيانات العمل");card("الحساب الحالي","$username — $role");if(can("settings_manage")) btn("تغيير كلمة المرور"){passwordDialog(username)}
        if(can("settings_manage")) {
            val biometricOn = getSharedPreferences("security",0).getString("biometric_user","") == username
            card("الدخول بالبصمة", if(biometricOn) "الدخول بالبصمة مفعّل لهذا الحساب" else "الدخول بالبصمة غير مفعّل")
            if(biometricOn) btn("إلغاء تفعيل الدخول بالبصمة",{getSharedPreferences("security",0).edit().remove("biometric_user").apply();db.audit(username,"إلغاء تفعيل الدخول بالقياسات الحيوية","الأمان");settings()},true)
            else btn("تفعيل الدخول بالبصمة",::enableBiometric)
        }
        if(can("settings_manage")) {
            card("نماذج المظهر العشرة","اختر من عشرة نماذج متناسقة. اللون الأساسي والأزرار والخلفية والبطاقات والنصوص تتغير معًا، مع مراعاة وضوح القراءة.")
            val themeNames=UI_THEMES.mapIndexed{i,t->"${i+1}. ${t.name}"}
            val picker=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,themeNames);setSelection(getSharedPreferences("ui",0).getInt("theme_index",0).coerceIn(0,9))}
            body.addView(picker,LinearLayout.LayoutParams(-1,dp(52)))
            val preview=MaterialCardView(this).apply { radius=dp(20).toFloat();cardElevation=dp(2).toFloat();strokeWidth=dp(1) }
            val previewBox=column().apply { setPadding(dp(16),dp(14),dp(16),dp(14)) }
            val previewTitle=text("معاينة مباشرة للنموذج",15f,theme.ink,true)
            val previewDesc=text("ستتغير ألوان البطاقات والخلفية والأزرار معًا",12f,theme.muted)
            val previewAction=MaterialButton(this).apply{text="زر تجريبي";isClickable=false;cornerRadius=dp(14)}
            previewBox.addView(previewTitle);previewBox.addView(previewDesc);previewBox.addView(previewAction)
            preview.addView(previewBox);body.addView(preview,LinearLayout.LayoutParams(-1,-2))
            fun updateThemePreview(index:Int){val t=UI_THEMES[index.coerceIn(0,UI_THEMES.lastIndex)];preview.setCardBackgroundColor(t.card);preview.strokeColor=t.shadow;previewTitle.setTextColor(t.ink);previewDesc.setTextColor(t.muted);previewAction.backgroundTintList=android.content.res.ColorStateList.valueOf(t.accent);previewAction.setTextColor(Color.WHITE)}
            updateThemePreview(picker.selectedItemPosition)
            picker.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(parent:AdapterView<*>?){};override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long){updateThemePreview(position)}}
            btn("تطبيق نموذج الألوان المختار"){getSharedPreferences("ui",0).edit().remove("custom_accent").remove("custom_bg").remove("custom_ink").apply();saveTheme(picker.selectedItemPosition);settings()}
            card("طريقة الاستخدام","اختر نموذجًا من القائمة، شاهد المعاينة المباشرة، ثم اضغط تطبيق. للعودة إلى المظهر الطبي الأخضر اختر النموذج الأول.")
        }
        if(can("settings_manage")) btn("تكبير الخط",{val p=getSharedPreferences("ui",0);p.edit().putFloat("font_scale",(p.getFloat("font_scale",1f)+0.1f).coerceAtMost(1.4f)).apply();settings()},true)
        if(can("settings_manage")) btn("تصغير الخط",{val p=getSharedPreferences("ui",0);p.edit().putFloat("font_scale",(p.getFloat("font_scale",1f)-0.1f).coerceAtLeast(0.9f)).apply();settings()},true)
        if(can("settings_manage")){val current=getSharedPreferences("security",0).getInt("auto_lock_minutes",5);card("القفل التلقائي","المدة الحالية: ${if(current==0)"معطل" else "$current دقائق"}");listOf(1,5,10,15,0).forEach{m->btn(if(m==0)"تعطيل القفل التلقائي" else "القفل بعد $m دقيقة",{getSharedPreferences("security",0).edit().putInt("auto_lock_minutes",m).apply();idleHandler.removeCallbacks(idleLock);settings()},true)}}
        card("النسخ الاحتياطي المشفر","تشفير AES-256-GCM ومفتاح مشتق من كلمة مرور تختارها. يمكن استعادة الملف على جهاز آخر عند توفر كلمة المرور.")
        if(can("backup_restore")) btn("إنشاء نسخة احتياطية مشفرة",{backupPasswordDialog(false)})
        if(can("backup_restore")) btn("استعادة نسخة احتياطية مشفرة",{backupPasswordDialog(true)},true)
        if(can("backup_restore")) btn("استيراد قاعدة بيانات البرنامج (SQLite)",{confirmPlainDatabaseImport()},true)
        card("حالة التشفير التشغيلي","قاعدة البيانات تعمل باستخدام SQLCipher، ويُحمى مفتاحها المحلي بواسطة Android Keystore.")
        if(can("backup_restore")) btn("فحص سلامة قاعدة البيانات وعدد السجلات"){try{AlertDialog.Builder(this).setTitle("نتيجة فحص قاعدة البيانات").setMessage(db.integritySummary()).setPositiveButton("موافق",null).show();db.audit(username,"فحص سلامة قاعدة البيانات","الأمان")}catch(e:Exception){toast("تعذر إتمام الفحص: ${e.message}")}}
        card("معلومات الإصدار","الإصدار ${BuildConfig.VERSION_NAME} — رقم البناء ${BuildConfig.VERSION_CODE} — قاعدة بيانات SQLCipher");btn("عودة",::home,true)}

    private fun biometricLogin(target:String){
        try {
        val manager=BiometricManager.from(this)
        val availability=manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
        if(availability!=BiometricManager.BIOMETRIC_SUCCESS){toast("البصمة أو قفل الجهاز غير متاح. استخدم كلمة المرور.");return}
        val prompt=BiometricPrompt(this,ContextCompat.getMainExecutor(this),object:BiometricPrompt.AuthenticationCallback(){
            override fun onAuthenticationSucceeded(result:BiometricPrompt.AuthenticationResult){super.onAuthenticationSucceeded(result);val currentRole=db.activeRole(target);if(currentRole==null){getSharedPreferences("security",0).edit().remove("biometric_user").apply();toast("الحساب موقوف أو غير موجود؛ سجل الدخول بكلمة المرور")}else{username=target;role=currentRole;db.audit(username,"دخول بالقياسات الحيوية","النظام");home();onUserInteraction()}}
            override fun onAuthenticationError(errorCode:Int,errString:CharSequence){super.onAuthenticationError(errorCode,errString);toast("تعذر الدخول بالبصمة: $errString")}
        })
        prompt.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("الدخول الآمن").setSubtitle("تحقق من هويتك للدخول إلى حسابك").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG).setNegativeButtonText("إلغاء").build())
        } catch(e:Exception) { toast("تعذر تشغيل البصمة: ${e.localizedMessage?:"استخدم كلمة المرور"}") }
    }
    private fun enableBiometric(){
        try {
        val manager=BiometricManager.from(this)
        val availability=manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
        if(availability!=BiometricManager.BIOMETRIC_SUCCESS){toast("يجب إعداد بصمة أو قفل شاشة آمن على الهاتف أولًا");return}
        val prompt=BiometricPrompt(this,ContextCompat.getMainExecutor(this),object:BiometricPrompt.AuthenticationCallback(){
            override fun onAuthenticationSucceeded(result:BiometricPrompt.AuthenticationResult){super.onAuthenticationSucceeded(result);getSharedPreferences("security",0).edit().putString("biometric_user",username).apply();db.audit(username,"تفعيل الدخول بالقياسات الحيوية","الأمان");toast("تم تفعيل الدخول بالبصمة لهذا الحساب");settings()}
            override fun onAuthenticationError(errorCode:Int,errString:CharSequence){super.onAuthenticationError(errorCode,errString);toast("لم يتم تفعيل البصمة: $errString")}
        })
        prompt.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("تأكيد تفعيل الدخول بالبصمة").setSubtitle("أكد هويتك لتفعيل الدخول السريع لهذا الحساب").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG).setNegativeButtonText("إلغاء").build())
        } catch(e:Exception) { toast("لم يتم تشغيل خدمة البصمة: ${e.localizedMessage?:"تحقق من إعدادات الهاتف"}") }
    }
    private fun backupPasswordDialog(restore:Boolean){val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),0,dp(20),0)};val p=EditText(this).apply{hint="كلمة مرور النسخة (10 أحرف على الأقل)";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD};box.addView(p);AlertDialog.Builder(this).setTitle(if(restore)"استعادة النسخة المشفرة" else "إنشاء نسخة مشفرة").setView(box).setPositiveButton(if(restore)"اختيار الملف" else "حفظ النسخة"){_,_->val pass=p.text.toString();if(pass.length<10){toast("كلمة المرور يجب ألا تقل عن 10 أحرف");return@setPositiveButton};backupPassphrase=pass;if(restore)openBackup.launch("application/octet-stream")else createBackup.launch("employee-analysis-backup.eabk")}.setNegativeButton("إلغاء",null).show()}
    private fun writeBackup(uri:Uri){if(!requirePermission("backup_restore"))return;try{val out=contentResolver.openOutputStream(uri)?:throw IOException("تعذر فتح الملف للحفظ");out.use{SecureBackup.exportEncrypted(this,it,backupPassphrase.toCharArray(),databaseKey)};db.audit(username,"إنشاء نسخة احتياطية مشفرة","قاعدة البيانات");backupPassphrase="";toast("تم إنشاء النسخة الاحتياطية المشفرة") }catch(e:Exception){backupPassphrase="";toast("فشل إنشاء النسخة الاحتياطية: ${e.message}")}}
    private fun confirmPlainDatabaseImport(){
        if(!requirePermission("backup_restore"))return
        AlertDialog.Builder(this).setTitle("استيراد قاعدة بيانات البرنامج")
            .setMessage("اختر ملف employee_analysis.db الذي تم تجهيزه لك. سيتم فحصه أولًا ثم تشفيره تلقائيًا بمفتاح هذا الهاتف.\n\nتنبيه: الاستيراد سيستبدل البيانات الحالية ببيانات الملف المختار. احتفظ بنسخة احتياطية من بياناتك الحالية قبل المتابعة.")
            .setPositiveButton("اختيار ملف قاعدة البيانات"){_,_->openPlainDatabase.launch("application/octet-stream")}
            .setNegativeButton("إلغاء",null).show()
    }
    private fun importPlainDatabase(uri:Uri){
        if(!requirePermission("backup_restore"))return
        var closed=false
        try{
            db.close();closed=true
            val input=contentResolver.openInputStream(uri)?:throw IOException("تعذر قراءة ملف قاعدة البيانات")
            input.use{SecureBackup.importPlainDatabase(this,it,databaseKey)}
            db=AppDb(this,databaseKey);closed=false
            val importedEmployees=db.scalar("SELECT COUNT(*) FROM employees")
            val importedAnalyses=db.scalar("SELECT COUNT(*) FROM analyses")
            db.audit(username,"استيراد قاعدة بيانات SQLite وتشفيرها","قاعدة البيانات",null,"الموظفون: $importedEmployees؛ التحاليل: $importedAnalyses")
            File(getDatabasePath("employee_analysis.db").parentFile,"employee_analysis.pre-import").delete()
            username="";role="";screenHistory.clear()
            toast("تم استيراد قاعدة البيانات وفحصها وتشفيرها بنجاح. سجل الدخول بحساب موجود داخل الملف.")
            login()
        }catch(e:Exception){
            if(closed){try{db=AppDb(this,databaseKey)}catch(_:Exception){}}
            toast("تعذر استيراد قاعدة البيانات: ${e.message?:"خطأ غير محدد"}. لم يتم اعتماد الملف إذا فشل التحقق.")
        }
    }
    private fun readBackup(uri:Uri){
        if(!requirePermission("backup_restore"))return
        var helperClosed=false
        try {
            // Close every SQLiteOpenHelper connection before the file swap; otherwise SQLite may
            // retain a handle to the old inode while the path now points at the restored file.
            db.close(); helperClosed=true
            val input=contentResolver.openInputStream(uri) ?: throw IOException("تعذر قراءة ملف النسخة الاحتياطية")
            input.use { SecureBackup.restoreEncrypted(this,it,backupPassphrase.toCharArray(),databaseKey) }
            db=AppDb(this,databaseKey)
            // Opening the helper executes the real application schema/migration path.
            val restoredEmployees=db.scalar("SELECT COUNT(*) FROM employees")
            val restoredAnalyses=db.scalar("SELECT COUNT(*) FROM analyses")
            db.audit(username,"استعادة نسخة احتياطية مشفرة","قاعدة البيانات",null,"الموظفون: $restoredEmployees؛ التحاليل: $restoredAnalyses")
            File(getDatabasePath("employee_analysis.db").parentFile,"employee_analysis.rollback").delete()
            File(getDatabasePath("employee_analysis.db").parentFile,"employee_analysis.pre-import").delete()
            backupPassphrase=""; username=""; role=""; screenHistory.clear()
            toast("تمت الاستعادة بنجاح. الموظفون: $restoredEmployees؛ التحاليل: $restoredAnalyses. سجل الدخول بحساب موجود في النسخة.")
            login()
        } catch(e:Exception) {
            backupPassphrase=""
            if(helperClosed) {
                try { db=AppDb(this,databaseKey); db.scalar("SELECT COUNT(*) FROM employees") }
                catch(reopen:Exception) { toast("تعذر فتح قاعدة البيانات بعد المحاولة. لا تحذف بيانات التطبيق؛ رسالة الفتح: ${reopen.message}"); return }
            }
            toast("فشلت الاستعادة: ${e.message ?: "خطأ غير محدد"}. تم الحفاظ على قاعدة البيانات السابقة إذا لم يتم اعتماد النسخة.")
        }
    }
    private fun audit(){if(!requirePermission("audit_view"))return;page("سجل العمليات","آخر 500 عملية");db.auditRows().forEach{card(it)};btn("عودة",::home,true)}
    private fun can(key:String):Boolean = db.permissions(username)[key]==true
    private fun requirePermission(key:String):Boolean { if(can(key))return true;toast("ليس لديك صلاحية لتنفيذ هذه العملية");return false }
    private fun permissionLabel(key:String)=when(key){"employees_view"->"عرض الموظفين";"employees_edit"->"إضافة وتعديل الموظفين";"employees_delete"->"حذف واستعادة الموظفين";"analyses_view"->"عرض التحاليل";"analyses_edit"->"إضافة وتعديل التحاليل";"analyses_delete"->"حذف واستعادة التحاليل";"import_export"->"استيراد وتصدير البيانات";"reports"->"إعداد وطباعة التقارير";"users_manage"->"إدارة المستخدمين والصلاحيات";"settings_manage"->"إدارة الإعدادات";"audit_view"->"عرض سجل العمليات";else->"النسخ الاحتياطي والاستعادة"}
    private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_LONG).show()}
}
