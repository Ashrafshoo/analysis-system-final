package com.ashraf.employeeanalysis

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private class LocalDb(ctx: Context) : SQLiteOpenHelper(ctx, "employee_analysis.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE employees(id INTEGER PRIMARY KEY AUTOINCREMENT, file_no TEXT UNIQUE, name TEXT NOT NULL, job TEXT, department TEXT, workplace TEXT, phone TEXT, notes TEXT, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL)")
        db.execSQL("CREATE TABLE analyses(id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id INTEGER NOT NULL, analysis_type TEXT NOT NULL, status TEXT NOT NULL, sample_date TEXT, result_date TEXT, result TEXT, notes TEXT, classification TEXT NOT NULL DEFAULT 'تأكيدية', created_at TEXT NOT NULL, deleted INTEGER NOT NULL DEFAULT 0, FOREIGN KEY(employee_id) REFERENCES employees(id))")
        db.execSQL("CREATE TABLE audit(id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL, entity TEXT NOT NULL, entity_id INTEGER, details TEXT, created_at TEXT NOT NULL)")
        db.execSQL("CREATE TABLE app_users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password_hash TEXT, role TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1)")
        db.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT)")
        db.execSQL("INSERT INTO app_users(username,password_hash,role) VALUES('admin','CHANGE_ME','مدير')")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun now() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
    fun audit(action: String, entity: String, id: Long?, details: String = "") { writableDatabase.insert("audit", null, ContentValues().apply { put("action", action); put("entity", entity); if(id!=null) put("entity_id",id); put("details",details); put("created_at",now()) }) }
    fun employees(q: String = ""): List<Array<String>> {
        val out=mutableListOf<Array<String>>(); val db=readableDatabase
        val c=db.rawQuery("SELECT id,COALESCE(file_no,''),name,COALESCE(job,''),COALESCE(department,''),COALESCE(workplace,'') FROM employees WHERE active=1 AND (name LIKE ? OR file_no LIKE ? OR department LIKE ? OR workplace LIKE ?) ORDER BY name", arrayOf("%$q%","%$q%","%$q%","%$q%"))
        c.use { while(it.moveToNext()) out.add(Array(6){i->it.getString(i) ?: ""}) }; return out
    }
    fun addEmployee(fileNo:String,name:String,job:String,dept:String,work:String,phone:String,notes:String): Boolean = try {
        val id=writableDatabase.insertOrThrow("employees",null,ContentValues().apply { put("file_no",fileNo.ifBlank{null}); put("name",name); put("job",job); put("department",dept); put("workplace",work); put("phone",phone); put("notes",notes); put("created_at",now()) })
        audit("إضافة","موظف",id,name); true
    } catch (_: Exception) { false }
    fun updateEmployee(id:Long,fileNo:String,name:String,job:String,dept:String,work:String,phone:String,notes:String):Boolean = try {
        val n=writableDatabase.update("employees",ContentValues().apply { put("file_no",fileNo.ifBlank{null}); put("name",name); put("job",job); put("department",dept); put("workplace",work); put("phone",phone); put("notes",notes) },"id=?",arrayOf(id.toString())); audit("تعديل","موظف",id,name); n>0
    } catch (_:Exception){false}
    fun addAnalysis(employeeId:Long,type:String,status:String,sample:String,resultDate:String,result:String,notes:String,classification:String):Boolean = try {
        val id=writableDatabase.insertOrThrow("analyses",null,ContentValues().apply { put("employee_id",employeeId); put("analysis_type",type); put("status",status); put("sample_date",sample); put("result_date",resultDate); put("result",result); put("notes",notes); put("classification",classification); put("created_at",now()) }); audit("إضافة","تحليل",id,"employee_id=$employeeId"); true
    } catch (_:Exception){false}
    fun analyses(employeeId:Long?=null):List<Array<String>> { val out=mutableListOf<Array<String>>(); val sql="SELECT a.id,e.name,a.analysis_type,a.status,COALESCE(a.sample_date,''),COALESCE(a.result_date,''),COALESCE(a.result,''),a.classification FROM analyses a JOIN employees e ON e.id=a.employee_id WHERE a.deleted=0"+(if(employeeId!=null)" AND e.id=?" else "")+" ORDER BY a.id DESC"; readableDatabase.rawQuery(sql,if(employeeId!=null) arrayOf(employeeId.toString()) else null).use { c->while(c.moveToNext())out.add(Array(8){i->c.getString(i)?:""}) };return out }
    fun softDeleteAnalysis(id:Long){writableDatabase.execSQL("UPDATE analyses SET deleted=1 WHERE id=?",arrayOf(id));audit("إخفاء/حذف منطقي","تحليل",id)}
    fun count(table:String):Int=readableDatabase.rawQuery("SELECT COUNT(*) FROM $table"+(if(table=="analyses")" WHERE deleted=0" else ""),null).use{if(it.moveToFirst())it.getInt(0)else 0}
    fun exportCsv():String { val sb=StringBuilder("رقم الملف,الاسم,الوظيفة,الإدارة,جهة العمل,الهاتف,ملاحظات\n"); readableDatabase.rawQuery("SELECT COALESCE(file_no,''),name,COALESCE(job,''),COALESCE(department,''),COALESCE(workplace,''),COALESCE(phone,''),COALESCE(notes,'') FROM employees WHERE active=1 ORDER BY name",null).use{c->while(c.moveToNext()){sb.append((0 until c.columnCount).joinToString(","){i->"\""+c.getString(i).orEmpty().replace("\"","\"\"")+"\""}).append('\n')}};return sb.toString() }
    fun importCsv(lines:List<List<String>>):Pair<Int,Int>{var added=0;var skipped=0;lines.drop(1).forEach{r->if(r.size>=2&&r[1].isNotBlank()){if(addEmployee(r.getOrElse(0){""},r[1],r.getOrElse(2){""},r.getOrElse(3){""},r.getOrElse(4){""},r.getOrElse(5){""},r.getOrElse(6){""}))added++ else skipped++}else skipped++};return added to skipped}
}

class MainActivity : AppCompatActivity() {
    private lateinit var db:LocalDb; private lateinit var root:LinearLayout; private var currentTab="home"
    private val exportLauncher=registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")){uri->if(uri!=null) try{contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use{it.write(db.exportCsv())};toast("تم تصدير ملف الموظفين") }catch(e:Exception){toast("تعذر التصدير: ${e.message}")}}
    private val importLauncher=registerForActivityResult(ActivityResultContracts.GetContent()){uri->if(uri!=null)importCsv(uri)}
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);window.decorView.layoutDirection=View.LAYOUT_DIRECTION_RTL;db=LocalDb(this);showHome()}
    private fun base(title:String){root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18);setBackgroundColor(0xFFF4F7F8.toInt())}; val scroll=ScrollView(this);scroll.addView(root);setContentView(scroll);val h=TextView(this).apply{text=title;textSize=24f;setTextColor(0xFF0B3949.toInt());typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setPadding(8)};root.addView(h);root.addView(TextView(this).apply{text="تطبيق محلي — بيانات محفوظة على هذا الجهاز";textSize=12f;gravity=Gravity.CENTER;setTextColor(0xFF55717B.toInt());setPadding(4)}) }
    private fun button(label:String,action:()->Unit){root.addView(Button(this).apply{text=label;isAllCaps=false;setOnClickListener{action()}})}
    private fun field(hint:String, value:String=""):EditText=EditText(this).apply{this.hint=hint;setText(value);textSize=16f;setSingleLine(hint!="ملاحظات");root.addView(this)}
    private fun label(text:String){root.addView(TextView(this).apply{this.text=text;textSize=16f;setTextColor(0xFF203E49.toInt());setPadding(4)})}
    private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_LONG).show()}
    private fun showHome(){currentTab="home";base("تحاليل العاملين");label("لوحة المتابعة");label("عدد الموظفين: ${db.count("employees")}    |    عدد التحاليل: ${db.count("analyses")}");button("إدارة الموظفين والبحث"){showEmployees()};button("سجل التحاليل والنتائج"){showAnalyses()};button("إضافة موظف جديد"){employeeForm()};button("إضافة تحليل لموظف"){chooseEmployeeForAnalysis()};button("استيراد CSV للموظفين"){importLauncher.launch("text/*")};button("تصدير بيانات الموظفين CSV"){exportLauncher.launch("employees.csv")};button("سجل المراجعة (Audit)"){showAudit()};button("معلومات النسخ الاحتياطي والأمان"){AlertDialog.Builder(this).setTitle("النسخ الاحتياطي والأمان").setMessage("التطبيق يعمل محليًا ولا يطلب اتصال إنترنت. استخدم تصدير CSV لحفظ بيانات الموظفين. النسخ الاحتياطي الكامل والاستعادة المشفرة وتسجيل الدخول والصلاحيات المتكاملة ما زالت تحتاج استكمالًا واختبارًا قبل الاستخدام الفعلي.").setPositiveButton("حسنًا",null).show()};button("تحديث الشاشة"){showHome()} }
    private fun showEmployees(query:String=""){currentTab="employees";base("الموظفون");val search=field("ابحث بالاسم أو رقم الملف أو الإدارة",query);button("بحث"){showEmployees(search.text.toString().trim())};button("إضافة موظف"){employeeForm()};button("الرئيسية"){showHome()};val rows=db.employees(query);label("النتائج: ${rows.size}");rows.forEach{r->button("${r[2]}  |  ملف: ${r[1]}\n${r[4]} — ${r[5]}"){employeeDetails(r)} };if(rows.isEmpty())label("لا توجد نتائج مطابقة") }
    private fun employeeDetails(r:Array<String>){AlertDialog.Builder(this).setTitle(r[2]).setMessage("رقم الملف: ${r[1]}\nالوظيفة: ${r[3]}\nالإدارة: ${r[4]}\nجهة العمل: ${r[5]}").setPositiveButton("تعديل"){_,_->employeeForm(r)}.setNeutralButton("تحاليل الموظف"){_,_->showEmployeeAnalyses(r[0].toLong())}.setNegativeButton("إغلاق",null).show()}
    private fun employeeForm(old:Array<String>?=null){base(if(old==null)"إضافة موظف" else "تعديل بيانات موظف");val file=field("رقم الملف",old?.get(1).orEmpty());val name=field("الاسم الكامل *",old?.get(2).orEmpty());val job=field("الوظيفة",old?.get(3).orEmpty());val dept=field("الإدارة",old?.get(4).orEmpty());val work=field("جهة العمل",old?.get(5).orEmpty());val phone=field("الهاتف");val notes=field("ملاحظات");button("حفظ البيانات"){if(name.text.isBlank()){toast("الاسم مطلوب");return@button};val ok=if(old==null)db.addEmployee(file.text.toString().trim(),name.text.toString().trim(),job.text.toString(),dept.text.toString(),work.text.toString(),phone.text.toString(),notes.text.toString()) else db.updateEmployee(old[0].toLong(),file.text.toString(),name.text.toString(),job.text.toString(),dept.text.toString(),work.text.toString(),phone.text.toString(),notes.text.toString());if(ok){toast("تم الحفظ");showEmployees()}else toast("تعذر الحفظ؛ تحقق من عدم تكرار رقم الملف")};button("إلغاء"){showEmployees()} }
    private fun chooseEmployeeForAnalysis(){base("اختيار الموظف");val rows=db.employees();rows.forEach{r->button("${r[2]} — ${r[1]}"){analysisForm(r[0].toLong(),r[2])}};button("رجوع"){showHome()} }
    private fun analysisForm(employeeId:Long,employeeName:String){base("إضافة تحليل");label("الموظف: $employeeName");val type=field("نوع التحليل *");val status=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("قيد الانتظار","تم الاستلام","تم التحليل","تمت المراجعة"));root.addView(this)};val classification=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("تأكيدية","استدلالية"));root.addView(this)};val sample=field("تاريخ العينة YYYY-MM-DD");val resultDate=field("تاريخ النتيجة YYYY-MM-DD");val result=field("النتيجة");val notes=field("ملاحظات");button("حفظ التحليل"){if(type.text.isBlank()){toast("نوع التحليل مطلوب");return@button};if(db.addAnalysis(employeeId,type.text.toString(),status.selectedItem.toString(),sample.text.toString(),resultDate.text.toString(),result.text.toString(),notes.text.toString(),classification.selectedItem.toString())){toast("تم حفظ التحليل");showEmployeeAnalyses(employeeId)}else toast("تعذر حفظ التحليل")};button("إلغاء"){showEmployeeAnalyses(employeeId)} }
    private fun showAnalyses(){showAnalysisList(null)};private fun showEmployeeAnalyses(id:Long){showAnalysisList(id)}
    private fun showAnalysisList(employeeId:Long?){base(if(employeeId==null)"سجل التحاليل" else "تحاليل الموظف");button("الرئيسية"){showHome()};val rows=db.analyses(employeeId);label("عدد السجلات: ${rows.size}");rows.forEach{r->button("${r[1]} — ${r[2]}\n${r[3]} | ${r[7]} | ${r[6]}"){AlertDialog.Builder(this).setTitle(r[2]).setMessage("الموظف: ${r[1]}\nالحالة: ${r[3]}\nتاريخ العينة: ${r[4]}\nتاريخ النتيجة: ${r[5]}\nالنتيجة: ${r[6]}\nالتصنيف: ${r[7]}").setPositiveButton("إخفاء السجل") {_,_->db.softDeleteAnalysis(r[0].toLong());showAnalysisList(employeeId)}.setNegativeButton("إغلاق",null).show()} };if(rows.isEmpty())label("لا توجد تحاليل مسجلة") }
    private fun showAudit(){base("سجل المراجعة");button("الرئيسية"){showHome()};val c=db.readableDatabase.rawQuery("SELECT action,entity,COALESCE(entity_id,0),COALESCE(details,''),created_at FROM audit ORDER BY id DESC LIMIT 300",null);c.use{while(it.moveToNext())label("${it.getString(4)}\n${it.getString(0)} — ${it.getString(1)} #${it.getString(2)}\n${it.getString(3)}")}}
    private fun importCsv(uri:Uri){try{val lines=contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use{reader->reader.readLines().map{line->parseCsvLine(line)}}?: emptyList();val (added,skipped)=db.importCsv(lines);toast("تم الاستيراد. أضيف: $added، تم تخطي: $skipped");showHome()}catch(e:Exception){toast("تعذر قراءة الملف: ${e.message}")}}
    private fun parseCsvLine(line:String):List<String>{val out=mutableListOf<String>();val b=StringBuilder();var quoted=false;var i=0;while(i<line.length){val ch=line[i];if(ch=='"'){if(quoted&&i+1<line.length&&line[i+1]=='"'){b.append('"');i++}else quoted=!quoted}else if(ch==','&&!quoted){out.add(b.toString());b.setLength(0)}else b.append(ch);i++};out.add(b.toString());return out}
}
