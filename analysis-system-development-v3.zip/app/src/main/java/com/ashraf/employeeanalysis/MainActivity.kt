package com.ashraf.employeeanalysis

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Typeface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.util.TypedValue
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import android.util.Base64
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private class LocalDb(ctx: Context) : SQLiteOpenHelper(ctx, "employee_analysis.db", null, 3) {
    override fun onConfigure(db: SQLiteDatabase) { super.onConfigure(db); db.setForeignKeyConstraintsEnabled(true) }
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE employees(id INTEGER PRIMARY KEY AUTOINCREMENT, file_no TEXT UNIQUE, name TEXT NOT NULL, job TEXT, department TEXT, workplace TEXT, phone TEXT, notes TEXT, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL)")
        db.execSQL("CREATE TABLE analyses(id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id INTEGER NOT NULL, analysis_type TEXT NOT NULL, status TEXT NOT NULL, sample_date TEXT, result_date TEXT, result TEXT, notes TEXT, classification TEXT NOT NULL DEFAULT 'تأكيدية', created_at TEXT NOT NULL, deleted INTEGER NOT NULL DEFAULT 0, FOREIGN KEY(employee_id) REFERENCES employees(id))")
        db.execSQL("CREATE TABLE audit(id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL, entity TEXT NOT NULL, entity_id INTEGER, details TEXT, created_at TEXT NOT NULL)")
        db.execSQL("CREATE TABLE app_users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password_hash TEXT, role TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1)")
        db.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT)")
        db.execSQL("CREATE TABLE schema_meta(version INTEGER NOT NULL)")
        db.execSQL("INSERT INTO schema_meta(version) VALUES(3)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_employees_name ON employees(name)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_employees_file_no ON employees(file_no)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_analyses_employee ON analyses(employee_id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_analyses_deleted ON analyses(deleted)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Migrations are additive: never drop employee or historical analysis rows.
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS schema_meta(version INTEGER NOT NULL)")
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE employees ADD COLUMN updated_at TEXT")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_employees_active_name ON employees(active,name)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_analyses_employee_date ON analyses(employee_id,sample_date)")
            db.execSQL("UPDATE schema_meta SET version=3")
        }
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_employees_name ON employees(name)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_employees_file_no ON employees(file_no)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_analyses_employee ON analyses(employee_id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_analyses_deleted ON analyses(deleted)")
    }
    fun now() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
    fun audit(action: String, entity: String, id: Long?, details: String = "") { writableDatabase.insert("audit", null, ContentValues().apply { put("action", action); put("entity", entity); if(id!=null) put("entity_id",id); put("details",details); put("created_at",now()) }) }
    fun employees(q: String = ""): List<Array<String>> {
        val out=mutableListOf<Array<String>>(); val db=readableDatabase
        val c=db.rawQuery("SELECT id,COALESCE(file_no,''),name,COALESCE(job,''),COALESCE(department,''),COALESCE(workplace,''),COALESCE(phone,''),COALESCE(notes,'') FROM employees WHERE active=1 AND (name LIKE ? OR file_no LIKE ? OR department LIKE ? OR workplace LIKE ?) ORDER BY name", arrayOf("%$q%","%$q%","%$q%","%$q%"))
        c.use { while(it.moveToNext()) out.add(Array(8){i->it.getString(i) ?: ""}) }; return out
    }
    fun addEmployee(fileNo:String,name:String,job:String,dept:String,work:String,phone:String,notes:String): Boolean = try {
        val id=writableDatabase.insertOrThrow("employees",null,ContentValues().apply { put("file_no",fileNo.ifBlank{null}); put("name",name); put("job",job); put("department",dept); put("workplace",work); put("phone",phone); put("notes",notes); put("created_at",now()) })
        audit("إضافة","موظف",id,name); true
    } catch (_: Exception) { false }
    fun updateEmployee(id:Long,fileNo:String,name:String,job:String,dept:String,work:String,phone:String,notes:String):Boolean = try {
        val n=writableDatabase.update("employees",ContentValues().apply { put("file_no",fileNo.ifBlank{null}); put("name",name); put("job",job); put("department",dept); put("workplace",work); put("phone",phone); put("notes",notes) },"id=?",arrayOf(id.toString())); audit("تعديل","موظف",id,name); n>0
    } catch (_:Exception){false}
    fun softDeleteEmployee(id:Long):Boolean = try {
        val n=writableDatabase.update("employees",ContentValues().apply{put("active",0)},"id=? AND active=1",arrayOf(id.toString()))
        if(n>0)audit("حذف منطقي","موظف",id)
        n>0
    } catch(_:Exception){false}
    fun restoreEmployee(id:Long):Boolean = try {
        val n=writableDatabase.update("employees",ContentValues().apply{put("active",1)},"id=? AND active=0",arrayOf(id.toString()))
        if(n>0)audit("استعادة","موظف",id)
        n>0
    } catch(_:Exception){false}
    fun deletedEmployees():List<Array<String>> {
        val out=mutableListOf<Array<String>>()
        readableDatabase.rawQuery("SELECT id,COALESCE(file_no,''),name FROM employees WHERE active=0 ORDER BY name",null).use{c->while(c.moveToNext())out.add(Array(3){i->c.getString(i)?:""})}
        return out
    }
    fun addAnalysis(employeeId:Long,type:String,status:String,sample:String,resultDate:String,result:String,notes:String,classification:String):Boolean = try {
        val id=writableDatabase.insertOrThrow("analyses",null,ContentValues().apply { put("employee_id",employeeId); put("analysis_type",type); put("status",status); put("sample_date",sample); put("result_date",resultDate); put("result",result); put("notes",notes); put("classification",classification); put("created_at",now()) }); audit("إضافة","تحليل",id,"employee_id=$employeeId"); true
    } catch (_:Exception){false}
    fun analyses(employeeId:Long?=null):List<Array<String>> { val out=mutableListOf<Array<String>>(); val sql="SELECT a.id,e.name,a.analysis_type,a.status,COALESCE(a.sample_date,''),COALESCE(a.result_date,''),COALESCE(a.result,''),a.classification,COALESCE(a.notes,''),a.employee_id FROM analyses a JOIN employees e ON e.id=a.employee_id WHERE a.deleted=0"+(if(employeeId!=null)" AND e.id=?" else "")+" ORDER BY a.id DESC"; readableDatabase.rawQuery(sql,if(employeeId!=null) arrayOf(employeeId.toString()) else null).use { c->while(c.moveToNext())out.add(Array(10){i->c.getString(i)?:""}) };return out }
    fun updateAnalysis(id:Long,type:String,status:String,sample:String,resultDate:String,result:String,notes:String,classification:String):Boolean = try {
        val n=writableDatabase.update("analyses",ContentValues().apply { put("analysis_type",type);put("status",status);put("sample_date",sample);put("result_date",resultDate);put("result",result);put("notes",notes);put("classification",classification) },"id=? AND deleted=0",arrayOf(id.toString()))
        if(n>0)audit("تعديل","تحليل",id,type); n>0
    } catch(_:Exception){false}
    fun restoreAnalysis(id:Long):Boolean { val n=writableDatabase.update("analyses",ContentValues().apply{put("deleted",0)},"id=?",arrayOf(id.toString()));if(n>0)audit("استعادة","تحليل",id);return n>0 }
    fun deletedAnalyses():List<Array<String>> { val out=mutableListOf<Array<String>>();readableDatabase.rawQuery("SELECT a.id,e.name,a.analysis_type,a.status FROM analyses a JOIN employees e ON e.id=a.employee_id WHERE a.deleted=1 ORDER BY a.id DESC",null).use{c->while(c.moveToNext())out.add(Array(4){i->c.getString(i)?:""})};return out }
    fun softDeleteAnalysis(id:Long){writableDatabase.execSQL("UPDATE analyses SET deleted=1 WHERE id=?",arrayOf(id));audit("إخفاء/حذف منطقي","تحليل",id)}
    fun count(table:String):Int=readableDatabase.rawQuery("SELECT COUNT(*) FROM $table"+(if(table=="analyses")" WHERE deleted=0" else ""),null).use{if(it.moveToFirst())it.getInt(0)else 0}
    fun exportCsv():String { val sb=StringBuilder("رقم الملف,الاسم,الوظيفة,الإدارة,جهة العمل,الهاتف,ملاحظات\n"); readableDatabase.rawQuery("SELECT COALESCE(file_no,''),name,COALESCE(job,''),COALESCE(department,''),COALESCE(workplace,''),COALESCE(phone,''),COALESCE(notes,'') FROM employees WHERE active=1 ORDER BY name",null).use{c->while(c.moveToNext()){sb.append((0 until c.columnCount).joinToString(","){i->"\""+c.getString(i).orEmpty().replace("\"","\"\"")+"\""}).append('\n')}};return sb.toString() }
    fun importCsv(lines:List<List<String>>):Pair<Int,Int>{var added=0;var skipped=0;lines.drop(1).forEach{r->if(r.size>=2&&r[1].isNotBlank()){if(addEmployee(r.getOrElse(0){""},r[1],r.getOrElse(2){""},r.getOrElse(3){""},r.getOrElse(4){""},r.getOrElse(5){""},r.getOrElse(6){""}))added++ else skipped++}else skipped++};return added to skipped}
}

class MainActivity : AppCompatActivity() {
    private lateinit var db:LocalDb; private lateinit var root:LinearLayout; private var currentTab="home"
    private val exportLauncher=registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")){uri->if(uri!=null) try{contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use{it.write(db.exportCsv())};toast("تم تصدير ملف الموظفين") }catch(e:Exception){toast("تعذر التصدير: ${e.message}")}}
    private val importLauncher=registerForActivityResult(ActivityResultContracts.GetContent()){uri->if(uri!=null)importCsv(uri)}
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);window.decorView.layoutDirection=View.LAYOUT_DIRECTION_RTL;window.statusBarColor=Color.rgb(8,63,112);window.navigationBarColor=Color.rgb(8,63,112);db=LocalDb(this);showLogin()}
    private val securityPrefs by lazy { getSharedPreferences("local_auth", Context.MODE_PRIVATE) }
    private fun passwordHash(password:String, salt:ByteArray):String {
        val spec=PBEKeySpec(password.toCharArray(),salt,120000,256)
        val bytes=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        spec.clearPassword(); return Base64.encodeToString(bytes,Base64.NO_WRAP)
    }
    private fun verifyPassword(password:String):Boolean {
        val saltText=securityPrefs.getString("salt",null) ?: return false
        val expected=securityPrefs.getString("hash",null) ?: return false
        return try { java.security.MessageDigest.isEqual(passwordHash(password,Base64.decode(saltText,Base64.NO_WRAP)).toByteArray(),expected.toByteArray()) } catch(_:Exception){false}
    }
    private fun savePassword(password:String){val salt=ByteArray(16);SecureRandom().nextBytes(salt);securityPrefs.edit().putString("salt",Base64.encodeToString(salt,Base64.NO_WRAP)).putString("hash",passwordHash(password,salt)).apply()}
    private fun showLogin(){
        val first=securityPrefs.getString("hash",null)==null
        base(if(first)"إعداد كلمة المرور" else "تسجيل الدخول")
        val emblem=TextView(this).apply{text="⚗";textSize=58f;gravity=Gravity.CENTER;setTextColor(Color.rgb(0,111,190));setPadding(8)};root.addView(emblem)
        label(if(first)"مرحبًا بك في تحاليل العاملين\nأنشئ كلمة مرور لحماية بياناتك" else "تحاليل العاملين\nأدخل كلمة المرور للمتابعة")
        val password=field(if(first)"إنشاء كلمة مرور جديدة" else "كلمة المرور").apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
        val confirm=if(first)field("تأكيد كلمة المرور").apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}else null
        button(if(first)"حفظ كلمة المرور والمتابعة" else "دخول آمن") {
            val p=password.text.toString()
            if(p.length<6){toast("يجب أن تتكون كلمة المرور من 6 أحرف أو أرقام على الأقل");return@button}
            if(first){if(p!=confirm?.text?.toString()){toast("كلمتا المرور غير متطابقتين");return@button};savePassword(p);db.audit("إنشاء","حماية الدخول",null,"تم إعداد كلمة مرور محلية");toast("تم إنشاء كلمة المرور بنجاح");showHome()}
            else if(verifyPassword(p)){db.audit("دخول","المستخدم",null,"تم تسجيل الدخول");showHome()}else{toast("كلمة المرور غير صحيحة");password.setText("")}
        }
        if(!first) label("لا تتم إتاحة بيانات الموظفين قبل التحقق من كلمة المرور.")
    }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun base(title:String){root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18);setBackgroundColor(Color.rgb(242,248,253))};val scroll=ScrollView(this);scroll.addView(root);setContentView(scroll);val header=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(14);background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(7,65,119),Color.rgb(0,137,194))).apply{cornerRadius=dp(20).toFloat()}};val h=TextView(this).apply{text="⚗  $title";textSize=23f;setTextColor(Color.WHITE);typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setPadding(8)};header.addView(h);header.addView(TextView(this).apply{text="إدارة وتنظيم نتائج التحاليل الطبية";textSize=12f;gravity=Gravity.CENTER;setTextColor(Color.rgb(220,242,255));setPadding(4)});root.addView(header,LinearLayout.LayoutParams(-1,dp(100)).apply{bottomMargin=dp(16)})}
    private fun button(label:String,action:()->Unit){val b=Button(this).apply{text=label;isAllCaps=false;textSize=16f;setTextColor(Color.rgb(12,67,116));background=GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,intArrayOf(Color.WHITE,Color.rgb(226,241,253))).apply{cornerRadius=dp(16).toFloat();setStroke(dp(1),Color.rgb(201,226,246))};elevation=dp(2).toFloat();setPadding(dp(14),dp(12),dp(14),dp(12));setOnClickListener{action()}};root.addView(b,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(10)})}
    private fun field(hint:String, value:String=""):EditText=EditText(this).apply{this.hint=hint;setText(value);textSize=16f;setSingleLine(hint!="ملاحظات");root.addView(this)}
    private fun label(text:String){root.addView(TextView(this).apply{this.text=text;textSize=16f;setTextColor(0xFF16466D.toInt());setPadding(8)})}
    private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_LONG).show()}
    private fun showHome(){currentTab="home";base("تحاليل العاملين");label("لوحة المتابعة");label("عدد الموظفين: ${db.count("employees")}    |    عدد التحاليل: ${db.count("analyses")}");button("إدارة الموظفين والبحث"){showEmployees()};button("سجل التحاليل والنتائج"){showAnalyses()};button("إضافة موظف جديد"){employeeForm()};button("إضافة تحليل لموظف"){chooseEmployeeForAnalysis()};button("استيراد CSV للموظفين"){importLauncher.launch("text/*")};button("تصدير بيانات الموظفين CSV"){exportLauncher.launch("employees.csv")};button("سجل المراجعة (Audit)"){showAudit()};button("سجلات التحاليل المحذوفة واستعادتها"){showDeletedAnalyses()};button("الموظفون المحذوفون واستعادتهم"){showDeletedEmployees()};button("معلومات النسخ الاحتياطي والأمان"){AlertDialog.Builder(this).setTitle("النسخ الاحتياطي والأمان").setMessage("التطبيق يعمل محليًا ولا يطلب اتصال إنترنت. استخدم تصدير CSV لحفظ بيانات الموظفين. النسخ الاحتياطي الكامل والاستعادة المشفرة وتسجيل الدخول والصلاحيات المتكاملة ما زالت تحتاج استكمالًا واختبارًا قبل الاستخدام الفعلي.").setPositiveButton("حسنًا",null).show()};button("تحديث الشاشة"){showHome()} }
    private fun showEmployees(query:String=""){currentTab="employees";base("الموظفون");val search=field("ابحث بالاسم أو رقم الملف أو الإدارة",query);button("بحث"){showEmployees(search.text.toString().trim())};button("إضافة موظف"){employeeForm()};button("الرئيسية"){showHome()};val rows=db.employees(query);label("النتائج: ${rows.size}");rows.forEach{r->button("${r[2]}  |  ملف: ${r[1]}\n${r[4]} — ${r[5]}"){employeeDetails(r)} };if(rows.isEmpty())label("لا توجد نتائج مطابقة") }
    private fun employeeDetails(r:Array<String>){AlertDialog.Builder(this).setTitle(r[2]).setMessage("رقم الملف: ${r[1]}\nالوظيفة: ${r[3]}\nالإدارة: ${r[4]}\nجهة العمل: ${r[5]}\nالهاتف: ${r.getOrNull(6).orEmpty()}\nملاحظات: ${r.getOrNull(7).orEmpty()}").setPositiveButton("تعديل"){_,_->employeeForm(r)}.setNeutralButton("تحاليل الموظف"){_,_->showEmployeeAnalyses(r[0].toLong())}.setNegativeButton("حذف الموظف") { _,_-> AlertDialog.Builder(this).setTitle("تأكيد الحذف المنطقي").setMessage("سيتم إخفاء الموظف من القوائم مع الاحتفاظ بسجلاته وتحاليله لاستعادتها لاحقًا. هل تريد المتابعة؟").setPositiveButton("حذف") { _,_-> if(db.softDeleteEmployee(r[0].toLong())){toast("تم إخفاء الموظف ويمكن استعادته");showEmployees()}else toast("تعذر حذف الموظف") }.setNegativeButton("إلغاء",null).show() }.show()}
    private fun employeeForm(old:Array<String>?=null){base(if(old==null)"إضافة موظف" else "تعديل بيانات موظف");val file=field("رقم الملف",old?.get(1).orEmpty());val name=field("الاسم الكامل *",old?.get(2).orEmpty());val job=field("الوظيفة",old?.get(3).orEmpty());val dept=field("الإدارة",old?.get(4).orEmpty());val work=field("جهة العمل",old?.get(5).orEmpty());val phone=field("الهاتف",old?.getOrNull(6).orEmpty());val notes=field("ملاحظات",old?.getOrNull(7).orEmpty());button("حفظ البيانات"){if(name.text.isBlank()){toast("الاسم مطلوب");return@button};val ok=if(old==null)db.addEmployee(file.text.toString().trim(),name.text.toString().trim(),job.text.toString(),dept.text.toString(),work.text.toString(),phone.text.toString(),notes.text.toString()) else db.updateEmployee(old[0].toLong(),file.text.toString(),name.text.toString(),job.text.toString(),dept.text.toString(),work.text.toString(),phone.text.toString(),notes.text.toString());if(ok){toast("تم الحفظ");showEmployees()}else toast("تعذر الحفظ؛ تحقق من عدم تكرار رقم الملف")};button("إلغاء"){showEmployees()} }
    private fun showDeletedEmployees(){base("الموظفون المحذوفون");button("الرئيسية"){showHome()};val rows=db.deletedEmployees();label("السجلات: ${rows.size}");rows.forEach{r->button("${r[2]} — ${r[1]}"){AlertDialog.Builder(this).setTitle("استعادة الموظف").setMessage("هل تريد إعادة إظهار هذا الموظف؟ ستظل تحاليله التاريخية محفوظة.").setPositiveButton("استعادة"){_,_->if(db.restoreEmployee(r[0].toLong())){toast("تمت استعادة الموظف");showDeletedEmployees()}else toast("تعذرت الاستعادة")}.setNegativeButton("إلغاء",null).show()}};if(rows.isEmpty())label("لا يوجد موظفون محذوفون")}
    private fun chooseEmployeeForAnalysis(){base("اختيار الموظف");val rows=db.employees();rows.forEach{r->button("${r[2]} — ${r[1]}"){analysisForm(r[0].toLong(),r[2])}};button("رجوع"){showHome()} }
    private fun analysisForm(employeeId:Long,employeeName:String){base("إضافة تحليل");label("الموظف: $employeeName");val type=field("نوع التحليل *");val status=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("قيد الانتظار","تم الاستلام","تم التحليل","تمت المراجعة"));root.addView(this)};val classification=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("تأكيدية","استدلالية"));root.addView(this)};val sample=field("تاريخ العينة YYYY-MM-DD");val resultDate=field("تاريخ النتيجة YYYY-MM-DD");val result=field("النتيجة");val notes=field("ملاحظات");button("حفظ التحليل"){if(type.text.isBlank()){toast("نوع التحليل مطلوب");return@button};if(db.addAnalysis(employeeId,type.text.toString(),status.selectedItem.toString(),sample.text.toString(),resultDate.text.toString(),result.text.toString(),notes.text.toString(),classification.selectedItem.toString())){toast("تم حفظ التحليل");showEmployeeAnalyses(employeeId)}else toast("تعذر حفظ التحليل")};button("إلغاء"){showEmployeeAnalyses(employeeId)} }
    private fun showAnalyses(){showAnalysisList(null)};private fun showEmployeeAnalyses(id:Long){showAnalysisList(id)}
    private fun showAnalysisList(employeeId:Long?){base(if(employeeId==null)"سجل التحاليل" else "تحاليل الموظف");button("الرئيسية"){showHome()};val rows=db.analyses(employeeId);label("عدد السجلات: ${rows.size}");rows.forEach{r->button("${r[1]} — ${r[2]}\n${r[3]} | ${r[7]} | ${r[6]}"){AlertDialog.Builder(this).setTitle(r[2]).setMessage("الموظف: ${r[1]}\nالحالة: ${r[3]}\nتاريخ العينة: ${r[4]}\nتاريخ النتيجة: ${r[5]}\nالنتيجة: ${r[6]}\nالتصنيف: ${r[7]}").setPositiveButton("إخفاء السجل") {_,_->db.softDeleteAnalysis(r[0].toLong());showAnalysisList(employeeId)}.setNeutralButton("تعديل"){_,_->analysisEditForm(r)}.setNegativeButton("إغلاق",null).show()} };if(rows.isEmpty())label("لا توجد تحاليل مسجلة") }
    private fun showDeletedAnalyses(){base("التحاليل المحذوفة");button("الرئيسية"){showHome()};val rows=db.deletedAnalyses();label("السجلات: ${rows.size}");rows.forEach{r->button("${r[1]} — ${r[2]} (${r[3]})"){AlertDialog.Builder(this).setTitle("استعادة التحليل").setMessage("هل تريد استعادة هذا السجل؟").setPositiveButton("استعادة"){_,_->if(db.restoreAnalysis(r[0].toLong())){toast("تمت الاستعادة");showDeletedAnalyses()}else toast("تعذرت الاستعادة")}.setNegativeButton("إلغاء",null).show()}};if(rows.isEmpty())label("لا توجد سجلات محذوفة")}
    private fun analysisEditForm(r:Array<String>){base("تعديل التحليل");val type=field("نوع التحليل",r[2]);val status=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("قيد الانتظار","تم الاستلام","تم التحليل","تمت المراجعة"));setSelection((0 until adapter.count).firstOrNull{adapter.getItem(it)==r[3]}?:0);root.addView(this)};val classification=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("تأكيدية","استدلالية"));setSelection((0 until adapter.count).firstOrNull{adapter.getItem(it)==r[7]}?:0);root.addView(this)};val sample=field("تاريخ العينة YYYY-MM-DD",r[4]);val resultDate=field("تاريخ النتيجة YYYY-MM-DD",r[5]);val result=field("النتيجة",r[6]);val notes=field("ملاحظات",r[8]);button("حفظ التعديلات"){if(type.text.isBlank()){toast("نوع التحليل مطلوب");return@button};if(db.updateAnalysis(r[0].toLong(),type.text.toString(),status.selectedItem.toString(),sample.text.toString(),resultDate.text.toString(),result.text.toString(),notes.text.toString(),classification.selectedItem.toString())){toast("تم تحديث التحليل");showAnalysisList(r[9].toLong())}else toast("تعذر تحديث التحليل")};button("إلغاء"){showAnalysisList(r[9].toLong())}}
    private fun showAudit(){base("سجل المراجعة");button("الرئيسية"){showHome()};val c=db.readableDatabase.rawQuery("SELECT action,entity,COALESCE(entity_id,0),COALESCE(details,''),created_at FROM audit ORDER BY id DESC LIMIT 300",null);c.use{while(it.moveToNext())label("${it.getString(4)}\n${it.getString(0)} — ${it.getString(1)} #${it.getString(2)}\n${it.getString(3)}")}}
    private fun importCsv(uri:Uri){try{val lines=contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use{reader->reader.readLines().map{line->parseCsvLine(line)}}?: emptyList();val (added,skipped)=db.importCsv(lines);toast("تم الاستيراد. أضيف: $added، تم تخطي: $skipped");showHome()}catch(e:Exception){toast("تعذر قراءة الملف: ${e.message}")}}
    private fun parseCsvLine(line:String):List<String>{val out=mutableListOf<String>();val b=StringBuilder();var quoted=false;var i=0;while(i<line.length){val ch=line[i];if(ch=='"'){if(quoted&&i+1<line.length&&line[i+1]=='"'){b.append('"');i++}else quoted=!quoted}else if(ch==','&&!quoted){out.add(b.toString());b.setLength(0)}else b.append(ch);i++};out.add(b.toString());return out}
}
