package com.ashraf.employeeanalysis

import java.io.InputStream
import java.io.OutputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.parsers.SAXParserFactory
import org.xml.sax.Attributes
import org.xml.sax.InputSource
import org.xml.sax.helpers.DefaultHandler
import org.w3c.dom.Element

/** Minimal Office Open XML .xlsx codec: no external libraries or network required. */
object XlsxCodec {
    data class Sheet(val rows: List<List<String>>)

    fun write(output: OutputStream, rows: List<List<String>>) {
        ZipOutputStream(output).use { z ->
            fun entry(name: String, value: String) {
                z.putNextEntry(ZipEntry(name))
                z.write(value.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
            entry("[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""")
            entry("_rels/.rels", """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
            entry("xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="قاعدة البيانات" sheetId="1" r:id="rId1"/></sheets></workbook>""")
            entry("xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""")

            // Stream worksheet rows instead of constructing a second, potentially huge XML string.
            z.putNextEntry(ZipEntry("xl/worksheets/sheet1.xml"))
            z.write("""<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>""".toByteArray(Charsets.UTF_8))
            rows.forEachIndexed { ri, row ->
                val xml = StringBuilder().append("<row r=\\"").append(ri + 1).append("\\">")
                row.forEachIndexed { ci, raw ->
                    val ref = col(ci) + (ri + 1)
                    xml.append("<c r=\\"").append(ref).append("\\" t=\\"inlineStr\\"><is><t xml:space=\\"preserve\\">").append(esc(raw)).append("</t></is></c>")
                }
                xml.append("</row>")
                z.write(xml.toString().toByteArray(Charsets.UTF_8))
            }
            z.write("</sheetData></worksheet>".toByteArray(Charsets.UTF_8))
            z.closeEntry()
        }
    }

    fun read(input: InputStream, preferredSheetName: String? = null): Sheet {
        val files = mutableMapOf<String, ByteArray>()
        var totalBytes = 0L
        ZipInputStream(input).use { z ->
            var e = z.nextEntry
            var entryCount = 0
            while (e != null) {
                if (!e.isDirectory) {
                    entryCount++
                    require(entryCount <= 2_000) { "ملف Excel يحتوي عددًا غير معتاد من المكونات" }
                    val safeName = e.name.replace('\\', '/')
                    require(safeName.isNotBlank() && !safeName.startsWith("/") &&
                        safeName.split('/').none { it == ".." || it.isBlank() }) { "مسار غير آمن داخل ملف Excel" }
                    val buffer = ByteArray(8 * 1024)
                    val bytes = ByteArrayOutputStream()
                    while (true) {
                        val count = z.read(buffer)
                        if (count < 0) break
                        totalBytes += count
                        require(totalBytes <= 64L * 1024 * 1024) { "ملف Excel أكبر من الحد المسموح للاستيراد" }
                        bytes.write(buffer, 0, count)
                    }
                    require(!files.containsKey(safeName)) { "ملف Excel يحتوي مكونًا مكرر المسار" }
                    files[safeName] = bytes.toByteArray()
                }
                e = z.nextEntry
            }
        }
        // Resolve the first worksheet through workbook relationships instead of assuming sheet1.xml.
        val workbook = files["xl/workbook.xml"] ?: throw IllegalArgumentException("ملف Excel لا يحتوي تعريف المصنف")
        val workbookDoc = parse(workbook)
        val sheetNodes = workbookDoc.getElementsByTagName("sheet")
        require(sheetNodes.length > 0) { "ملف Excel لا يحتوي أوراق عمل" }
        val relBytes = files["xl/_rels/workbook.xml.rels"] ?: throw IllegalArgumentException("ملف Excel لا يحتوي روابط أوراق العمل")
        val relDoc = parse(relBytes); val relNodes = relDoc.getElementsByTagName("Relationship")
        var selected = sheetNodes.item(0) as Element
        if (!preferredSheetName.isNullOrBlank()) {
            val aliases = when (preferredSheetName.trim()) {
                "قاعدة البيانات" -> setOf("قاعدة البيانات", "البيانات", "التحاليل", "بيانات", "تحليل", "Sheet1", "Data")
                else -> setOf(preferredSheetName.trim())
            }
            val match = (0 until sheetNodes.length).map { sheetNodes.item(it) as Element }
                .firstOrNull { candidate -> aliases.any { it.equals(candidate.getAttribute("name").trim(), ignoreCase = true) } }
            // Use the first sheet as a safe fallback; header validation runs before DB changes.
            selected = match ?: (sheetNodes.item(0) as Element)
        }
        val relationshipId = selected.getAttribute("r:id")
        var target: String? = null
        for (i in 0 until relNodes.length) { val rel = relNodes.item(i) as Element; if (rel.getAttribute("Id") == relationshipId) target = rel.getAttribute("Target") }
        val sheetPath = target?.let { raw ->
            val normalized = java.net.URI(null, null, raw.replace('\\', '/'), null).normalize().path
            val candidate = if (normalized.startsWith("/")) normalized.removePrefix("/") else "xl/$normalized"
            require(!candidate.split('/').any { it == ".." }) { "مسار ورقة البيانات غير صالح" }
            candidate
        } ?: throw IllegalArgumentException("تعذر تحديد ورقة البيانات")
        val sheetBytes = files[sheetPath] ?: throw IllegalArgumentException("ورقة البيانات المطلوبة غير موجودة")
        val shared = files["xl/sharedStrings.xml"]?.let { parse(it).getElementsByTagName("si").let { nodes -> (0 until nodes.length).map { i -> nodes.item(i).textContent } } } ?: emptyList()
        // SAX parsing avoids constructing a huge DOM tree for workbooks containing tens of
        // thousands of rows. The worksheet XML may be tens of MB after decompression.
        val rows = mutableListOf<List<String>>()
        val factory = secureSaxFactory()
        val parser = factory.newSAXParser()
        val reader = parser.xmlReader.apply {
            // Some Android XML providers do not implement the Xerces DOCTYPE feature.
            // Treat unsupported hardening flags as optional, while blocking external
            // entity resolution at the parser boundary below.
            setFeatureSafely(this, "http://apache.org/xml/features/disallow-doctype-decl", true)
            setFeatureSafely(this, "http://xml.org/sax/features/external-general-entities", false)
            setFeatureSafely(this, "http://xml.org/sax/features/external-parameter-entities", false)
            setFeatureSafely(this, "http://apache.org/xml/features/nonvalidating/load-external-dtd", false)
            entityResolver = org.xml.sax.EntityResolver { _, _ -> InputSource(java.io.StringReader("")) }
        }
        val handler = object : DefaultHandler() {
            private var inRow = false; private var inCell = false; private var inValue = false
            private var cellType = ""; private var cellIndex = -1; private var maxIndex = -1
            private val values = mutableMapOf<Int, String>(); private val text = StringBuilder()
            override fun startElement(uri: String?, localName: String?, qName: String, attrs: Attributes) {
                val tag = (localName?.takeIf { it.isNotBlank() } ?: qName.substringAfter(':')).substringAfter(':')
                when (tag) {
                    "row" -> { inRow = true; values.clear(); maxIndex = -1 }
                    "c" -> { inCell = true; cellType = attrs.getValue("t") ?: ""; cellIndex = colIndex(attrs.getValue("r") ?: "A1"); maxIndex = maxOf(maxIndex, cellIndex); text.setLength(0) }
                    "v", "t" -> if (inCell) { inValue = true; text.setLength(0) }
                }
            }
            override fun characters(ch: CharArray, start: Int, length: Int) { if (inValue) text.append(ch, start, length) }
            override fun endElement(uri: String?, localName: String?, qName: String) {
                val tag = (localName?.takeIf { it.isNotBlank() } ?: qName.substringAfter(':')).substringAfter(':')
                when (tag) {
                    "v", "t" -> if (inCell && inValue) { val value = text.toString(); if (cellType == "s" && tag == "v") { val idx = value.toIntOrNull(); values[cellIndex] = if (idx == null) "" else shared.getOrElse(idx) { "" } } else values[cellIndex] = (values[cellIndex] ?: "") + value; inValue = false }
                    "c" -> inCell = false
                    "row" -> { if (rows.size >= 200_000) throw IllegalArgumentException("عدد صفوف Excel يتجاوز الحد المسموح"); rows.add((0..maxIndex).map { values[it] ?: "" }); inRow = false }
                }
            }
        }
        reader.contentHandler = handler
        reader.parse(InputSource(sheetBytes.inputStream()))
        return Sheet(rows)
    }

    private fun secureSaxFactory(): SAXParserFactory = SAXParserFactory.newInstance().apply {
        isNamespaceAware = true
        try { isXIncludeAware = false } catch (_: Exception) { }
        setFeatureSafely(this, "http://apache.org/xml/features/disallow-doctype-decl", true)
        setFeatureSafely(this, "http://xml.org/sax/features/external-general-entities", false)
        setFeatureSafely(this, "http://xml.org/sax/features/external-parameter-entities", false)
        setFeatureSafely(this, "http://apache.org/xml/features/nonvalidating/load-external-dtd", false)
    }
    private fun setFeatureSafely(factory: SAXParserFactory, name: String, value: Boolean) {
        try { factory.setFeature(name, value) } catch (_: Exception) { /* provider-specific feature */ }
    }
    private fun setFeatureSafely(reader: org.xml.sax.XMLReader, name: String, value: Boolean) {
        try { reader.setFeature(name, value) } catch (_: Exception) { /* provider-specific feature */ }
    }
    private fun parse(bytes: ByteArray): org.w3c.dom.Document {
        val factory = DocumentBuilderFactory.newInstance().apply {
            isNamespaceAware = false
            try { isXIncludeAware = false } catch (_: Exception) { }
            try { setExpandEntityReferences(false) } catch (_: Exception) { }
            try { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) } catch (_: Exception) { }
            try { setFeature("http://xml.org/sax/features/external-general-entities", false) } catch (_: Exception) { }
            try { setFeature("http://xml.org/sax/features/external-parameter-entities", false) } catch (_: Exception) { }
            try { setAttribute("http://javax.xml.XMLConstants/property/accessExternalDTD", "") } catch (_: Exception) { }
            try { setAttribute("http://javax.xml.XMLConstants/property/accessExternalSchema", "") } catch (_: Exception) { }
        }
        return factory.newDocumentBuilder().apply {
            setEntityResolver(org.xml.sax.EntityResolver { _, _ -> InputSource(java.io.StringReader("")) })
        }.parse(bytes.inputStream())
    }
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")
    private fun col(n: Int): String { var x=n+1; val b=StringBuilder(); while(x>0){val r=(x-1)%26;b.insert(0,('A'.code+r).toChar());x=(x-1)/26};return b.toString() }
    private fun colIndex(ref: String): Int { val letters=ref.takeWhile{it.isLetter()};var n=0;letters.forEach{n=n*26+(it.uppercaseChar().code-'A'.code+1)};return n-1 }
}
