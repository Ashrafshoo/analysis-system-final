package com.ashraf.employeeanalysis

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class XlsxCodecSecurityTest {
    @Test fun roundTripLargeArabicSheet() {
        val rows = (1..500).map { listOf("رقم $it", "موظف تجريبي $it", "سلبي") }
        val bytes = ByteArrayOutputStream().also { XlsxCodec.write(it, rows) }.toByteArray()
        assertTrue(XlsxCodec.read(ByteArrayInputStream(bytes)).rows.size == 500)
    }
}
