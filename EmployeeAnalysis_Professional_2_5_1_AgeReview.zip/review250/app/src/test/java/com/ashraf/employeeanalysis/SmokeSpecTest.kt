package com.ashraf.employeeanalysis

import org.junit.Assert.assertTrue
import org.junit.Test

class SmokeSpecTest {
    @Test fun projectHasAValidApplicationIdConvention() {
        assertTrue("com.ashraf.employeeanalysis".contains("."))
    }
}
