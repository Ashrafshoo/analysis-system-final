package com.ashraf.employeeanalysis

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import net.sqlcipher.database.SQLiteDatabase
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Local SQLCipher key protected by Android Keystore; never stored as plaintext in preferences. */
object DatabaseSecurity {
    private const val PREFS = "database_security"
    private const val CIPHER_KEY = "wrapped_db_key"
    private const val IV_KEY = "wrapped_db_iv"
    private const val ALIAS = "employee_analysis_keystore_v1"

    fun loadOrCreateKey(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val stored = prefs.getString(CIPHER_KEY, null)
        if (stored != null) {
            val iv = Base64.decode(prefs.getString(IV_KEY, "") ?: "", Base64.NO_WRAP)
            require(iv.size == 12) { "بيانات مفتاح قاعدة البيانات تالفة؛ لا تحذف بيانات التطبيق حتى لا تفقد قاعدة البيانات" }
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKeystoreKey(), GCMParameterSpec(128, iv))
            val raw = cipher.doFinal(Base64.decode(stored, Base64.NO_WRAP))
            require(raw.size == 32) { "مفتاح قاعدة البيانات غير صالح" }
            return Base64.encodeToString(raw, Base64.NO_WRAP)
        }
        val raw = ByteArray(32).also { java.security.SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKeystoreKey())
        val ok = prefs.edit().putString(CIPHER_KEY, Base64.encodeToString(cipher.doFinal(raw), Base64.NO_WRAP))
            .putString(IV_KEY, Base64.encodeToString(cipher.iv, Base64.NO_WRAP)).commit()
        check(ok) { "تعذر حفظ مفتاح تشفير قاعدة البيانات" }
        return Base64.encodeToString(raw, Base64.NO_WRAP)
    }

    private fun getOrCreateKeystoreKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }

    /** One-time atomic migration of an existing plaintext SQLite file to SQLCipher. */
    fun migratePlainDatabase(context: Context, passphrase: String) {
        val file = context.getDatabasePath("employee_analysis.db")
        if (!file.exists() || isSqlCipher(file, passphrase)) return
        val temp = File(file.parentFile, "employee_analysis.encrypted.tmp")
        val old = File(file.parentFile, "employee_analysis.plain.migration-backup")
        temp.delete(); old.delete()
        val source = SQLiteDatabase.openDatabase(file.absolutePath, "", null, SQLiteDatabase.OPEN_READWRITE)
        try {
            val escapedPath = temp.absolutePath.replace("'", "''")
            val escapedKey = passphrase.replace("'", "''")
            source.rawExecSQL("ATTACH DATABASE '$escapedPath' AS encrypted KEY '$escapedKey'")
            try { source.rawQuery("SELECT sqlcipher_export('encrypted')", null).use { it.moveToFirst() } }
            finally { source.rawExecSQL("DETACH DATABASE encrypted") }
        } finally { source.close() }
        require(isSqlCipher(temp, passphrase)) { temp.delete(); "تعذر التحقق من تشفير قاعدة البيانات بعد الترحيل" }
        if (!file.renameTo(old)) { temp.delete(); throw IllegalStateException("تعذر حفظ قاعدة البيانات الأصلية قبل التشفير") }
        if (!temp.renameTo(file)) {
            old.renameTo(file); temp.delete()
            throw IllegalStateException("تعذر اعتماد قاعدة البيانات المشفرة؛ تمت إعادة الملف الأصلي")
        }
        // Validate the committed target. Roll back to the original if validation fails.
        if (!isSqlCipher(file, passphrase)) {
            file.delete(); old.renameTo(file)
            throw IllegalStateException("فشل التحقق النهائي؛ تمت إعادة قاعدة البيانات الأصلية")
        }
        old.delete()
    }

    fun isSqlCipher(file: File, passphrase: String): Boolean = try {
        val db = SQLiteDatabase.openDatabase(file.absolutePath, passphrase, null, SQLiteDatabase.OPEN_READONLY)
        try {
            db.rawQuery("SELECT count(*) FROM sqlite_master", null).use { it.moveToFirst() }
            db.rawQuery("PRAGMA cipher_version", null).use { it.moveToFirst() && it.getString(0).isNotBlank() }
        } finally { db.close() }
    } catch (_: Exception) { false }
}
